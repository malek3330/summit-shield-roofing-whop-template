# Roofing & High-Ticket Contractor Whop Website Template

Clean, modular, **2-minute rebrandable** template engineered for US residential and light-commercial roofing contractors on **Whop Websites** (`whop.sh`) with complete high-ticket payment lifecycle integration:

1. **Dedicated Checkout Routes (`/book/inspection`, `/book/tune-up`, `/deposit`)** (`$149` / `$299` / `$500` real Whop Products & Plans via `<PaymentElement>`, `<ExpressCheckoutElement>`, `<CheckoutElement>`, `<EmailElement>`, and `<BrandingElement>`)
2. **Card-on-File Authorization (`off_session`)** via `<Payments mode="setup">` + Whop `POST /setup_intents` and deposit confirmation tokens
3. **Final Balance Billing (`/checkout/return` & Contractor Portal)** via Whop `POST /invoices` (`/issue` auto-charge on vaulted `payt_...` OR `/send` hosted invoice checkout link + PDF + `/void` cleanup)
4. **Quote Requests -> Whop Leads & Events CRM** (`POST /leads` + `POST /events` `lead` with public response redaction and admin-only CRM listing)
5. **Custom Conversion Pixel Telemetry + Live Inspector** (`whop.track('service_viewed' | 'estimate_requested' | 'deposit_started')` + `?debug=1` or bottom-left Pixel Log pill)

Default Example Deployment: **https://summit-shield-roofing-tx.whop.site**

---

## 2-Minute Whitelabel / Rebrand Checklist (No Component Rewrites Needed)

Anyone reusing this template for a new roofing company only needs to edit **1 config file** (`src/config/roofingTemplate.ts`), optionally drop in photos under `public/images/`, and push encrypted secrets via Whop CLI:

### Step 1 — Edit [`src/config/roofingTemplate.ts`](src/config/roofingTemplate.ts)

Everything displayed on the storefront is centralized inside `roofingTemplate`:

| Key | What It Controls Across the Entire Site |
| --- | --- |
| `brand` | Company name (`name`, `shortName`), optional custom `logoUrl`, tagline, license badge, phone, email, address, hours, rating & completed roof count |
| `theme` | Complete site CSS palette (`canvasHex`, `surfaceHex`, `borderHex`, `inkHex`, `obsidianHex`, `midnightHex`, `accentHex`, `accentDeepHex`, `secondaryAccentHex`, `forestHex`) **plus** native Whop Payment Elements styling (`elementsAccentColor`, `elementsGrayColor`) |
| `hero` | Eyebrow, headline + gradient-highlighted phrases (`headlineHighlightPrimary`, `headlineHighlightSecondary`), CTAs, badge pills, workflow title, photography paths, craftsmanship showcase copy & 4 hero stats |
| `services` | Service scope cards, interactive filter pill labels (`filterLabel`), pricing labels, warranties & highlights |
| `plans` | The 3 checkout plans (`inspection`, `deposit`, `tuneup`), titles, prices, deliverables & off-session vault flag |
| `financing` | Native Whop BNPL provider cards (Klarna, Afterpay / Cash App Afterpay, Splitit) + monthly calculator sample total & quick presets (`calculatorPresets`) |
| `serviceArea` | Region label, headline, city cards & **automatic SVG dispatch radar pins** (`mapLabel`, `mapX`, `mapY`, `isHub` — omit coordinates to auto-place around your HQ) |
| `reviews` | Trust credentials strip & verified homeowner testimonials |
| `invoiceFlowPresets` | Step 3 closing invoice presets (gross total, credited deposit, net final balance) |
| `formPlaceholders` | Sample names, emails, phones, ZIP codes & street addresses for forms |

### Step 2 — Optional Visual Assets (`public/`)

- Replace the three hero/portfolio images in `public/images/` (`hero-roof.jpg`, `craftsmanship-detail.jpg`, `replacement-home.jpg`) or add your logo (`public/images/logo.png`) and reference it via `brand.logoUrl`.
- Customize `public/favicon.svg` if desired.

### Step 3 — Link Your Own Whop App & Set Encrypted Secrets

1. Create or connect a Whop website app for your contractor account:
   ```bash
   npx whop apps create   # or update "app_id" and "name" in whop.app.json
   ```
2. Provision encrypted runtime credentials (documented in `.env.example`):
   ```bash
   npx whop apps secrets set --app <your_app_id> \
     --secret ROOFING_ACCOUNT_ID=biz_xxxxxxxxxxxxx \
     --secret ROOFING_PLAN_INSPECTION=plan_xxxxxxxxxxxxx \
     --secret ROOFING_PLAN_DEPOSIT=plan_xxxxxxxxxxxxx \
     --secret ROOFING_PLAN_TUNEUP=plan_xxxxxxxxxxxxx \
     --secret ROOFING_PRODUCT_INSPECTION=prod_xxxxxxxxxxxxx \
     --secret ROOFING_PRODUCT_DEPOSIT=prod_xxxxxxxxxxxxx \
     --secret ROOFING_PRODUCT_TUNEUP=prod_xxxxxxxxxxxxx \
     --secret ADMIN_PASSCODE=<strong_portal_passcode> \
     --secret SESSION_SECRET=<random_64_char_hex>
   ```
   *(If deploying off Whop hosted proxy, also set `WHOP_API_KEY` as a secret.)*

### Step 4 — Verify & Deploy Live

```bash
# 1. Install dependencies
npm install

# 2. Typecheck & build check
npm run typecheck
npm run build

# 3. Deploy live to *.whop.site via Whop CLI
npx whop apps deploy
```

---

## Security & Privacy Architecture

- **Zero Hardcoded Account/Plan IDs or Secrets in Repo:** Product/plan IDs (`ROOFING_PLAN_*`, `ROOFING_PRODUCT_*`, `ROOFING_ACCOUNT_ID`), Portal credentials (`ADMIN_PASSCODE`, `SESSION_SECRET`), and optional Sandbox keys live inside encrypted Whop App Secrets, never committed to source files.
- **Authenticated Contractor Operations Portal:** Viewing homeowner leads (`GET /api/leads`), viewing/issuing/voiding invoices (`GET` / `POST /api/invoices`), listing vaulted customers (`GET /api/setup-intents`), viewing diagnostic server info, and toggling Sandbox Test Mode all require a valid signed `HttpOnly; SameSite=Lax` HMAC-SHA256 `summit_admin_session` cookie issued by `POST /api/admin/auth`.
- **Signed Buyer Receipt Cookie (`summit_buyer_receipt`):** Single-transaction status checks (`GET /api/payments/confirm?id=...`, `GET /api/setup-intents?id=...`) require either an admin session or a signed session receipt cookie bound to that specific transaction ID, and strictly redact `member_id`, `payment_method_id`, and customer emails for non-admin callers.

---

## Testing Payment Elements in Whop Sandbox (`4242 4242 4242 4242`)

Whop rejects test card numbers when running against Live Production keys. To test the complete checkout, card vaulting, and auto-charge invoice workflow safely without charging a real card:

1. Open [Whop Sandbox Developer Dashboard](https://sandbox.whop.com/dashboard/developer), grab a Sandbox Company API key (`apik_...`) and Sandbox Business ID (`biz_...`).
2. Run the 1-command Sandbox provisioning script:
   ```bash
   node scripts/setup-sandbox.mjs --key apik_xxxxxxxxxxxxx --account biz_xxxxxxxxxxxxx
   npx whop apps deploy
   ```
3. Open `/deposit` or `/book/inspection`, click **`Test Card (4242)`** at the top of the checkout card to switch into Sandbox Checkout Mode (no passcode required for public test demos), or click **Contractor Portal** in the footer to manage leads and invoices as an admin.
4. Test card **`4242 4242 4242 4242`** (any future expiration date + any 3-digit CVC) works cleanly across `PaymentElement`, `ExpressCheckoutElement`, `CheckoutElement`, `$0 Card Authorization`, and auto-redirects to `/checkout/return` where you can immediately demo **Auto-Charge Saved Card** or **Send Manual Invoice** via the Whop Invoices API.
