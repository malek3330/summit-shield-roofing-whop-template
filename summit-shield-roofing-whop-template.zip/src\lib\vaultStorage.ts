import type { VaultedCustomerRecord } from '#/lib/types'

const STORAGE_KEY = 'summit_shield_vault_hint_v2'

/**
 * Only non-PII confirmation metadata is ever stored in browser localStorage.
 * Full billing identifiers (`mber_...`, `payt_...`, email) remain strictly inside
 * authenticated Contractor Portal memory / server Whop API lookups.
 */
export function loadSavedVaultCustomer(): VaultedCustomerRecord | null {
  if (typeof window === 'undefined') return null
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const parsed = JSON.parse(raw) as Partial<VaultedCustomerRecord>
    if (!parsed || typeof parsed.sourceType !== 'string') return null
    return {
      sourceId: '',
      sourceType: parsed.sourceType,
      cardSaved: Boolean(parsed.cardSaved),
      cardSummary: parsed.cardSummary ?? null,
      capturedAtIso: parsed.capturedAtIso ?? new Date().toISOString(),
    }
  } catch {
    return null
  }
}

export function persistVaultCustomer(record: VaultedCustomerRecord): void {
  if (typeof window === 'undefined') return
  try {
    const safeHint: VaultedCustomerRecord = {
      sourceId: '',
      sourceType: record.sourceType,
      cardSaved: Boolean(record.cardSaved),
      cardSummary: record.cardSummary ?? null,
      capturedAtIso: record.capturedAtIso,
    }
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(safeHint))
  } catch {
    // Ignore storage quota issues cleanly
  }
}

export function clearVaultCustomer(): void {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.removeItem(STORAGE_KEY)
    window.localStorage.removeItem('summit_shield_vaulted_customer_v1')
  } catch {
    // Ignore storage issues cleanly
  }
}
