import { createFileRoute } from '@tanstack/react-router'
import {
  createBuyerReceiptSetCookie,
  getAdminSession,
  hasBuyerReceiptAccess,
} from '#/server/auth'
import {
  createWhopServerClient,
  handleWhopApiError,
  jsonResponse,
  requireAccountId,
  resolveAuthorizedRuntimeMode,
} from '#/server/whopServer'

interface CreateSetupIntentPayload {
  confirmationToken?: string
  email?: string
  returnUrl?: string
  metadata?: Record<string, string | null>
  environmentMode?: 'production' | 'sandbox'
}

export const Route = createFileRoute('/api/setup-intents')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const isAdmin = await getAdminSession(request)
          const url = new URL(request.url)
          const id = url.searchParams.get('id')?.trim()
          const mode = resolveAuthorizedRuntimeMode(url.searchParams.get('mode'), isAdmin, Boolean(id))
          const whop = createWhopServerClient(mode)

          if (id) {
            if (!id.startsWith('sint_')) {
              return jsonResponse(
                { ok: false, code: 'INVALID_ID', message: 'Invalid setup intent identifier.' },
                400,
              )
            }

            const hasReceipt = isAdmin || (await hasBuyerReceiptAccess(request, id))
            if (!hasReceipt) {
              return jsonResponse(
                {
                  ok: false,
                  code: 'UNAUTHORIZED',
                  message: 'Not authorized to inspect this card setup record.',
                },
                401,
              )
            }

            const [setupIntent, setupStatus] = await Promise.all([
              whop.setupIntents.retrieve({ id }),
              whop.setupIntents.retrieveStatus({ setup_intent_id: id }).catch(() => null),
            ])

            if (!isAdmin) {
              return jsonResponse({
                ok: true,
                redacted: true,
                setupIntent: {
                  status: setupIntent.status,
                  cardSaved: Boolean(setupIntent.payment_method_id && setupIntent.member_id),
                  cardSummary: setupIntent.payment_instrument?.display_name ?? null,
                  failureMessage: setupIntent.last_setup_error?.message ?? null,
                },
              })
            }

            return jsonResponse({
              ok: true,
              environment: mode,
              setupIntent,
              setupStatus,
            })
          }

          // Listing vaulted customers (Setup Intents + Deposits w/ saved methods) is strictly Admin-only
          if (!isAdmin) {
            return jsonResponse(
              {
                ok: false,
                code: 'UNAUTHORIZED',
                message: 'Contractor Portal sign-in required to list saved payment methods.',
              },
              401,
            )
          }

          const accountId = requireAccountId(mode)
          const [setupPage, paymentsPage] = await Promise.all([
            whop.setupIntents.list({
              account_id: accountId,
              first: 15,
            }),
            whop.payments
              .list({
                account_id: accountId,
                first: 15,
              })
              .catch(() => ({ data: [] })),
          ])

          const vaultedPayments = (paymentsPage.data ?? []).filter(
            (p) => Boolean(p.payment_method_id && p.member_id),
          )

          return jsonResponse({
            ok: true,
            environment: mode,
            setupIntents: setupPage.data,
            vaultedPayments,
          })
        } catch (error) {
          return handleWhopApiError(error, 'reading Whop setup intents')
        }
      },

      POST: async ({ request }) => {
        try {
          const isAdmin = await getAdminSession(request)
          const body = (await request.json().catch(() => null)) as CreateSetupIntentPayload | null
          const confirmationToken = body?.confirmationToken?.trim()

          if (!confirmationToken) {
            return jsonResponse(
              {
                ok: false,
                code: 'MISSING_CONFIRMATION_TOKEN',
                message: 'Missing confirmation token from Payment Element.',
              },
              400,
            )
          }

          const mode = resolveAuthorizedRuntimeMode(body?.environmentMode, isAdmin, true)
          const accountId = requireAccountId(mode)
          const whop = createWhopServerClient(mode)
          const requestOrigin = new URL(request.url).origin
          const safeReturnUrl =
            body?.returnUrl?.trim() || `${requestOrigin}/checkout/return?mode=setup`

          const setupIntent = await whop.setupIntents.create({
            account_id: accountId,
            confirmation_token: confirmationToken,
            currency: 'usd',
            return_url: safeReturnUrl,
            ...(body?.email?.trim() ? { email: body.email.trim() } : {}),
            metadata: {
              flow: 'roofing_card_on_file_setup',
              purpose: 'final_balance_invoicing',
              ...(body?.metadata ?? {}),
            },
          })

          const receiptCookie = await createBuyerReceiptSetCookie(request, setupIntent.id)
          const extraHeaders = receiptCookie ? { 'Set-Cookie': receiptCookie } : undefined

          if (!isAdmin) {
            return jsonResponse(
              {
                ok: true,
                setupIntent: {
                  id: setupIntent.id,
                  status: setupIntent.status,
                  client_secret: setupIntent.client_secret,
                },
                clientSecret: setupIntent.client_secret,
              },
              201,
              extraHeaders,
            )
          }

          return jsonResponse(
            {
              ok: true,
              environment: mode,
              setupIntent,
              clientSecret: setupIntent.client_secret,
            },
            201,
            extraHeaders,
          )
        } catch (error) {
          return handleWhopApiError(error, 'creating Whop setup intent')
        }
      },
    },
  },
})
