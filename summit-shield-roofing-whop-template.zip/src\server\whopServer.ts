import { WhopClient, WhopEnvironment } from '@whop/sdk'
import { roofingTemplate, type WhopPlanKey } from '#/config/roofingTemplate'

export type WhopRuntimeMode = 'production' | 'sandbox'

export class WhopNotConfiguredError extends Error {
  readonly code = 'WHOP_NOT_CONFIGURED'
  readonly status = 503

  constructor(message?: string) {
    super(
      message ??
        'Payment processing credentials are not active yet for this deployment.',
    )
    this.name = 'WhopNotConfiguredError'
  }
}

export interface ResolvedPlanServerConfig {
  key: WhopPlanKey
  title: string
  shortTitle: string
  badge: string
  priceUsd: number
  billingLabel: string
  supportsSetupIntentVault: boolean
  productId: string
  variantId: string
  isRealVariantId: boolean
  isRealProductId: boolean
}

export interface PublicWhopRuntimeConfig {
  configured: boolean
  checkoutReady: boolean
  environment: WhopRuntimeMode
  sandboxConfigured: boolean
  adminAuthenticated: boolean
  hasRealAccountId: boolean
  hasRealPlans: boolean
  checkoutAccountId: string
  plans: Record<WhopPlanKey, {
    key: WhopPlanKey
    title: string
    shortTitle: string
    badge: string
    priceUsd: number
    billingLabel: string
    supportsSetupIntentVault: boolean
    productId: string
    variantId: string
    isRealVariantId: boolean
    isRealProductId: boolean
  }>
  // Populated ONLY when Admin Portal session is authenticated
  adminDiagnostics?: {
    authMode: 'api_key' | 'hosted_proxy' | 'unconfigured'
    accountId: string
    hasRealAccountId: boolean
    webhookConfigured: boolean
    sandboxConfigured: boolean
  }
}

export function readServerEnv(name: string): string | undefined {
  if (typeof process === 'undefined' || !process.env) return undefined
  const value = process.env[name]?.trim()
  return value && value.length > 0 ? value : undefined
}

export function isPlaceholderWhopId(id: string | undefined | null): boolean {
  if (!id) return true
  const trimmed = id.trim()
  if (!trimmed) return true
  return (
    trimmed.startsWith('prod_roof_') ||
    trimmed.startsWith('plan_roof_') ||
    trimmed.includes('replace_with_yours') ||
    trimmed.includes('xxxxxxxx')
  )
}

export function resolveAuthorizedRuntimeMode(
  requestedMode: unknown,
  isAdmin: boolean,
  allowPublicSandboxDemo = false,
): WhopRuntimeMode {
  if ((isAdmin || allowPublicSandboxDemo) && requestedMode === 'sandbox' && isSandboxModeConfigured()) {
    return 'sandbox'
  }
  const raw = readServerEnv('WHOP_ENVIRONMENT') ?? roofingTemplate.whopDefaults.environment
  return raw === 'sandbox' ? 'sandbox' : 'production'
}

export function getWhopEnvironmentName(requestedMode?: WhopRuntimeMode | null): WhopRuntimeMode {
  if (requestedMode === 'sandbox' && isSandboxModeConfigured()) {
    return 'sandbox'
  }
  const raw = readServerEnv('WHOP_ENVIRONMENT') ?? roofingTemplate.whopDefaults.environment
  return raw === 'sandbox' ? 'sandbox' : 'production'
}

export function isSandboxModeConfigured(): boolean {
  const sbxKey = readServerEnv('WHOP_SANDBOX_API_KEY') ?? readServerEnv('ROOFING_SANDBOX_API_KEY')
  const sbxAcct =
    readServerEnv('WHOP_SANDBOX_ACCOUNT_ID') ?? readServerEnv('ROOFING_SANDBOX_ACCOUNT_ID')
  const p1 =
    readServerEnv('WHOP_SANDBOX_PLAN_INSPECTION') ?? readServerEnv('ROOFING_SANDBOX_PLAN_INSPECTION')
  const p2 =
    readServerEnv('WHOP_SANDBOX_PLAN_DEPOSIT') ?? readServerEnv('ROOFING_SANDBOX_PLAN_DEPOSIT')
  const p3 =
    readServerEnv('WHOP_SANDBOX_PLAN_TUNEUP') ?? readServerEnv('ROOFING_SANDBOX_PLAN_TUNEUP')

  if (readServerEnv('WHOP_ENVIRONMENT') === 'sandbox') {
    const baseAcct = getWhopAccountId('production')
    return Boolean(
      readServerEnv('WHOP_API_KEY') &&
        baseAcct.startsWith('biz_') &&
        !isPlaceholderWhopId(baseAcct),
    )
  }

  return Boolean(
    sbxKey &&
      sbxAcct?.startsWith('biz_') &&
      !isPlaceholderWhopId(sbxAcct) &&
      p1?.startsWith('plan_') &&
      p2?.startsWith('plan_') &&
      p3?.startsWith('plan_'),
  )
}

export function getWhopAccountId(mode: WhopRuntimeMode = 'production'): string {
  if (mode === 'sandbox') {
    const sbx =
      readServerEnv('WHOP_SANDBOX_ACCOUNT_ID') ?? readServerEnv('ROOFING_SANDBOX_ACCOUNT_ID')
    if (sbx) return sbx
  }
  return (
    readServerEnv('WHOP_ACCOUNT_ID') ??
    readServerEnv('ROOFING_ACCOUNT_ID') ??
    roofingTemplate.whopDefaults.accountId ??
    ''
  )
}

export function getResolvedPlans(
  mode: WhopRuntimeMode = 'production',
): Record<WhopPlanKey, ResolvedPlanServerConfig> {
  const isSandbox = mode === 'sandbox' && isSandboxModeConfigured()

  const envVariantOverrides: Record<WhopPlanKey, string | undefined> = isSandbox
    ? {
        inspection:
          readServerEnv('WHOP_SANDBOX_PLAN_INSPECTION') ??
          readServerEnv('ROOFING_SANDBOX_PLAN_INSPECTION') ??
          readServerEnv('WHOP_PLAN_INSPECTION'),
        deposit:
          readServerEnv('WHOP_SANDBOX_PLAN_DEPOSIT') ??
          readServerEnv('ROOFING_SANDBOX_PLAN_DEPOSIT') ??
          readServerEnv('WHOP_PLAN_DEPOSIT'),
        tuneup:
          readServerEnv('WHOP_SANDBOX_PLAN_TUNEUP') ??
          readServerEnv('ROOFING_SANDBOX_PLAN_TUNEUP') ??
          readServerEnv('WHOP_PLAN_TUNEUP'),
      }
    : {
        inspection:
          readServerEnv('ROOFING_PLAN_INSPECTION') ??
          readServerEnv('WHOP_PLAN_INSPECTION') ??
          readServerEnv('WHOP_VARIANT_INSPECTION'),
        deposit:
          readServerEnv('ROOFING_PLAN_DEPOSIT') ??
          readServerEnv('WHOP_PLAN_DEPOSIT') ??
          readServerEnv('WHOP_VARIANT_DEPOSIT'),
        tuneup:
          readServerEnv('ROOFING_PLAN_TUNEUP') ??
          readServerEnv('WHOP_PLAN_TUNEUP') ??
          readServerEnv('WHOP_VARIANT_TUNEUP'),
      }

  const envProductOverrides: Record<WhopPlanKey, string | undefined> = isSandbox
    ? {
        inspection:
          readServerEnv('WHOP_SANDBOX_PRODUCT_INSPECTION') ??
          readServerEnv('ROOFING_SANDBOX_PRODUCT_INSPECTION'),
        deposit:
          readServerEnv('WHOP_SANDBOX_PRODUCT_DEPOSIT') ??
          readServerEnv('ROOFING_SANDBOX_PRODUCT_DEPOSIT'),
        tuneup:
          readServerEnv('WHOP_SANDBOX_PRODUCT_TUNEUP') ??
          readServerEnv('ROOFING_SANDBOX_PRODUCT_TUNEUP'),
      }
    : {
        inspection:
          readServerEnv('ROOFING_PRODUCT_INSPECTION') ?? readServerEnv('WHOP_PRODUCT_INSPECTION'),
        deposit:
          readServerEnv('ROOFING_PRODUCT_DEPOSIT') ?? readServerEnv('WHOP_PRODUCT_DEPOSIT'),
        tuneup:
          readServerEnv('ROOFING_PRODUCT_TUNEUP') ?? readServerEnv('WHOP_PRODUCT_TUNEUP'),
      }

  const out = {} as Record<WhopPlanKey, ResolvedPlanServerConfig>

  for (const key of ['inspection', 'deposit', 'tuneup'] as const) {
    const tpl = roofingTemplate.plans[key]
    const variantId = envVariantOverrides[key] ?? tpl.defaultVariantId
    const productId = envProductOverrides[key] ?? tpl.defaultProductId

    out[key] = {
      key,
      title: tpl.title,
      shortTitle: tpl.shortTitle,
      badge: tpl.badge,
      priceUsd: tpl.priceUsd,
      billingLabel: tpl.billingLabel,
      supportsSetupIntentVault: tpl.supportsSetupIntentVault,
      productId,
      variantId,
      isRealVariantId: variantId.startsWith('plan_') && !isPlaceholderWhopId(variantId),
      isRealProductId: productId.startsWith('prod_') && !isPlaceholderWhopId(productId),
    }
  }

  return out
}

export function getPublicRuntimeConfig(
  isAdmin = false,
  requestedMode?: WhopRuntimeMode | null,
): PublicWhopRuntimeConfig {
  const sandboxConfigured = isSandboxModeConfigured()
  const activeMode = resolveAuthorizedRuntimeMode(requestedMode, isAdmin, true)

  const apiKey =
    activeMode === 'sandbox'
      ? (readServerEnv('WHOP_SANDBOX_API_KEY') ??
          readServerEnv('ROOFING_SANDBOX_API_KEY') ??
          readServerEnv('WHOP_API_KEY'))
      : readServerEnv('WHOP_API_KEY')
  const apiOrigin = readServerEnv('WHOP_API_ORIGIN')
  const accountId = getWhopAccountId(activeMode)
  const plans = getResolvedPlans(activeMode)

  const authMode: 'api_key' | 'hosted_proxy' | 'unconfigured' = apiKey
    ? 'api_key'
    : activeMode === 'production' && apiOrigin
      ? 'hosted_proxy'
      : 'unconfigured'

  const hasRealAccountId = accountId.startsWith('biz_') && !isPlaceholderWhopId(accountId)
  const hasRealPlans =
    plans.inspection.isRealVariantId &&
    plans.deposit.isRealVariantId &&
    plans.tuneup.isRealVariantId

  const configured = authMode !== 'unconfigured' && hasRealAccountId

  const publicPlans = {
    inspection: {
      key: plans.inspection.key,
      title: plans.inspection.title,
      shortTitle: plans.inspection.shortTitle,
      badge: plans.inspection.badge,
      priceUsd: plans.inspection.priceUsd,
      billingLabel: plans.inspection.billingLabel,
      supportsSetupIntentVault: plans.inspection.supportsSetupIntentVault,
      productId: plans.inspection.productId,
      variantId: plans.inspection.variantId,
      isRealVariantId: plans.inspection.isRealVariantId,
      isRealProductId: plans.inspection.isRealProductId,
    },
    deposit: {
      key: plans.deposit.key,
      title: plans.deposit.title,
      shortTitle: plans.deposit.shortTitle,
      badge: plans.deposit.badge,
      priceUsd: plans.deposit.priceUsd,
      billingLabel: plans.deposit.billingLabel,
      supportsSetupIntentVault: plans.deposit.supportsSetupIntentVault,
      productId: plans.deposit.productId,
      variantId: plans.deposit.variantId,
      isRealVariantId: plans.deposit.isRealVariantId,
      isRealProductId: plans.deposit.isRealProductId,
    },
    tuneup: {
      key: plans.tuneup.key,
      title: plans.tuneup.title,
      shortTitle: plans.tuneup.shortTitle,
      badge: plans.tuneup.badge,
      priceUsd: plans.tuneup.priceUsd,
      billingLabel: plans.tuneup.billingLabel,
      supportsSetupIntentVault: plans.tuneup.supportsSetupIntentVault,
      productId: plans.tuneup.productId,
      variantId: plans.tuneup.variantId,
      isRealVariantId: plans.tuneup.isRealVariantId,
      isRealProductId: plans.tuneup.isRealProductId,
    },
  }

  return {
    configured,
    checkoutReady: configured && hasRealPlans,
    environment: activeMode,
    sandboxConfigured,
    adminAuthenticated: isAdmin,
    hasRealAccountId,
    hasRealPlans,
    checkoutAccountId: hasRealAccountId ? accountId : '',
    plans: publicPlans,
    ...(isAdmin
      ? {
          adminDiagnostics: {
            authMode,
            accountId,
            hasRealAccountId,
            webhookConfigured: Boolean(readServerEnv('WHOP_WEBHOOK_SECRET')),
            sandboxConfigured,
          },
        }
      : {}),
  }
}

export function createWhopServerClient(mode: WhopRuntimeMode = 'production'): WhopClient {
  if (mode === 'sandbox') {
    const sbxKey =
      readServerEnv('WHOP_SANDBOX_API_KEY') ??
      readServerEnv('ROOFING_SANDBOX_API_KEY') ??
      (readServerEnv('WHOP_ENVIRONMENT') === 'sandbox' ? readServerEnv('WHOP_API_KEY') : undefined)

    if (!sbxKey) {
      throw new WhopNotConfiguredError(
        'Sandbox API key is not configured yet. Add WHOP_SANDBOX_API_KEY via `whop apps secrets set`.',
      )
    }

    return new WhopClient({
      token: sbxKey,
      environment: WhopEnvironment.Sandbox,
      apiVersionDate: '2026-10-28',
    })
  }

  const apiKey = readServerEnv('WHOP_API_KEY')
  const apiOrigin = readServerEnv('WHOP_API_ORIGIN')
  const envDefault = getWhopEnvironmentName()

  if (apiKey) {
    return new WhopClient({
      token: apiKey,
      environment:
        envDefault === 'sandbox' ? WhopEnvironment.Sandbox : WhopEnvironment.Production,
      apiVersionDate: '2026-10-28',
    })
  }

  if (apiOrigin) {
    const cleanOrigin = apiOrigin.replace(/\/+$/, '')
    return new WhopClient({
      baseUrl: `${cleanOrigin}/api/v1`,
      auth: false,
      apiVersionDate: '2026-10-28',
    })
  }

  throw new WhopNotConfiguredError()
}

export function requireAccountId(mode: WhopRuntimeMode = 'production'): string {
  const accountId = getWhopAccountId(mode)
  if (!accountId || !accountId.startsWith('biz_') || isPlaceholderWhopId(accountId)) {
    throw new WhopNotConfiguredError('Missing valid merchant account configuration.')
  }
  return accountId
}

export function jsonResponse(
  data: unknown,
  status = 200,
  extraHeaders?: Record<string, string>,
): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      ...(extraHeaders ?? {}),
    },
  })
}

export function handleWhopApiError(error: unknown, contextLabel: string): Response {
  if (error instanceof WhopNotConfiguredError) {
    return jsonResponse(
      {
        ok: false,
        code: error.code,
        message: error.message,
      },
      error.status,
    )
  }

  const errObj = error as {
    statusCode?: number
    message?: string
    body?: { error?: { message?: string; code?: string }; message?: string }
  }

  const statusCode =
    typeof errObj?.statusCode === 'number' && errObj.statusCode >= 400 && errObj.statusCode < 600
      ? errObj.statusCode
      : 500

  const apiMessage =
    errObj?.body?.error?.message ??
    errObj?.body?.message ??
    errObj?.message ??
    `Unexpected error during ${contextLabel}`

  const apiCode = errObj?.body?.error?.code ?? 'PAYMENT_GATEWAY_ERROR'

  // Never leak raw `details: errObj.body` upstream metadata to callers
  return jsonResponse(
    {
      ok: false,
      code: apiCode,
      message: apiMessage,
    },
    statusCode,
  )
}
