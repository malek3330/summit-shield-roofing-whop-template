import { createFileRoute, Link } from '@tanstack/react-router'
import { useEffect } from 'react'
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  ShieldCheck,
  Sparkles,
  Wallet,
} from 'lucide-react'
import { Footer } from '#/components/Footer'
import { Navbar } from '#/components/Navbar'
import { PixelDebugPill } from '#/components/PixelDebugPill'
import { WhopCheckoutFlow } from '#/components/WhopCheckoutFlow'
import { roofingTemplate, type WhopPlanKey } from '#/config/roofingTemplate'
import { trackWhopEvent } from '#/lib/whopPixel'

export const Route = createFileRoute('/book/$slug')({
  component: BookServiceCheckoutPage,
})

function resolvePlanKeyFromSlug(slug: string): WhopPlanKey {
  const s = slug.toLowerCase().trim()
  if (s === 'inspection' || s === 'inspect') return 'inspection'
  if (s === 'deposit' || s === 'project-deposit') return 'deposit'
  return 'tuneup'
}

function BookServiceCheckoutPage() {
  const { slug } = Route.useParams()
  const planKey = resolvePlanKeyFromSlug(slug)
  const plan = roofingTemplate.plans[planKey]

  useEffect(() => {
    trackWhopEvent('view_content', {
      content_id: planKey,
      content_name: plan.title,
      value: plan.priceUsd,
      currency: 'USD',
      route: `/book/${slug}`,
    })
    trackWhopEvent('service_viewed', {
      service_id: planKey,
      service_title: plan.title,
      price_usd: plan.priceUsd,
      source: 'dedicated_booking_page',
    })
  }, [planKey, plan.title, plan.priceUsd, slug])

  return (
    <div className="min-h-screen bg-[var(--roof-canvas)] text-[var(--roof-ink)]">
      <Navbar />

      {/* Crisp Dark Header */}
      <section className="bg-architectural-grid-dark relative overflow-hidden bg-[var(--roof-obsidian)] py-10 text-white sm:py-14">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-24 left-12 h-64 w-64 rounded-full bg-[var(--roof-copper)]/20 blur-[100px]"
        />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Link
            to="/"
            hash="services"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-white/75 transition-colors hover:text-white"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Back to Roofing Services & Estimate Form</span>
          </Link>

          <div className="mt-4 flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-bold tracking-wider text-[var(--roof-amber-light)] uppercase">
                <Sparkles className="h-3.5 w-3.5" />
                <span>{plan.badge}</span>
              </span>
              <h1 className="font-display mt-3 text-3xl font-extrabold text-white sm:text-4xl">
                {plan.title}
              </h1>
              <p className="mt-2 max-w-2xl text-sm leading-relaxed text-white/75 sm:text-base">
                {plan.description}
              </p>
            </div>

            <div className="shrink-0 rounded-2xl border border-white/15 bg-white/[0.06] px-5 py-3.5 text-left backdrop-blur-md lg:text-right">
              <div className="text-[11px] font-semibold tracking-wider text-white/60 uppercase">
                Transparent Total
              </div>
              <div className="font-mono-num text-3xl font-extrabold text-[var(--roof-copper-light)]">
                ${plan.priceUsd} <span className="text-sm font-semibold text-white/70">USD</span>
              </div>
              <div className="mt-0.5 text-xs text-emerald-300">{plan.billingLabel}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Split Checkout Section */}
      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
        <div className="grid items-start gap-8 lg:grid-cols-12">
          {/* Left Deliverables & Other Plans */}
          <div className="space-y-5 lg:col-span-5">
            <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-[var(--roof-obsidian)] to-[var(--roof-midnight)] p-6 text-white shadow-xl">
              <div className="flex items-center justify-between border-b border-white/15 pb-3">
                <span className="font-display text-sm font-bold">Included Deliverables</span>
                <span className="font-mono-num rounded-full bg-[var(--roof-copper)]/25 px-2.5 py-0.5 text-xs font-bold text-[var(--roof-copper-pale)]">
                  ${plan.priceUsd} USD
                </span>
              </div>
              <ul className="mt-4 space-y-3 text-sm text-white/85">
                {plan.deliverables.map((item) => (
                  <li key={item} className="flex items-start gap-2.5">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.05] p-3.5 text-xs text-white/75">
                <div className="flex items-center gap-1.5 font-semibold text-emerald-300">
                  <ShieldCheck className="h-4 w-4" />
                  <span>PCI-Isolated Whop Checkout</span>
                </div>
                <p className="mt-1 leading-relaxed text-white/65">
                  Apple Pay, Google Pay, major cards, Klarna, Afterpay, and Splitit installments
                  surface automatically when supported.
                </p>
              </div>
            </div>

            {/* Switch to other plans */}
            <div className="rounded-3xl border border-[var(--roof-border)] bg-white p-5 shadow-xs">
              <div className="flex items-center gap-2 text-xs font-bold tracking-wider text-[#4B5563] uppercase">
                <Wallet className="h-3.5 w-3.5 text-[var(--roof-copper)]" />
                <span>Need a Different Service Tier?</span>
              </div>
              <div className="mt-3 space-y-2">
                {(['inspection', 'deposit', 'tuneup'] as const)
                  .filter((k) => k !== planKey)
                  .map((otherKey) => {
                    const other = roofingTemplate.plans[otherKey]
                    const targetPath =
                      otherKey === 'deposit'
                        ? { to: '/deposit' as const }
                        : {
                            to: '/book/$slug' as const,
                            params: { slug: otherKey === 'tuneup' ? 'tune-up' : 'inspection' },
                          }
                    return (
                      <Link
                        key={otherKey}
                        {...targetPath}
                        className="flex items-center justify-between gap-2 rounded-2xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/70 p-3.5 text-xs transition-all hover:border-[var(--roof-copper)] hover:bg-white"
                      >
                        <div>
                          <div className="font-bold text-[var(--roof-ink)]">{other.title}</div>
                          <div className="text-[11px] text-[#6B7280]">{other.billingLabel}</div>
                        </div>
                        <span className="font-mono-num inline-flex shrink-0 items-center gap-1 font-extrabold text-[var(--roof-copper-deep)]">
                          ${other.priceUsd}
                          <ArrowRight className="h-3.5 w-3.5" />
                        </span>
                      </Link>
                    )
                  })}
              </div>
            </div>
          </div>

          {/* Right Checkout Elements Card */}
          <div className="lg:col-span-7">
            <WhopCheckoutFlow planKey={planKey} />
          </div>
        </div>
      </main>

      <Footer />
      <PixelDebugPill />
    </div>
  )
}
