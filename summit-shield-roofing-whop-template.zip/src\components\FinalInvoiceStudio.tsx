import { useCallback, useEffect, useState } from 'react'
import { Link } from '@tanstack/react-router'
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  ExternalLink,
  FileDown,
  KeyRound,
  Loader2,
  Lock,
  ReceiptText,
  RefreshCw,
  Send,
  ShieldCheck,
  Trash2,
  Zap,
} from 'lucide-react'
import { roofingTemplate } from '#/config/roofingTemplate'
import type {
  InvoiceRecordSummary,
  PublicRuntimeConfig,
  VaultedCustomerRecord,
} from '#/lib/types'

interface FinalInvoiceStudioProps {
  vaultedCustomer: VaultedCustomerRecord | null
  runtimeConfig: PublicRuntimeConfig | null
  onOpenPortal: () => void
}

const PUBLIC_LIFECYCLE_STEPS = [
  {
    step: '01',
    title: 'Deposit or Card Authorization',
    detail: `Start with a $${roofingTemplate.plans.inspection.priceUsd} diagnostic inspection or $${roofingTemplate.plans.deposit.priceUsd} scheduling deposit — credited 100% toward your project total.`,
  },
  {
    step: '02',
    title: 'Roof Installation & Walkthrough',
    detail:
      'In-house W-2 installers complete tear-off, synthetic underlayment, flashing, magnetic nail sweep, and photo review.',
  },
  {
    step: '03',
    title: 'Net Final Balance Settlement',
    detail:
      'Settle the remaining job balance securely via your authorized payment method or an emailed digital invoice + PDF receipt.',
  },
]

export function FinalInvoiceStudio({
  vaultedCustomer,
  runtimeConfig,
  onOpenPortal,
}: FinalInvoiceStudioProps) {
  const presets = roofingTemplate.invoiceFlowPresets
  const adminAuthenticated = Boolean(runtimeConfig?.adminAuthenticated)
  const environmentMode = runtimeConfig?.environment ?? 'production'

  const [selectedPresetId, setSelectedPresetId] = useState(presets[0].id)
  const [amountUsd, setAmountUsd] = useState(String(presets[0].finalBalanceUsd))
  const [lineTitle, setLineTitle] = useState(presets[0].lineTitle)
  const [jobReference, setJobReference] = useState(presets[0].jobReference)
  const [memo, setMemo] = useState(presets[0].memo)

  const [memberId, setMemberId] = useState('')
  const [paymentMethodId, setPaymentMethodId] = useState('')
  const [emailAddress, setEmailAddress] = useState('')
  const [customerName, setCustomerName] = useState('')

  const [submittingMode, setSubmittingMode] = useState<'auto_charge' | 'send_manual' | null>(null)
  const [voidingId, setVoidingId] = useState<string | null>(null)
  const [refreshing, setRefreshing] = useState(false)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)
  const [latestInvoice, setLatestInvoice] = useState<InvoiceRecordSummary | null>(null)
  const [recentInvoices, setRecentInvoices] = useState<InvoiceRecordSummary[]>([])

  useEffect(() => {
    if (!adminAuthenticated || !vaultedCustomer) return
    if (vaultedCustomer.memberId) setMemberId(vaultedCustomer.memberId)
    if (vaultedCustomer.paymentMethodId) setPaymentMethodId(vaultedCustomer.paymentMethodId)
    if (vaultedCustomer.email) setEmailAddress(vaultedCustomer.email)
    if (vaultedCustomer.customerName) setCustomerName(vaultedCustomer.customerName)
  }, [adminAuthenticated, vaultedCustomer])

  const applyPreset = (presetId: string) => {
    const found = presets.find((p) => p.id === presetId)
    if (!found) return
    setSelectedPresetId(found.id)
    setAmountUsd(String(found.finalBalanceUsd))
    setLineTitle(found.lineTitle)
    setJobReference(found.jobReference)
    setMemo(found.memo)
  }

  const formatMoneyField = (obj?: { formatted?: string; amount?: number | string }): string => {
    if (obj?.formatted) return obj.formatted
    if (obj?.amount != null) {
      const n = Number(obj.amount)
      if (Number.isFinite(n)) {
        return `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
      }
      return `$${obj.amount}`
    }
    return '—'
  }

  const normalizeInvoiceSummary = useCallback(
    (
      raw: Record<string, unknown>,
      pdfUrl?: string | null,
      verificationWarning?: string | null,
    ): InvoiceRecordSummary => {
      const totalObj = raw.total as { formatted?: string; amount?: number | string } | undefined
      const dueObj = raw.amount_due as { formatted?: string; amount?: number | string } | undefined
      return {
        id: String(raw.id ?? ''),
        number: String(raw.number ?? raw.id ?? ''),
        status: String(raw.status ?? 'open'),
        totalFormatted: formatMoneyField(totalObj),
        amountDueFormatted: formatMoneyField(dueObj),
        checkoutLink: typeof raw.checkout_link === 'string' ? raw.checkout_link : null,
        memberId: typeof raw.member_id === 'string' ? raw.member_id : null,
        paymentMethodId: typeof raw.payment_method_id === 'string' ? raw.payment_method_id : null,
        emailAddress: typeof raw.email_address === 'string' ? raw.email_address : null,
        customerName: typeof raw.customer_name === 'string' ? raw.customer_name : null,
        createdAt: String(raw.created_at ?? ''),
        dueAt: typeof raw.due_at === 'string' ? raw.due_at : null,
        pdfUrl: pdfUrl ?? null,
        verificationWarning: verificationWarning ?? null,
      }
    },
    [],
  )

  useEffect(() => {
    if (!adminAuthenticated || !runtimeConfig?.configured) {
      setRecentInvoices([])
      setLatestInvoice(null)
      if (!adminAuthenticated) {
        setMemberId('')
        setPaymentMethodId('')
        setEmailAddress('')
        setCustomerName('')
      }
      return
    }
    let active = true
    fetch(`/api/invoices?mode=${environmentMode}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { invoices?: Record<string, unknown>[] } | null) => {
        if (active && Array.isArray(data?.invoices)) {
          setRecentInvoices(data.invoices.map((item) => normalizeInvoiceSummary(item)))
        }
      })
      .catch(() => {})
    return () => {
      active = false
    }
  }, [adminAuthenticated, runtimeConfig?.configured, environmentMode, normalizeInvoiceSummary])

  const fetchLatestWhopRecords = async () => {
    if (!adminAuthenticated) return
    setRefreshing(true)
    setErrorMsg(null)
    try {
      const [invRes, setupRes] = await Promise.all([
        fetch(`/api/invoices?mode=${environmentMode}`),
        fetch(`/api/setup-intents?mode=${environmentMode}`),
      ])
      if (invRes.ok) {
        const invData = (await invRes.json()) as { invoices?: Record<string, unknown>[] }
        if (Array.isArray(invData.invoices)) {
          setRecentInvoices(invData.invoices.map((item) => normalizeInvoiceSummary(item)))
        }
      } else {
        const errData = (await invRes.json().catch(() => null)) as { message?: string } | null
        if (errData?.message) setErrorMsg(errData.message)
      }

      if (setupRes.ok && (!memberId || !paymentMethodId)) {
        const setupData = (await setupRes.json()) as {
          setupIntents?: Array<{
            id: string
            status: string
            member_id: string | null
            payment_method_id: string | null
            user?: { email?: string | null; name?: string | null } | null
          }>
          vaultedPayments?: Array<{
            id: string
            status: string
            member_id: string | null
            payment_method_id: string | null
            customer_email?: string | null
            user?: { email?: string | null; name?: string | null } | null
          }>
        }
        const latestSetup = setupData.setupIntents?.find(
          (s) => s.status === 'succeeded' && s.payment_method_id && s.member_id,
        )
        const latestPay = setupData.vaultedPayments?.find(
          (p) => p.payment_method_id && p.member_id,
        )
        const target = latestSetup ?? latestPay
        if (target) {
          setMemberId(target.member_id ?? '')
          setPaymentMethodId(target.payment_method_id ?? '')
          if (target.user?.email) setEmailAddress(target.user.email)
          else if (latestPay?.customer_email) setEmailAddress(latestPay.customer_email)
          if (target.user?.name) setCustomerName(target.user.name)
        }
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to sync Whop invoices.')
    } finally {
      setRefreshing(false)
    }
  }

  const submitInvoice = async (mode: 'auto_charge' | 'send_manual') => {
    if (!adminAuthenticated) return
    setErrorMsg(null)
    setSubmittingMode(mode)

    try {
      const res = await fetch('/api/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: mode,
          environmentMode,
          memberId: memberId.trim() || undefined,
          paymentMethodId: mode === 'auto_charge' ? paymentMethodId.trim() : undefined,
          emailAddress: emailAddress.trim() || undefined,
          customerName: customerName.trim() || undefined,
          amountUsd: Number(amountUsd),
          lineTitle: lineTitle.trim(),
          jobReference: jobReference.trim(),
          memo: memo.trim(),
          dueDays: 7,
        }),
      })

      const data = (await res.json()) as {
        ok?: boolean
        message?: string
        warning?: string | null
        invoice?: Record<string, unknown>
        pdfUrl?: string | null
      }

      if (!res.ok || !data.invoice) {
        throw new Error(data.message || 'Whop invoice creation failed.')
      }

      const summary = normalizeInvoiceSummary(data.invoice, data.pdfUrl, data.warning)
      setLatestInvoice(summary)
      setRecentInvoices((prev) => [summary, ...prev.filter((item) => item.id !== summary.id)])
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to create Whop invoice.')
    } finally {
      setSubmittingMode(null)
    }
  }

  const handleVoidInvoice = async (invoiceId: string) => {
    if (!adminAuthenticated) return
    setVoidingId(invoiceId)
    setErrorMsg(null)
    try {
      const res = await fetch('/api/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'void',
          invoiceId,
          environmentMode,
        }),
      })
      const data = (await res.json()) as { ok?: boolean; message?: string }
      if (!res.ok || !data.ok) {
        throw new Error(data.message || 'Unable to void invoice.')
      }
      setRecentInvoices((prev) =>
        prev.map((inv) => (inv.id === invoiceId ? { ...inv, status: 'void' } : inv)),
      )
      if (latestInvoice?.id === invoiceId) {
        setLatestInvoice((prev) => (prev ? { ...prev, status: 'void' } : prev))
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to void invoice.')
    } finally {
      setVoidingId(null)
    }
  }

  const activePreset = presets.find((p) => p.id === selectedPresetId) ?? presets[0]
  const depositCredited = activePreset.depositCreditedUsd
  const parsedAmount = Number(amountUsd) || 0
  const grossDerived = parsedAmount + depositCredited

  // PUBLIC HOMEOWNER VIEW (Zero API calls, zero PII, zero internal IDs)
  if (!adminAuthenticated) {
    return (
      <section
        id="invoice-flow"
        className="border-b border-[var(--roof-border)] bg-white py-14 sm:py-20"
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 rounded-full border border-emerald-300/60 bg-emerald-50 px-3.5 py-1 text-xs font-bold tracking-wider text-emerald-800 uppercase">
                <ReceiptText className="h-3.5 w-3.5 text-emerald-600" />
                <span>Step 3 · Deposit-to-Closing Balance Billing</span>
              </div>
              <h2 className="font-display mt-3 text-3xl font-extrabold text-[var(--roof-ink)] sm:text-4xl">
                Pay Only a Small Deposit Upfront. Settle Your Net Balance After Inspection.
              </h2>
              <p className="mt-3 text-base text-[#4B5563]">
                We never demand 100% upfront for residential roof work. Every $
                {roofingTemplate.plans.inspection.priceUsd} diagnostic check and $
                {roofingTemplate.plans.deposit.priceUsd} scheduling deposit is credited in full on
                your itemized closing invoice.
              </p>
            </div>

            <Link
              to="/deposit"
              className="btn-shimmer inline-flex min-h-11 shrink-0 items-center gap-2 rounded-xl bg-gradient-to-r from-[var(--roof-copper)] to-[var(--roof-amber)] px-5 py-2.5 text-sm font-bold text-white shadow-sm transition-all hover:-translate-y-0.5"
            >
              <span>Start ${roofingTemplate.plans.deposit.priceUsd} Deposit &amp; Card Setup</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          {/* Transparent Deposit-to-Final Sample Math Bar */}
          <div className="mt-8 grid gap-3 rounded-2xl border border-[var(--roof-border)] bg-gradient-to-r from-[var(--roof-obsidian)] via-[var(--roof-midnight)] to-[var(--roof-obsidian)] p-4 text-white shadow-md sm:grid-cols-3">
            <div className="rounded-xl bg-white/[0.06] px-4 py-3">
              <div className="text-[11px] font-semibold tracking-wider text-white/60 uppercase">
                Sample Approved Roof Scope
              </div>
              <div className="font-mono-num mt-0.5 text-lg font-bold text-white">
                ${activePreset.grossJobTotalUsd.toLocaleString()}
              </div>
            </div>
            <div className="rounded-xl border border-emerald-400/25 bg-emerald-500/12 px-4 py-3">
              <div className="text-[11px] font-semibold tracking-wider text-emerald-300 uppercase">
                − Credited Scheduling Deposit
              </div>
              <div className="font-mono-num mt-0.5 text-lg font-bold text-emerald-300">
                −${depositCredited.toLocaleString()}
              </div>
            </div>
            <div className="rounded-xl border border-[var(--roof-copper-light)]/35 bg-[var(--roof-copper)]/18 px-4 py-3">
              <div className="text-[11px] font-semibold tracking-wider text-[var(--roof-copper-pale)] uppercase">
                = Due Upon Completion
              </div>
              <div className="font-mono-num mt-0.5 text-lg font-extrabold text-[var(--roof-copper-light)]">
                ${activePreset.finalBalanceUsd.toLocaleString()} USD
              </div>
            </div>
          </div>

          {/* 3-Step Clean Homeowner Cards */}
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {PUBLIC_LIFECYCLE_STEPS.map((item) => (
              <div
                key={item.step}
                className="flex flex-col justify-between rounded-3xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/75 p-6 shadow-2xs transition-all hover:-translate-y-1 hover:bg-white hover:shadow-md"
              >
                <div>
                  <span className="font-mono-num inline-flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-[var(--roof-copper)] to-[var(--roof-amber)] text-xs font-extrabold text-white">
                    {item.step}
                  </span>
                  <h3 className="font-display mt-4 text-lg font-bold text-[var(--roof-ink)]">
                    {item.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-[#4B5563]">{item.detail}</p>
                </div>
                <div className="mt-5 flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
                  <ShieldCheck className="h-4 w-4" />
                  <span>Protected Closing Process</span>
                </div>
              </div>
            ))}
          </div>

          {/* Unobtrusive Live Demo + Contractor Access Bar */}
          <div className="mt-8 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-[var(--roof-border)] bg-[var(--roof-canvas)] px-5 py-4 text-xs text-[#4B5563]">
            <span>
              Complete a deposit checkout (including instant{' '}
              <code className="font-mono-num font-bold">4242</code> Sandbox card testing) to unlock
              interactive <strong>Whop Invoices API</strong> billing right on your confirmation page,
              or manage all jobs in the Contractor Portal.
            </span>
            <div className="flex flex-wrap items-center gap-2">
              <Link
                to="/deposit"
                className="inline-flex min-h-9 shrink-0 items-center gap-1.5 rounded-xl bg-[var(--roof-ink)] px-3.5 py-2 text-xs font-bold text-white transition-colors hover:bg-[var(--roof-copper)]"
              >
                <span>Test Deposit → Invoice Flow</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
              <button
                type="button"
                onClick={onOpenPortal}
                className="inline-flex min-h-9 shrink-0 items-center gap-1.5 rounded-xl border border-[var(--roof-ink)]/20 bg-white px-3.5 py-2 text-xs font-bold text-[var(--roof-ink)] shadow-2xs transition-colors hover:border-[var(--roof-copper)] hover:text-[var(--roof-copper)]"
              >
                <Lock className="h-3.5 w-3.5 text-[var(--roof-copper)]" />
                <span>Contractor Portal</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    )
  }

  // AUTHENTICATED CONTRACTOR INVOICE STUDIO VIEW
  return (
    <section
      id="invoice-flow"
      className="border-b border-[var(--roof-border)] bg-white py-14 sm:py-20"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-emerald-300/60 bg-emerald-50 px-3.5 py-1 text-xs font-bold tracking-wider text-emerald-800 uppercase">
              <ReceiptText className="h-3.5 w-3.5 text-emerald-600" />
              <span>
                Step 3 · Final Balance Billing Studio ({environmentMode.toUpperCase()})
              </span>
            </div>
            <h2 className="font-display mt-3 text-3xl font-extrabold text-[var(--roof-ink)] sm:text-4xl">
              Auto-Charge Card-on-File or Send a Hosted Final Balance Invoice.
            </h2>
            <p className="mt-3 text-base text-[#4B5563]">
              Issue native Whop Invoices to auto-charge a vaulted card off-session or send a hosted
              checkout link & downloadable PDF.
            </p>
          </div>

          <button
            type="button"
            onClick={fetchLatestWhopRecords}
            disabled={refreshing}
            className="inline-flex min-h-11 shrink-0 items-center gap-2 rounded-xl border border-[var(--roof-border)] bg-[var(--roof-canvas)] px-4 py-2.5 text-sm font-semibold text-[var(--roof-ink)] transition-all hover:-translate-y-0.5 hover:border-[var(--roof-ink)] hover:shadow-xs"
          >
            <RefreshCw className={`h-4 w-4 text-[var(--roof-copper)] ${refreshing ? 'animate-spin' : ''}`} />
            <span>Sync Live Invoices & Vault</span>
          </button>
        </div>

        {/* Visual Deposit-to-Final Math Bar */}
        <div className="mt-8 grid gap-3 rounded-2xl border border-[var(--roof-border)] bg-gradient-to-r from-[var(--roof-obsidian)] via-[var(--roof-midnight)] to-[var(--roof-obsidian)] p-4 text-white shadow-md sm:grid-cols-3">
          <div className="rounded-xl bg-white/[0.06] px-4 py-3">
            <div className="text-[11px] font-semibold tracking-wider text-white/60 uppercase">
              Total Job Value
            </div>
            <div className="font-mono-num mt-0.5 text-lg font-bold text-white">
              ${grossDerived.toLocaleString()}
            </div>
          </div>
          <div className="rounded-xl border border-emerald-400/25 bg-emerald-500/12 px-4 py-3">
            <div className="text-[11px] font-semibold tracking-wider text-emerald-300 uppercase">
              − Deposit Credited (Step 1)
            </div>
            <div className="font-mono-num mt-0.5 text-lg font-bold text-emerald-300">
              −${depositCredited.toLocaleString()}
            </div>
          </div>
          <div className="rounded-xl border border-[var(--roof-copper-light)]/35 bg-[var(--roof-copper)]/18 px-4 py-3">
            <div className="text-[11px] font-semibold tracking-wider text-[var(--roof-copper-pale)] uppercase">
              = Net Final Whop Invoice
            </div>
            <div className="font-mono-num mt-0.5 text-lg font-extrabold text-[var(--roof-copper-light)]">
              ${parsedAmount.toLocaleString()} USD
            </div>
          </div>
        </div>

        <div className="mt-6 grid items-start gap-8 lg:grid-cols-12">
          {/* Left column: Invoice Composer */}
          <div className="rounded-3xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/85 p-6 shadow-xs lg:col-span-7">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-display text-lg font-bold text-[#111827]">
                Final Balance Invoice Composer
              </h3>
              <span
                className={`font-mono-num inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold shadow-2xs ${
                  environmentMode === 'sandbox'
                    ? 'border border-amber-300 bg-amber-50 text-amber-900'
                    : 'bg-white text-[#111827]'
                }`}
              >
                <span
                  className={`h-2 w-2 rounded-full ${
                    environmentMode === 'sandbox'
                      ? 'bg-amber-500'
                      : runtimeConfig?.configured
                        ? 'bg-emerald-500'
                        : 'bg-amber-500'
                  }`}
                />
                {environmentMode === 'sandbox' ? 'Sandbox API Active' : 'Live API Mode'}
              </span>
            </div>

            {/* Scope presets */}
            <div className="mt-4">
              <div className="text-xs font-bold tracking-wider text-[#4B5563] uppercase">
                Quick Roofing Job Closeout Presets
              </div>
              <div className="mt-2 grid gap-2 sm:grid-cols-3">
                {presets.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => applyPreset(preset.id)}
                    className={`rounded-2xl border p-3 text-left text-xs transition-all duration-200 hover:-translate-y-0.5 ${
                      selectedPresetId === preset.id
                        ? 'border-[var(--roof-copper)] bg-white shadow-sm ring-1 ring-[var(--roof-copper)]'
                        : 'border-[var(--roof-border)] bg-white/75 hover:bg-white'
                    }`}
                  >
                    <div className="font-bold text-[var(--roof-ink)]">{preset.label}</div>
                    <div className="font-mono-num mt-1 text-[11px] text-[#6B7280]">
                      ${preset.grossJobTotalUsd.toLocaleString()} − ${preset.depositCreditedUsd}{' '}
                      deposit
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Balance inputs */}
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div>
                <label
                  htmlFor="invoice-amount"
                  className="block text-xs font-bold text-[#374151]"
                >
                  Final Balance Amount (USD)
                </label>
                <div className="relative mt-1.5">
                  <span className="font-mono-num pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-sm font-bold text-[var(--roof-copper)]">
                    $
                  </span>
                  <input
                    id="invoice-amount"
                    type="number"
                    min="1"
                    step="0.01"
                    value={amountUsd}
                    onChange={(e) => setAmountUsd(e.target.value)}
                    className="font-mono-num min-h-11 w-full rounded-xl border border-[var(--roof-border)] bg-white py-2.5 pr-3 pl-7 text-sm font-bold text-[var(--roof-ink)] transition-all focus:border-[var(--roof-copper)] focus:ring-2 focus:ring-[var(--roof-copper)]/15"
                  />
                </div>
                <p className="mt-1 text-[11px] text-[#6B7280]">
                  Default presets fit standard limits (&le;$2,500); verified accounts bill higher
                  totals seamlessly.
                </p>
              </div>

              <div>
                <label htmlFor="invoice-ref" className="block text-xs font-bold text-[#374151]">
                  Job Reference / Scope ID
                </label>
                <input
                  id="invoice-ref"
                  type="text"
                  value={jobReference}
                  onChange={(e) => setJobReference(e.target.value)}
                  className="mt-1.5 min-h-11 w-full rounded-xl border border-[var(--roof-border)] bg-white px-3 py-2.5 text-sm text-[var(--roof-ink)] transition-all focus:border-[var(--roof-copper)] focus:ring-2 focus:ring-[var(--roof-copper)]/15"
                />
              </div>

              <div className="sm:col-span-2">
                <label
                  htmlFor="invoice-title"
                  className="block text-xs font-bold text-[#374151]"
                >
                  Invoice Line Item Title
                </label>
                <input
                  id="invoice-title"
                  type="text"
                  value={lineTitle}
                  onChange={(e) => setLineTitle(e.target.value)}
                  className="mt-1.5 min-h-11 w-full rounded-xl border border-[var(--roof-border)] bg-white px-3 py-2.5 text-sm text-[var(--roof-ink)] transition-all focus:border-[var(--roof-copper)] focus:ring-2 focus:ring-[var(--roof-copper)]/15"
                />
              </div>
            </div>

            {/* Homeowner Vaulted Card Credentials */}
            <div className="mt-5 rounded-2xl border border-[var(--roof-border)] bg-white p-4">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--roof-surface)] pb-2.5">
                <div className="flex items-center gap-1.5 text-xs font-bold tracking-wider text-emerald-800 uppercase">
                  <KeyRound className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Vaulted Customer Target (From Setup / Deposit)</span>
                </div>
                {vaultedCustomer?.sourceId && (
                  <span className="font-mono-num rounded-full bg-emerald-500/15 px-2.5 py-0.5 text-[11px] font-bold text-emerald-800">
                    Synced from {vaultedCustomer.sourceId}
                  </span>
                )}
              </div>

              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <div>
                  <label htmlFor="inv-member-id" className="block text-[11px] font-semibold text-[#4B5563]">
                    Whop Member ID (<code className="font-mono-num">mber_...</code>) — Auto-Charge
                  </label>
                  <input
                    id="inv-member-id"
                    type="text"
                    placeholder="mber_xxxxxxxxxxxxx"
                    value={memberId}
                    onChange={(e) => setMemberId(e.target.value)}
                    className="font-mono-num mt-1 min-h-10 w-full rounded-xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/60 px-3 text-xs text-[var(--roof-ink)] focus:border-[var(--roof-copper)]"
                  />
                </div>
                <div>
                  <label htmlFor="inv-pm-id" className="block text-[11px] font-semibold text-[#4B5563]">
                    Saved Method (<code className="font-mono-num">payt_...</code>) — Vaulted Card
                  </label>
                  <input
                    id="inv-pm-id"
                    type="text"
                    placeholder="payt_xxxxxxxxxxxxx"
                    value={paymentMethodId}
                    onChange={(e) => setPaymentMethodId(e.target.value)}
                    className="font-mono-num mt-1 min-h-10 w-full rounded-xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/60 px-3 text-xs text-[var(--roof-ink)] focus:border-[var(--roof-copper)]"
                  />
                </div>
                <div>
                  <label htmlFor="inv-email" className="block text-[11px] font-semibold text-[#4B5563]">
                    Homeowner Email — Manual Invoice Send
                  </label>
                  <input
                    id="inv-email"
                    type="email"
                    placeholder={roofingTemplate.formPlaceholders.email}
                    value={emailAddress}
                    onChange={(e) => setEmailAddress(e.target.value)}
                    className="mt-1 min-h-10 w-full rounded-xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/60 px-3 text-xs text-[var(--roof-ink)] focus:border-[var(--roof-copper)]"
                  />
                </div>
                <div>
                  <label htmlFor="inv-name" className="block text-[11px] font-semibold text-[#4B5563]">
                    Homeowner Name (Optional)
                  </label>
                  <input
                    id="inv-name"
                    type="text"
                    placeholder={roofingTemplate.formPlaceholders.invoiceCustomerName}
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="mt-1 min-h-10 w-full rounded-xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/60 px-3 text-xs text-[var(--roof-ink)] focus:border-[var(--roof-copper)]"
                  />
                </div>
              </div>
            </div>

            {errorMsg && (
              <div
                role="alert"
                className="mt-4 flex items-start gap-2.5 rounded-2xl border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-900"
              >
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* 2 Billing Execution Buttons */}
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                disabled={submittingMode !== null}
                onClick={() => submitInvoice('auto_charge')}
                className="btn-shimmer inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-700 to-teal-600 px-4 py-3 text-sm font-bold text-white shadow-md transition-all hover:-translate-y-0.5 disabled:opacity-55"
              >
                {submittingMode === 'auto_charge' ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Zap className="h-4 w-4" />
                )}
                <span>Issue & Auto-Charge Saved Card</span>
              </button>

              <button
                type="button"
                disabled={submittingMode !== null}
                onClick={() => submitInvoice('send_manual')}
                className="btn-shimmer inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[var(--roof-ink)] to-[#1F2937] px-4 py-3 text-sm font-bold text-white shadow-md transition-all hover:-translate-y-0.5 hover:from-[var(--roof-copper)] hover:to-[var(--roof-amber)] disabled:opacity-55"
              >
                {submittingMode === 'send_manual' ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
                <span>Send Manual Invoice + Pay Link</span>
              </button>
            </div>
          </div>

          {/* Right column: Receipt / Live Whop Invoices Ledger */}
          <div className="space-y-4 lg:col-span-5">
            {latestInvoice && (
              <div className="rounded-3xl border border-emerald-400/50 bg-gradient-to-br from-emerald-50 to-white p-6 shadow-md">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 font-bold text-emerald-800">
                    <CheckCircle2 className="h-5 w-5 text-emerald-600" />
                    <span>Invoice {latestInvoice.number} Created</span>
                  </div>
                  <span className="font-mono-num rounded-full border border-emerald-300 bg-white px-2.5 py-1 text-xs font-bold text-[#111827] uppercase">
                    {latestInvoice.status}
                  </span>
                </div>

                <dl className="font-mono-num mt-4 grid grid-cols-2 gap-3 text-xs">
                  <div className="rounded-xl border border-emerald-200/70 bg-white p-3">
                    <dt className="text-[#6B7280]">Invoice ID</dt>
                    <dd className="mt-0.5 font-semibold break-all text-[#111827]">
                      {latestInvoice.id}
                    </dd>
                  </div>
                  <div className="rounded-lg bg-white p-3">
                    <dt className="text-[#6B7280]">Final Total</dt>
                    <dd className="mt-0.5 text-base font-bold text-[#C2491D]">
                      {latestInvoice.totalFormatted}
                    </dd>
                  </div>
                </dl>

                <div className="mt-4 flex flex-wrap gap-2.5">
                  {latestInvoice.checkoutLink && (
                    <a
                      href={latestInvoice.checkoutLink}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex min-h-10 items-center gap-1.5 rounded-lg bg-[#C2491D] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#9E3712]"
                    >
                      <span>Open Hosted Pay Link</span>
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  )}
                  {latestInvoice.pdfUrl && (
                    <a
                      href={latestInvoice.pdfUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-[#D8D1C4] bg-white px-3.5 py-2 text-xs font-semibold text-[#141A21] hover:border-[#141A21]"
                    >
                      <FileDown className="h-3.5 w-3.5 text-[#C2491D]" />
                      <span>Download PDF</span>
                    </a>
                  )}
                </div>

                {latestInvoice.verificationWarning && (
                  <div className="mt-4 rounded-xl border border-amber-300 bg-amber-50 p-3 text-xs leading-relaxed text-amber-950">
                    <strong>Draft Invoice Created ({latestInvoice.id}):</strong>{' '}
                    {environmentMode === 'sandbox'
                      ? `${latestInvoice.verificationWarning}. Your Sandbox invoice draft & PDF receipt were created live; full off-session invoice auto-collection requires payout verification on the Whop account.`
                      : `${latestInvoice.verificationWarning}. Complete business KYC verification or switch to Portal → Sandbox Card (4242) to test instant card settlement.`}
                  </div>
                )}
              </div>
            )}

            {/* Ledger List */}
            <div className="rounded-2xl border border-[#D8D1C4] bg-[#F6F4EF]/65 p-5">
              <div className="flex items-center justify-between border-b border-[#D8D1C4] pb-3">
                <h3 className="font-display text-sm font-bold text-[#141A21]">
                  Recent Invoices ({environmentMode})
                </h3>
                <span className="font-mono-num text-xs text-[#4B5563]">
                  {recentInvoices.length} shown
                </span>
              </div>

              {recentInvoices.length === 0 ? (
                <p className="mt-4 text-xs leading-relaxed text-[#4B5563]">
                  Click <strong>Sync Live Invoices & Vault</strong> above or issue a balance
                  invoice to view live records from your Whop account.
                </p>
              ) : (
                <div className="mt-4 space-y-2.5">
                  {recentInvoices.slice(0, 6).map((inv) => {
                    const canVoid = inv.status === 'draft' || inv.status === 'open'
                    return (
                      <div
                        key={inv.id}
                        className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#D8D1C4] bg-white p-3 text-xs"
                      >
                        <div>
                          <div className="font-mono-num font-bold text-[#141A21]">
                            {inv.number} · {inv.totalFormatted}
                          </div>
                          <div className="mt-0.5 text-[#6B7280]">
                            {inv.emailAddress || inv.memberId || inv.id}
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono-num rounded bg-[#EDE9DF] px-2 py-0.5 text-[11px] font-semibold text-[#141A21] uppercase">
                            {inv.status}
                          </span>
                          {inv.checkoutLink && inv.status !== 'void' && (
                            <a
                              href={inv.checkoutLink}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex h-8 items-center gap-1 rounded bg-[#141A21] px-2.5 text-[11px] font-semibold text-white hover:bg-[#C2491D]"
                            >
                              <span>Pay</span>
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          )}
                          {canVoid && (
                            <button
                              type="button"
                              onClick={() => handleVoidInvoice(inv.id)}
                              disabled={voidingId === inv.id}
                              title="Void draft/open invoice"
                              className="inline-flex h-8 items-center justify-center rounded border border-red-200 bg-red-50 px-2 text-red-700 hover:bg-red-100 disabled:opacity-50"
                            >
                              {voidingId === inv.id ? (
                                <Loader2 className="h-3 w-3 animate-spin" />
                              ) : (
                                <Trash2 className="h-3 w-3" />
                              )}
                            </button>
                          )}
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
