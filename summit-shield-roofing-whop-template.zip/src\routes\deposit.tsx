import { createFileRoute, Link } from '@tanstack/react-router'
import { useEffect } from 'react'
import {
  ArrowLeft,
  CheckCircle2,
  KeyRound,
  ReceiptText,
  ShieldCheck,
} from 'lucide-react'
import { Footer } from '#/components/Footer'
import { Navbar } from '#/components/Navbar'
import { PixelDebugPill } from '#/components/PixelDebugPill'
import { WhopCheckoutFlow } from '#/components/WhopCheckoutFlow'
import { roofingTemplate } from '#/config/roofingTemplate'
import { trackWhopEvent } from '#/lib/whopPixel'

export const Route = createFileRoute('/deposit')({
  component: DepositCheckoutPage,
})

function DepositCheckoutPage() {
  const plan = roofingTemplate.plans.deposit

  useEffect(() => {
    trackWhopEvent('view_content', {
      content_id: 'deposit',
      content_name: plan.title,
      value: plan.priceUsd,
      currency: 'USD',
      route: '/deposit',
    })
    trackWhopEvent('service_viewed', {
      service_id: 'deposit',
      service_title: plan.title,
      price_usd: plan.priceUsd,
      source: 'deposit_route',
    })
    trackWhopEvent('deposit_started', {
      plan_key: 'deposit',
      amount_usd: plan.priceUsd,
      vaults_card_on_file: true,
      source: 'deposit_route_entry',
    })
  }, [plan.title, plan.priceUsd])

  return (
    <div className="min-h-screen bg-[var(--roof-canvas)] text-[var(--roof-ink)]">
      <Navbar />

      <section className="bg-architectural-grid-dark relative overflow-hidden bg-[var(--roof-obsidian)] py-10 text-white sm:py-14">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-24 right-12 h-72 w-72 rounded-full bg-emerald-500/18 blur-[120px]"
        />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Link
            to="/"
            hash="checkout-flow"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-white/75 transition-colors hover:text-white"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Back to All Roofing Plans</span>
          </Link>

          <div className="mt-4 flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/35 bg-emerald-500/15 px-3 py-1 text-xs font-bold tracking-wider text-emerald-300 uppercase">
                <KeyRound className="h-3.5 w-3.5" />
                <span>Step 1 · Deposit + Card-on-File via SetupIntent</span>
              </span>
              <h1 className="font-display mt-3 text-3xl font-extrabold text-white sm:text-4xl">
                {plan.title} (${plan.priceUsd})
              </h1>
              <p className="mt-2 max-w-2xl text-sm leading-relaxed text-white/75 sm:text-base">
                {plan.description}
              </p>
            </div>

            <div className="shrink-0 rounded-2xl border border-white/15 bg-white/[0.06] px-5 py-3.5 backdrop-blur-md lg:text-right">
              <div className="text-[11px] font-semibold tracking-wider text-white/60 uppercase">
                Scheduling Deposit Today
              </div>
              <div className="font-mono-num text-3xl font-extrabold text-[var(--roof-copper-light)]">
                ${plan.priceUsd} <span className="text-sm font-semibold text-white/70">USD</span>
              </div>
              <div className="mt-0.5 text-xs text-emerald-300">
                100% credited on your final Whop Invoice
              </div>
            </div>
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
        <div className="grid items-start gap-8 lg:grid-cols-12">
          {/* Left column: How Deposit -> SetupIntent -> Final Invoice Works */}
          <div className="space-y-5 lg:col-span-5">
            <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-[var(--roof-obsidian)] to-[var(--roof-midnight)] p-6 text-white shadow-xl">
              <div className="flex items-center justify-between border-b border-white/15 pb-3">
                <span className="font-display text-sm font-bold">
                  Deposit → Job → Final Invoice Flow
                </span>
                <ReceiptText className="h-4 w-4 text-[var(--roof-copper-light)]" />
              </div>

              <ol className="mt-4 space-y-4 text-sm">
                <li className="flex items-start gap-3">
                  <span className="font-mono-num flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-[var(--roof-copper)] text-xs font-extrabold text-white">
                    1
                  </span>
                  <div>
                    <div className="font-bold text-white">Save Card via SetupIntent</div>
                    <p className="mt-0.5 text-xs leading-relaxed text-white/70">
                      Authorizes your card on file cleanly so remaining closing balances can be
                      billed effortlessly after inspection.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="font-mono-num flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-sky-500 text-xs font-extrabold text-white">
                    2
                  </span>
                  <div>
                    <div className="font-bold text-white">Pay ${plan.priceUsd} Project Deposit</div>
                    <p className="mt-0.5 text-xs leading-relaxed text-white/70">
                      Orders color-matched shingles, files city roof permits, and locks your crew
                      dispatch window.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="font-mono-num flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-emerald-600 text-xs font-extrabold text-white">
                    3
                  </span>
                  <div>
                    <div className="font-bold text-white">Settle Net Balance via Whop Invoice</div>
                    <p className="mt-0.5 text-xs leading-relaxed text-white/70">
                      Right on the confirmation page, preview &amp; run Step 3: auto-charge the
                      saved card or send a hosted final invoice link + PDF.
                    </p>
                  </div>
                </li>
              </ol>

              <ul className="mt-5 space-y-2 border-t border-white/15 pt-4 text-xs text-white/85">
                {plan.deliverables.map((item) => (
                  <li key={item} className="flex items-start gap-2">
                    <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border border-emerald-200 bg-emerald-50/75 p-4 text-xs text-emerald-950">
              <div className="flex items-center gap-2 font-bold">
                <ShieldCheck className="h-4 w-4 text-emerald-700" />
                <span>Need Test Mode? Zero Passcode Needed Here</span>
              </div>
              <p className="mt-1 leading-relaxed text-emerald-900/85">
                Click <strong>Test Card (4242)</strong> in the checkout box to run a complete
                Sandbox deposit with Visa <code className="font-mono-num font-bold">4242 4242 4242 4242</code>{' '}
                and immediately demo Step 3 Final Balance Invoicing on the confirmation page.
              </p>
            </div>
          </div>

          {/* Right column: Whop Checkout Elements */}
          <div className="lg:col-span-7">
            <WhopCheckoutFlow planKey="deposit" />
          </div>
        </div>
      </main>

      <Footer />
      <PixelDebugPill />
    </div>
  )
}
