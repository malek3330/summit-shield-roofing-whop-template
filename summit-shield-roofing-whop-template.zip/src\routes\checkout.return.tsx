import { createFileRoute, Link } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import {
  AlertCircle,
  ArrowLeft,
  CheckCircle2,
  Clock,
  ExternalLink,
  FileDown,
  Loader2,
  Printer,
  ReceiptText,
  Send,
  ShieldCheck,
  Zap,
} from 'lucide-react'
import { Footer } from '#/components/Footer'
import { Navbar } from '#/components/Navbar'
import { PixelDebugPill } from '#/components/PixelDebugPill'
import { roofingTemplate } from '#/config/roofingTemplate'
import { persistVaultCustomer } from '#/lib/vaultStorage'

export const Route = createFileRoute('/checkout/return')({
  component: CheckoutReturnPage,
})

interface VerifiedReturnState {
  loading: boolean
  isAdmin: boolean
  status: string
  planKey: string | null
  environmentMode: 'production' | 'sandbox'
  paymentId: string | null
  setupIntentId: string | null
  recordId: string | null
  memberId: string | null
  paymentMethodId: string | null
  cardSaved: boolean
  cardSummary: string | null
  summaryText: string
  error: string | null
}

interface BuyerInvoiceOutcome {
  id: string
  number: string
  status: string
  totalFormatted: string
  checkoutLink: string | null
  pdfUrl: string | null
  warning: string | null
}

function formatInvoiceMoney(obj?: { formatted?: string; amount?: number | string }): string {
  if (obj?.formatted) return obj.formatted
  if (obj?.amount != null) {
    const n = Number(obj.amount)
    if (Number.isFinite(n)) {
      return `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
    }
    return `$${obj.amount}`
  }
  return '—'
}

function CheckoutReturnPage() {
  const [state, setState] = useState<VerifiedReturnState>({
    loading: true,
    isAdmin: false,
    status: 'checking',
    planKey: null,
    environmentMode: 'production',
    paymentId: null,
    setupIntentId: null,
    recordId: null,
    memberId: null,
    paymentMethodId: null,
    cardSaved: false,
    cardSummary: null,
    summaryText: 'Confirming booking & payment status…',
    error: null,
  })

  // Step 3 Final Balance Invoice Demo State (Authorized cleanly via HttpOnly receipt cookie)
  const [balanceAmountUsd, setBalanceAmountUsd] = useState('25')
  const [balanceLineTitle, setBalanceLineTitle] = useState(
    roofingTemplate.invoiceFlowPresets[0].lineTitle,
  )
  const [balanceEmail, setBalanceEmail] = useState('')
  const [submittingInvoiceMode, setSubmittingInvoiceMode] = useState<
    'auto_charge' | 'send_manual' | null
  >(null)
  const [invoiceError, setInvoiceError] = useState<string | null>(null)
  const [invoiceResult, setInvoiceResult] = useState<BuyerInvoiceOutcome | null>(null)

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const paymentId = params.get('payment')
    const setupIntentId =
      params.get('setup_intent_id') ?? params.get('setup_intent') ?? params.get('setup')
    const urlStatus = params.get('status')
    const planKey = params.get('plan')
    const envMode = params.get('env') === 'sandbox' ? 'sandbox' : 'production'

    const verify = async () => {
      try {
        if (paymentId) {
          type ConfirmPaymentResponse = {
            redacted?: boolean
            payment?: {
              id?: string
              status: string
              cardSaved?: boolean
              cardSummary?: string | null
              member_id?: string | null
              payment_method_id?: string | null
              payment_instrument?: { display_name?: string | null } | null
            }
          }
          let latestPaymentData: ConfirmPaymentResponse | null = null

          for (let attempt = 0; attempt < 4; attempt++) {
            const res = await fetch(
              `/api/payments/confirm?id=${encodeURIComponent(paymentId)}&mode=${envMode}`,
            )
            if (!res.ok) break
            latestPaymentData = (await res.json()) as ConfirmPaymentResponse
            const st = latestPaymentData?.payment?.status
            if (st === 'paid' || st === 'succeeded' || st === 'failed') break
            if (attempt < 3) await new Promise((r) => setTimeout(r, 900))
          }

          if (latestPaymentData?.payment) {
            const serverStatus = latestPaymentData.payment.status
            const resolvedStatus =
              serverStatus && serverStatus !== 'open'
                ? serverStatus
                : (urlStatus ?? serverStatus ?? 'open')
            const isAdmin = !latestPaymentData.redacted
            const saved = Boolean(
              latestPaymentData.payment.cardSaved ||
                Boolean(setupIntentId) ||
                Boolean(
                  latestPaymentData.payment.payment_method_id &&
                    latestPaymentData.payment.member_id,
                ),
            )
            const cardSummary =
              latestPaymentData.payment.payment_instrument?.display_name ??
              latestPaymentData.payment.cardSummary ??
              'Verified Card'

            persistVaultCustomer({
              sourceId: '',
              sourceType: setupIntentId ? 'setup_intent' : 'payment',
              cardSaved: saved,
              cardSummary,
              capturedAtIso: new Date().toISOString(),
            })

            const settledOrVaulted =
              resolvedStatus === 'succeeded' ||
              resolvedStatus === 'paid' ||
              (saved && Boolean(setupIntentId))

            setState({
              loading: false,
              isAdmin,
              status: resolvedStatus,
              planKey,
              environmentMode: envMode,
              paymentId,
              setupIntentId,
              recordId: isAdmin ? (latestPaymentData.payment.id ?? null) : null,
              memberId: isAdmin ? (latestPaymentData.payment.member_id ?? null) : null,
              paymentMethodId: isAdmin
                ? (latestPaymentData.payment.payment_method_id ?? null)
                : null,
              cardSaved: saved,
              cardSummary,
              summaryText: settledOrVaulted
                ? saved
                  ? 'Your deposit authorization succeeded and your payment method is securely saved via SetupIntent for project closeout.'
                  : 'Your payment succeeded and your roofing appointment has been recorded.'
                : `Checkout returned with status "${resolvedStatus}".`,
              error: null,
            })
            return
          }

          if (urlStatus) {
            const ok = urlStatus === 'succeeded' || urlStatus === 'paid'
            if (ok) {
              persistVaultCustomer({
                sourceId: '',
                sourceType: 'checkout',
                cardSaved: true,
                cardSummary: 'Whop Checkout',
                capturedAtIso: new Date().toISOString(),
              })
            }

            setState({
              loading: false,
              isAdmin: false,
              status: urlStatus,
              planKey,
              environmentMode: envMode,
              paymentId,
              setupIntentId,
              recordId: null,
              memberId: null,
              paymentMethodId: null,
              cardSaved: ok,
              cardSummary: 'Whop Checkout',
              summaryText: ok
                ? 'Your checkout payment succeeded! Check your confirmation email for your receipt.'
                : `Checkout returned with status "${urlStatus}".`,
              error: null,
            })
            return
          }
        }

        if (setupIntentId) {
          const res = await fetch(
            `/api/setup-intents?id=${encodeURIComponent(setupIntentId)}&mode=${envMode}`,
          )
          if (res.ok) {
            const data = (await res.json()) as {
              ok?: boolean
              redacted?: boolean
              setupIntent?: {
                id?: string
                status: string
                cardSaved?: boolean
                cardSummary?: string | null
                member_id?: string | null
                payment_method_id?: string | null
                payment_instrument?: { display_name?: string | null } | null
              }
            }

            if (data.setupIntent) {
              const resolvedStatus = urlStatus ?? data.setupIntent.status
              const isAdmin = !data.redacted
              const saved = Boolean(
                data.setupIntent.cardSaved ??
                  Boolean(data.setupIntent.payment_method_id && data.setupIntent.member_id),
              )
              const cardSummary =
                data.setupIntent.payment_instrument?.display_name ??
                data.setupIntent.cardSummary ??
                'Saved Card'

              persistVaultCustomer({
                sourceId: '',
                sourceType: 'setup_intent',
                cardSaved: saved,
                cardSummary,
                capturedAtIso: new Date().toISOString(),
              })

              setState({
                loading: false,
                isAdmin,
                status: resolvedStatus,
                planKey,
                environmentMode: envMode,
                paymentId: null,
                setupIntentId,
                recordId: isAdmin ? (data.setupIntent.id ?? null) : null,
                memberId: isAdmin ? (data.setupIntent.member_id ?? null) : null,
                paymentMethodId: isAdmin ? (data.setupIntent.payment_method_id ?? null) : null,
                cardSaved: saved,
                cardSummary,
                summaryText:
                  resolvedStatus === 'succeeded'
                    ? 'Your payment method has been authorized on file ($0.00 charged upfront) for final balance invoicing.'
                    : `Authorization status: "${resolvedStatus}".`,
                error: null,
              })
              return
            }
          }
        }

        setState((prev) => ({
          ...prev,
          loading: false,
          status: urlStatus ?? 'completed',
          planKey,
          environmentMode: envMode,
          paymentId,
          setupIntentId,
          summaryText:
            urlStatus === 'succeeded' || urlStatus === 'paid'
              ? 'Checkout completed! Your booking receipt has been recorded.'
              : 'Checkout session returned. Contact our office if you need a status update.',
        }))
      } catch (err) {
        setState((prev) => ({
          ...prev,
          loading: false,
          status: 'error',
          error: err instanceof Error ? err.message : 'Verification error',
        }))
      }
    }

    void verify()
  }, [])

  const isSuccess =
    state.status === 'succeeded' ||
    state.status === 'paid' ||
    (state.status === 'open' && Boolean(state.setupIntentId) && state.cardSaved)
  const showFinalInvoiceDemo =
    !state.loading &&
    Boolean(state.setupIntentId || state.paymentId) &&
    (isSuccess || Boolean(state.setupIntentId && state.cardSaved)) &&
    (state.planKey === 'deposit' || Boolean(state.setupIntentId) || state.cardSaved)

  const handleRunFinalInvoice = async (mode: 'auto_charge' | 'send_manual') => {
    setInvoiceError(null)
    setSubmittingInvoiceMode(mode)
    try {
      const res = await fetch('/api/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: mode,
          environmentMode: state.environmentMode,
          setupIntentId: state.setupIntentId || undefined,
          paymentId: state.paymentId || undefined,
          emailAddress: balanceEmail.trim() || undefined,
          amountUsd: Number(balanceAmountUsd),
          lineTitle: balanceLineTitle.trim(),
          jobReference: `JOB-TX-${Date.now().toString().slice(-4)}`,
          memo: `Final roofing balance net of $${roofingTemplate.plans.deposit.priceUsd} deposit.`,
          dueDays: 7,
        }),
      })

      const data = (await res.json()) as {
        ok?: boolean
        message?: string
        warning?: string | null
        pdfUrl?: string | null
        invoice?: {
          id?: string
          number?: string
          status?: string
          total?: { formatted?: string; amount?: number | string }
          checkout_link?: string | null
        }
      }

      if (!res.ok || !data.ok || !data.invoice) {
        throw new Error(data.message || 'Unable to generate Whop final invoice.')
      }

      setInvoiceResult({
        id: String(data.invoice.id ?? ''),
        number: String(data.invoice.number ?? data.invoice.id ?? ''),
        status: String(data.invoice.status ?? 'open'),
        totalFormatted: formatInvoiceMoney(data.invoice.total),
        checkoutLink: data.invoice.checkout_link ?? null,
        pdfUrl: data.pdfUrl ?? null,
        warning: data.warning ?? null,
      })
    } catch (err) {
      setInvoiceError(err instanceof Error ? err.message : 'Unable to execute Whop Invoices API.')
    } finally {
      setSubmittingInvoiceMode(null)
    }
  }

  return (
    <div className="min-h-screen bg-[var(--roof-surface)] text-[var(--roof-ink)]">
      <Navbar />

      <main className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <div className="rounded-3xl border border-[var(--roof-border)] bg-white p-7 shadow-lg sm:p-9">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-bold tracking-wider text-[var(--roof-copper-deep)] uppercase">
              {roofingTemplate.brand.name} · Checkout Confirmation
            </span>
            <div className="flex flex-wrap items-center gap-2 print:hidden">
              <button
                type="button"
                onClick={() => window.print()}
                className="btn-shimmer inline-flex min-h-9 items-center gap-1.5 rounded-xl border border-emerald-600/30 bg-emerald-50 px-3.5 py-1.5 text-xs font-bold text-emerald-800 shadow-xs hover:bg-emerald-100"
                title="Print Official Booking Receipt or Save as PDF"
              >
                <Printer className="h-4 w-4" />
                <span>Print Receipt (PDF)</span>
              </button>
              {state.environmentMode === 'sandbox' && (
                <span className="font-mono-num rounded-full border border-amber-300 bg-amber-50 px-2.5 py-0.5 text-[11px] font-bold text-amber-900">
                  SANDBOX TEST SESSION
                </span>
              )}
            </div>
          </div>

          {state.loading ? (
            <div className="mt-6 flex items-center gap-3 text-sm text-[#4B5563]">
              <Loader2 className="h-5 w-5 animate-spin text-[var(--roof-copper)]" />
              <span>{state.summaryText}</span>
            </div>
          ) : state.error ? (
            <div className="mt-5 flex items-start gap-3 rounded-xl border border-red-300 bg-red-50 p-4 text-sm text-red-900">
              <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-red-600" />
              <span>{state.error}</span>
            </div>
          ) : (
            <div className="mt-5">
              <div className="flex items-center gap-2.5">
                {isSuccess ? (
                  <CheckCircle2 className="h-8 w-8 text-emerald-600" />
                ) : (
                  <Clock className="h-8 w-8 text-amber-600" />
                )}
                <h1 className="font-display text-2xl font-extrabold text-[#141A21] sm:text-3xl">
                  {isSuccess ? 'Checkout Confirmed' : `Checkout Status: ${state.status}`}
                </h1>
              </div>

              <p className="mt-3 text-sm leading-relaxed text-[#4B5563]">{state.summaryText}</p>

              {state.cardSummary && (
                <div className="mt-4 inline-flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2 text-xs font-semibold text-emerald-800">
                  <ShieldCheck className="h-4 w-4 text-emerald-600" />
                  <span>
                    Method: {state.cardSummary}
                    {state.cardSaved ? ' · Saved via SetupIntent for Closing Balance' : ''}
                  </span>
                </div>
              )}

              {state.isAdmin && state.recordId && (
                <dl className="font-mono-num mt-5 grid gap-2.5 text-xs sm:grid-cols-2">
                  <div className="rounded-lg border border-[#E5DFD3] bg-[#F6F4EF] p-3">
                    <dt className="text-[#6B7280]">Transaction ID</dt>
                    <dd className="mt-0.5 font-semibold break-all text-[#141A21]">
                      {state.recordId}
                    </dd>
                  </div>
                  <div className="rounded-lg border border-[#E5DFD3] bg-[#F6F4EF] p-3">
                    <dt className="text-[#6B7280]">Status</dt>
                    <dd className="mt-0.5 font-bold text-[#2F5241] uppercase">{state.status}</dd>
                  </div>
                  {state.memberId && (
                    <div className="rounded-lg border border-[#E5DFD3] bg-[#F6F4EF] p-3">
                      <dt className="text-[#6B7280]">Member ID</dt>
                      <dd className="mt-0.5 font-semibold break-all text-[#141A21]">
                        {state.memberId}
                      </dd>
                    </div>
                  )}
                  {state.paymentMethodId && (
                    <div className="rounded-lg border border-[#E5DFD3] bg-[#F6F4EF] p-3">
                      <dt className="text-[#6B7280]">Saved Method</dt>
                      <dd className="mt-0.5 font-semibold break-all text-[#2F5241]">
                        {state.paymentMethodId}
                      </dd>
                    </div>
                  )}
                </dl>
              )}

              {/* Formal Printable Receipt Card (Print-optimized and clean on-screen) */}
              <div className="print-receipt-sheet mt-6 rounded-2xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/60 p-5 sm:p-6">
                <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#D8D1C4] pb-4">
                  <div>
                    <div className="font-display text-lg font-extrabold text-[#111827]">
                      {roofingTemplate.brand.name}
                    </div>
                    <div className="mt-0.5 text-xs text-[#4B5563]">
                      {roofingTemplate.brand.licenseNumber} · {roofingTemplate.brand.phoneDisplay}
                    </div>
                    <div className="text-xs text-[#4B5563]">
                      {roofingTemplate.brand.streetAddress}, {roofingTemplate.brand.cityStateZip}
                    </div>
                  </div>
                  <div className="text-left sm:text-right">
                    <div className="font-mono-num text-xs font-bold text-[var(--roof-copper-deep)] uppercase">
                      Official Booking &amp; Payment Receipt
                    </div>
                    <div className="font-mono-num mt-0.5 text-xs font-bold text-[#111827]">
                      {state.paymentId ? `RCP-${state.paymentId.slice(-8).toUpperCase()}` : 'RCP-PENDING'}
                    </div>
                    <div className="text-[11px] text-[#6B7280]">
                      {new Date().toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </div>
                  </div>
                </div>

                {/* Table of charges */}
                <div className="mt-4">
                  <div className="text-[11px] font-bold tracking-wider text-[#6B7280] uppercase">
                    Transaction Summary
                  </div>
                  <div className="mt-2 divide-y divide-[#E5DFD3] text-xs">
                    <div className="flex items-center justify-between py-2">
                      <div>
                        <div className="font-bold text-[#111827]">
                          {state.planKey === 'deposit'
                            ? roofingTemplate.plans.deposit.title
                            : state.planKey === 'inspection'
                              ? roofingTemplate.plans.inspection.title
                              : state.planKey === 'tuneup'
                                ? roofingTemplate.plans.tuneup.title
                                : 'Whop Service Reservation'}
                        </div>
                        <div className="text-[11px] text-[#4B5563]">
                          {state.planKey === 'deposit'
                            ? 'Guaranteed dispatch window & material reservation (100% credited to contract)'
                            : state.planKey === 'inspection'
                              ? 'Comprehensive drone & attic inspection with itemized digital repair scope'
                              : 'Complete roof tune-up, flashing reseal & valley clearing'}
                        </div>
                      </div>
                      <div className="font-mono-num font-extrabold text-[#111827]">
                        {state.planKey === 'deposit'
                          ? `$${roofingTemplate.plans.deposit.priceUsd.toFixed(2)}`
                          : state.planKey === 'inspection'
                            ? `$${roofingTemplate.plans.inspection.priceUsd.toFixed(2)}`
                            : state.planKey === 'tuneup'
                              ? `$${roofingTemplate.plans.tuneup.priceUsd.toFixed(2)}`
                              : '$500.00'}
                      </div>
                    </div>

                    {state.cardSaved && (
                      <div className="flex items-center justify-between py-2 text-[11px] text-[#4B5563]">
                        <div>
                          <span className="font-semibold text-emerald-800">Card-on-File Authorization</span>
                          <span className="block text-[10px] text-[#6B7280]">
                            Off-session billing setup for job closing invoice
                          </span>
                        </div>
                        <span className="font-mono-num font-bold text-emerald-800">$0.00 (Authorized)</span>
                      </div>
                    )}

                    {invoiceResult && (
                      <div className="flex items-center justify-between py-2 text-xs">
                        <div>
                          <span className="font-bold text-emerald-900">
                            Final Balance Invoice ({invoiceResult.number})
                          </span>
                          <span className="block text-[11px] text-[#4B5563]">
                            Settled via Whop Invoices API ({invoiceResult.status})
                          </span>
                        </div>
                        <span className="font-mono-num font-extrabold text-emerald-900">
                          {invoiceResult.totalFormatted}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="mt-3 flex items-center justify-between border-t-2 border-[#111827] pt-2 text-sm font-extrabold text-[#111827]">
                    <span>Total Settled Today</span>
                    <span className="font-mono-num">
                      {state.planKey === 'deposit'
                        ? `$${roofingTemplate.plans.deposit.priceUsd.toFixed(2)}`
                        : state.planKey === 'inspection'
                          ? `$${roofingTemplate.plans.inspection.priceUsd.toFixed(2)}`
                          : state.planKey === 'tuneup'
                            ? `$${roofingTemplate.plans.tuneup.priceUsd.toFixed(2)}`
                            : '$500.00'}
                    </span>
                  </div>
                </div>

                {/* Footer notes */}
                <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[#D8D1C4] pt-3 text-[11px] text-[#6B7280]">
                  <div>
                    Payment Method: <strong className="text-[#111827]">{state.cardSummary || 'Verified Card'}</strong>
                    {state.paymentId && ` · Whop ID: ${state.paymentId}`}
                  </div>
                  <div className="inline-flex items-center gap-1 font-semibold text-emerald-700">
                    <ShieldCheck className="h-3.5 w-3.5" />
                    <span>Verified Whop Payment</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 3 Interactive Final Balance Invoice Card for Buyer / Reviewer */}
          {showFinalInvoiceDemo && (
            <div className="mt-8 rounded-3xl border border-[var(--roof-border)] bg-gradient-to-br from-[var(--roof-obsidian)] to-[var(--roof-midnight)] p-6 text-white shadow-xl print:hidden">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/15 pb-3.5">
                <div className="flex items-center gap-2 text-xs font-bold tracking-wider text-emerald-300 uppercase">
                  <ReceiptText className="h-4 w-4" />
                  <span>Step 3 · Bill Final Balance (Whop Invoices API)</span>
                </div>
                <span className="font-mono-num rounded-full bg-white/10 px-2.5 py-0.5 text-[10px] font-semibold text-white/80">
                  Uses Stored Method From This Session
                </span>
              </div>

              <p className="mt-3 text-xs leading-relaxed text-white/75">
                Your card is saved on file from the deposit SetupIntent. Demonstrate or settle a
                final roofing balance right now by auto-charging the stored card or issuing a hosted
                payment invoice + PDF.
              </p>

              {/* Quick Balance Presets */}
              <div className="mt-4 flex flex-wrap gap-2">
                {[
                  { label: '$25 Quick Demo', val: '25' },
                  {
                    label: `$${roofingTemplate.invoiceFlowPresets[0].finalBalanceUsd.toLocaleString()} Hail Repair Net`,
                    val: String(roofingTemplate.invoiceFlowPresets[0].finalBalanceUsd),
                  },
                  {
                    label: `$${roofingTemplate.invoiceFlowPresets[1].finalBalanceUsd.toLocaleString()} Metal Canopy Net`,
                    val: String(roofingTemplate.invoiceFlowPresets[1].finalBalanceUsd),
                  },
                ].map((preset) => (
                  <button
                    key={preset.val}
                    type="button"
                    onClick={() => setBalanceAmountUsd(preset.val)}
                    className={`rounded-full px-3 py-1 text-xs font-bold transition-colors ${
                      balanceAmountUsd === preset.val
                        ? 'bg-[var(--roof-copper)] text-white'
                        : 'border border-white/15 bg-white/8 text-white/80 hover:bg-white/15'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <div>
                  <label htmlFor="ret-inv-amount" className="block text-[11px] font-semibold text-white/75">
                    Final Balance Amount (USD)
                  </label>
                  <div className="relative mt-1">
                    <span className="font-mono-num pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-xs font-bold text-[var(--roof-copper-light)]">
                      $
                    </span>
                    <input
                      id="ret-inv-amount"
                      type="number"
                      min="1"
                      max="25000"
                      step="0.01"
                      value={balanceAmountUsd}
                      onChange={(e) => setBalanceAmountUsd(e.target.value)}
                      className="font-mono-num min-h-10 w-full rounded-xl border border-white/15 bg-white/8 py-2 pr-3 pl-7 text-sm font-bold text-white"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="ret-inv-email" className="block text-[11px] font-semibold text-white/75">
                    Invoice Recipient Email (Optional Override)
                  </label>
                  <input
                    id="ret-inv-email"
                    type="email"
                    placeholder="Uses checkout email if blank"
                    value={balanceEmail}
                    onChange={(e) => setBalanceEmail(e.target.value)}
                    className="mt-1 min-h-10 w-full rounded-xl border border-white/15 bg-white/8 px-3 text-xs text-white placeholder:text-white/40"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="ret-inv-title" className="block text-[11px] font-semibold text-white/75">
                    Closing Line Item Title
                  </label>
                  <input
                    id="ret-inv-title"
                    type="text"
                    value={balanceLineTitle}
                    onChange={(e) => setBalanceLineTitle(e.target.value)}
                    className="mt-1 min-h-10 w-full rounded-xl border border-white/15 bg-white/8 px-3 text-xs text-white"
                  />
                </div>
              </div>

              {invoiceError && (
                <div className="mt-4 flex items-start gap-2 rounded-xl border border-red-400/40 bg-red-500/20 px-3.5 py-2.5 text-xs text-red-100">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-300" />
                  <span>{invoiceError}</span>
                </div>
              )}

              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <button
                  type="button"
                  disabled={submittingInvoiceMode !== null}
                  onClick={() => handleRunFinalInvoice('auto_charge')}
                  className="btn-shimmer inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 px-4 py-2.5 text-xs font-bold text-white shadow-md disabled:opacity-55 sm:text-sm"
                >
                  {submittingInvoiceMode === 'auto_charge' ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Zap className="h-4 w-4" />
                  )}
                  <span>Auto-Charge Saved Card</span>
                </button>

                <button
                  type="button"
                  disabled={submittingInvoiceMode !== null}
                  onClick={() => handleRunFinalInvoice('send_manual')}
                  className="btn-shimmer inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-white/25 bg-white/12 px-4 py-2.5 text-xs font-bold text-white hover:bg-white/20 disabled:opacity-55 sm:text-sm"
                >
                  {submittingInvoiceMode === 'send_manual' ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                  <span>Send Manual Invoice</span>
                </button>
              </div>

              {invoiceResult && (
                <div className="mt-5 rounded-2xl border border-emerald-400/40 bg-white/10 p-4 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-bold text-emerald-300">
                      Whop Invoice {invoiceResult.number} Created
                    </span>
                    <span className="font-mono-num rounded-full bg-emerald-500/20 px-2.5 py-0.5 font-bold text-emerald-200 uppercase">
                      {invoiceResult.status} · {invoiceResult.totalFormatted}
                    </span>
                  </div>

                  <div className="font-mono-num mt-2 text-[11px] text-white/75">
                    ID: {invoiceResult.id}
                  </div>

                  <div className="mt-3 flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="inline-flex min-h-9 items-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/20 px-3 py-1.5 font-semibold text-emerald-200 hover:bg-emerald-500/30 print:hidden"
                    >
                      <Printer className="h-3.5 w-3.5" />
                      <span>Print Receipt &amp; Invoice</span>
                    </button>
                    {invoiceResult.checkoutLink && (
                      <a
                        href={invoiceResult.checkoutLink}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex min-h-9 items-center gap-1.5 rounded-lg bg-[var(--roof-copper)] px-3 py-1.5 font-semibold text-white hover:bg-[var(--roof-copper-deep)] print:hidden"
                      >
                        <span>Open Hosted Pay Link</span>
                        <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    )}
                    {invoiceResult.pdfUrl && (
                      <a
                        href={invoiceResult.pdfUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex min-h-9 items-center gap-1.5 rounded-lg border border-white/25 bg-white/10 px-3 py-1.5 font-semibold text-white hover:bg-white/20 print:hidden"
                      >
                        <FileDown className="h-3.5 w-3.5" />
                        <span>Download PDF Invoice</span>
                      </a>
                    )}
                  </div>

                  {invoiceResult.warning && (
                    <div className="mt-3 rounded-xl border border-amber-400/35 bg-amber-500/15 p-2.5 text-[11px] leading-relaxed text-amber-100">
                      <strong>Draft Invoice Saved ({invoiceResult.id}):</strong>{' '}
                      {invoiceResult.warning}. Final auto-issuance requires business KYC verification
                      on the connected Whop merchant account.
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          <div className="mt-7 flex flex-wrap gap-3 print:hidden">
            <Link
              to="/"
              className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-[var(--roof-copper)] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[var(--roof-copper-deep)]"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Return to Home</span>
            </Link>
            <Link
              to="/deposit"
              className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-[var(--roof-border)] bg-[var(--roof-canvas)] px-5 py-2.5 text-sm font-semibold text-[var(--roof-ink)] hover:border-[var(--roof-ink)]"
            >
              <span>Run Another Deposit Test</span>
            </Link>
          </div>
        </div>
      </main>

      <Footer />
      <PixelDebugPill />
    </div>
  )
}
