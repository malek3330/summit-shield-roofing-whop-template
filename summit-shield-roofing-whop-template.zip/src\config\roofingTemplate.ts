import type { AccentColor } from '@whop/elements'

export type WhopPlanKey = 'inspection' | 'deposit' | 'tuneup'

export interface RoofingServiceItem {
  id: 'inspection' | 'repair' | 'replacement' | 'tuneup'
  categoryLabel: string
  filterLabel?: string
  title: string
  subtitle: string
  startingPriceLabel: string
  priceNumber: number
  turnaround: string
  warranty: string
  image: string
  imageAlt: string
  highlights: string[]
  linkedPlanKey: WhopPlanKey | null
  ctaLabel: string
}

export interface RoofingPlanConfig {
  key: WhopPlanKey
  badge: string
  cardLabel?: string
  title: string
  shortTitle: string
  description: string
  priceUsd: number
  billingLabel: string
  supportsSetupIntentVault: boolean
  defaultProductId: string
  defaultVariantId: string
  deliverables: string[]
}

export interface ServiceCity {
  city: string
  county: string
  zipPrefix: string
  dispatchEta: string
  roofFocus: string
  /** Optional radar map display label & SVG coordinates (viewBox 0..360 x 0..220) */
  mapLabel?: string
  mapX?: number
  mapY?: number
  isHub?: boolean
}

export interface RoofingReview {
  id: string
  homeowner: string
  neighborhood: string
  serviceDone: string
  rating: number
  quote: string
  verifiedJobValue: string
  dateLabel: string
}

export interface FinalInvoicePreset {
  id: string
  label: string
  jobReference: string
  grossJobTotalUsd: number
  depositCreditedUsd: number
  finalBalanceUsd: number
  lineTitle: string
  memo: string
}

export interface RoofingTemplateConfig {
  templateMeta: {
    templateVersion: string
    targetVertical: string
    rebrandInstructions: string
  }
  brand: {
    name: string
    shortName: string
    /** Optional URL/path to your square/wide logo image (e.g. '/images/logo.png'). Leave empty to use built-in roof icon. */
    logoUrl?: string
    tagline: string
    licenseNumber: string
    foundedYear: number
    yearsExperience: number
    phoneDisplay: string
    phoneHref: string
    email: string
    streetAddress: string
    cityStateZip: string
    serviceHours: string
    rating: string
    reviewCount: number
    completedRoofs: string
  }
  theme: {
    canvasHex: string
    surfaceHex: string
    borderHex: string
    inkHex: string
    obsidianHex: string
    midnightHex: string
    accentHex: string
    accentDeepHex: string
    secondaryAccentHex: string
    forestHex: string
    /** Controls native Whop Payment Elements primary highlight color ('orange', 'blue', 'amber', 'emerald', etc.) */
    elementsAccentColor: AccentColor
    elementsGrayColor: 'gray' | 'mauve' | 'slate' | 'sage' | 'olive' | 'sand' | 'auto'
  }
  hero: {
    eyebrow: string
    headline: string
    /** Optional substrings inside `headline` to render with vibrant gradient emphasis */
    headlineHighlightPrimary?: string
    headlineHighlightSecondary?: string
    subheadline: string
    primaryCta: string
    secondaryCta: string
    topLeftBadge: string
    topRightBadge: string
    workflowCardTitle: string
    heroImage: string
    heroImageAlt: string
    detailImage: string
    detailImageAlt: string
    replacementImage: string
    replacementImageAlt: string
    craftsmanshipShowcase: {
      detailEyebrow: string
      detailTitle: string
      detailDescription: string
      turnkeyEyebrow: string
      turnkeyTitle: string
      turnkeyDescription: string
    }
    stats: Array<{ value: string; label: string }>
  }
  services: RoofingServiceItem[]
  plans: Record<WhopPlanKey, RoofingPlanConfig>
  financing: {
    eyebrow: string
    headline: string
    description: string
    providers: Array<{
      name: string
      terms: string
      badge: string
    }>
    calculatorSampleTotal: number
    calculatorPresets?: Array<{ label: string; value: number }>
    disclaimer: string
  }
  serviceArea: {
    regionLabel: string
    headline: string
    description: string
    emergencyDispatchText: string
    radarLabel: string
    cities: ServiceCity[]
  }
  reviews: {
    headline: string
    subheadline: string
    trustCredentials: Array<{ title: string; subtitle: string }>
    items: RoofingReview[]
  }
  invoiceFlowPresets: FinalInvoicePreset[]
  formPlaceholders: {
    name: string
    email: string
    phone: string
    zip: string
    address: string
    notes: string
    invoiceCustomerName: string
  }
  whopDefaults: {
    accountId: string
    environment: 'production' | 'sandbox'
  }
}

/**
 * ============================================================================
 * REUSABLE CONTRACTOR TEMPLATE — EDIT ONLY THIS FILE TO REBRAND IN 2 MINUTES
 * ============================================================================
 * Swap:
 *   1. `brand`          -> Company name, optional `logoUrl`, phone, email, address, license
 *   2. `theme`          -> Page & Whop Checkout palette (`accentHex`, `secondaryAccentHex`, etc.)
 *   3. `hero` & `services` -> Headlines, roof photos (`/public/images/...`), scopes & prices
 *   4. `plans`          -> Your 3 Whop Products/Plans pricing (`$149` / `$500` / `$299` defaults)
 *   5. `serviceArea`    -> Local cities, ZIP codes, ETAs & radar map pin coordinates
 *   6. `reviews` & `invoiceFlowPresets` -> Testimonials, closeout presets & form placeholders
 *
 * Provision live API credentials securely via `npx whop apps secrets set` (never put secret API keys here).
 */
export const roofingTemplate: RoofingTemplateConfig = {
  templateMeta: {
    templateVersion: '2.1.0',
    targetVertical: 'US Residential & Light Commercial Roofing',
    rebrandInstructions:
      'Licensed, Bonded & Insured Central Texas Roofing Contractor · 50-Year Material & 10-Year Workmanship Warranty.',
  },
  brand: {
    name: 'Summit Shield Roofing Co.',
    shortName: 'Summit Shield',
    logoUrl: '',
    tagline: 'Engineered Storm-Grade Roof Systems Across Central Texas',
    licenseNumber: 'RCAT Licensed #TX-40928-RF · GAF Master Elite®',
    foundedYear: 2012,
    yearsExperience: 14,
    phoneDisplay: '(512) 555-0194',
    phoneHref: 'tel:+15125550194',
    email: 'estimates@summitshieldroofs.example',
    streetAddress: '4810 Bee Cave Rd, Suite 210',
    cityStateZip: 'Austin, TX 78746',
    serviceHours: 'Mon–Sat · 7:00 AM – 7:00 PM · 24/7 Storm Tarp Line',
    rating: '4.9',
    reviewCount: 418,
    completedRoofs: '2,450+',
  },
  theme: {
    canvasHex: '#FAF8F3',
    surfaceHex: '#F1EDE4',
    borderHex: '#E2DACB',
    inkHex: '#111827',
    obsidianHex: '#0B1016',
    midnightHex: '#121A24',
    accentHex: '#E05A2B',
    accentDeepHex: '#B83D14',
    secondaryAccentHex: '#F59E0B',
    forestHex: '#10B981',
    elementsAccentColor: 'orange',
    elementsGrayColor: 'sand',
  },
  hero: {
    eyebrow: 'Central Texas Architectural & Hail-Rated Roofing',
    headline: 'Roofs Built for 110°F Summers and Hailstorms.',
    headlineHighlightPrimary: '110°F Summers',
    headlineHighlightSecondary: 'Hailstorms.',
    subheadline:
      'Transparent upfront inspections, itemized digital quotes, and protected scheduling deposits—pay seamlessly by card, Apple Pay, or flexible monthly financing.',
    primaryCta: 'Lock $149 Roof Inspection',
    secondaryCta: 'Request Free Estimate',
    topLeftBadge: 'Class 4 Hail Rated',
    topRightBadge: '4K Aerial + Thermal Audit Ready',
    workflowCardTitle: 'High-Ticket Roofing Billing Flow',
    heroImage: '/images/hero-roof.jpg',
    heroImageAlt:
      'Austin Hill Country home with charcoal architectural shingles and standing-seam bronze accent roof at golden hour',
    detailImage: '/images/craftsmanship-detail.jpg',
    detailImageAlt:
      'Close-up craftsmanship of precision copper valley flashing and dimensional slate architectural shingles',
    replacementImage: '/images/replacement-home.jpg',
    replacementImageAlt:
      'Completed residential roof replacement featuring Class 4 charcoal shingles and seamless matte black gutters',
    craftsmanshipShowcase: {
      detailEyebrow: 'Copper Valley Engineering',
      detailTitle: 'Hand-Bent Copper Flashing & Class 4 Shingle Architecture',
      detailDescription:
        'Open metal valleys, ice-and-water membrane under all penetrations, and 6-nail wind patterns engineered for severe hail corridors.',
      turnkeyEyebrow: 'Turnkey Deposit-to-Final Flow',
      turnkeyTitle: '2-Day Full Tear-Off & Clean Magnetic Sweep',
      turnkeyDescription:
        'Start with a $500 refundable scheduling deposit, review final inspection photos, then settle your remaining balance digitally.',
    },
    stats: [
      { value: '2,450+', label: 'Texas Roofs Installed' },
      { value: '4.9 / 5', label: '418 Homeowner Reviews' },
      { value: '50-Yr', label: 'Transferable Warranty' },
      { value: '24 Hr', label: 'Storm Leak Dispatch' },
    ],
  },
  services: [
    {
      id: 'inspection',
      categoryLabel: 'Diagnostic Inspection',
      filterLabel: '$149 Inspection',
      title: '19-Point Drone & Attic Roof Inspection',
      subtitle:
        'Full thermal moisture scan, hail bruising check, decking probe, flashing audit, and insurer-ready photo packet.',
      startingPriceLabel: '$149 One-Time',
      priceNumber: 149,
      turnaround: '48-hr report delivery',
      warranty: '100% credited toward any approved job',
      image: '/images/hero-roof.jpg',
      imageAlt: 'Aerial architectural roof framing and standing-seam inspection overview',
      highlights: [
        '4K aerial ortho + close-up hail impact documentation',
        'Attic truss, soffit airflow & moisture-meter check',
        'Itemized repair vs. replacement scope sent digitally',
      ],
      linkedPlanKey: 'inspection',
      ctaLabel: 'Book $149 Inspection',
    },
    {
      id: 'repair',
      categoryLabel: 'Rapid Remediation',
      filterLabel: 'Storm Repair',
      title: 'Emergency Leak, Flashing & Storm Repair',
      subtitle:
        'Same-week remediation for torn architectural shingles, chimney crickets, skylights, pipe jacks, and hail penetrations.',
      startingPriceLabel: 'From $450 · Lock slot w/ $500 Deposit',
      priceNumber: 500,
      turnaround: '24–72 hr dispatch',
      warranty: '5-Year Leak-Free Repair Guarantee',
      image: '/images/craftsmanship-detail.jpg',
      imageAlt: 'Copper valley flashing and weather-tight architectural shingle repair',
      highlights: [
        'Color-matched GAF & Owens Corning architectural bundles',
        'Lead & anodized aluminum pipe-boot upgrades',
        'Digital photo proof before & after closeout',
      ],
      linkedPlanKey: 'deposit',
      ctaLabel: 'Pay $500 Repair Deposit',
    },
    {
      id: 'replacement',
      categoryLabel: 'Full System Replacement',
      filterLabel: 'Full Replacement',
      title: 'Class 4 Shingle & Standing-Seam Metal Roofs',
      subtitle:
        'Complete tear-off to bare plywood deck, synthetic ice & water shield, balanced ridge ventilation, and custom metal flashing.',
      startingPriceLabel: 'From $8,400 · Reserve w/ $500 Deposit',
      priceNumber: 8400,
      turnaround: '1–2 Day Clean Tear-Off & Install',
      warranty: '50-Yr Material + 10-Yr Workmanship',
      image: '/images/replacement-home.jpg',
      imageAlt: 'Freshly replaced Class 4 charcoal roof with seamless gutters on residential home',
      highlights: [
        'GAF Timberline® ArmorShield II Class 4 hail-rated shingles',
        '24-gauge Kynar-coated concealed-fastener standing seam',
        'Magnetic nail sweep + dumpster & city permit handling',
      ],
      linkedPlanKey: 'deposit',
      ctaLabel: 'Lock Install Slot ($500)',
    },
    {
      id: 'tuneup',
      categoryLabel: 'Flat-Rate Maintenance',
      filterLabel: '$299 Flat-Rate',
      title: 'Flat-Rate Roof & Flashing Preventative Tune-Up',
      subtitle:
        'Pre-storm preventative package at one transparent flat price — no upsells, no surprise service fees.',
      startingPriceLabel: '$299 Flat Rate',
      priceNumber: 299,
      turnaround: '90-min scheduled visit',
      warranty: '2-Year Sealant & Boot Warranty',
      image: '/images/hero-roof.jpg',
      imageAlt: 'Well-maintained Hill Country residential roof prepared for seasonal storms',
      highlights: [
        'Reseal up to 4 neoprene plumbing vents & chimney flashing',
        'Reset popped nails & replace up to 10 wind-lifted tabs',
        'Blow clear roof valleys, dead-valleys & downspout outlets',
      ],
      linkedPlanKey: 'tuneup',
      ctaLabel: 'Book $299 Flat-Rate',
    },
  ],
  plans: {
    inspection: {
      key: 'inspection',
      badge: 'One-Time Fee',
      cardLabel: 'Inspection',
      title: '19-Point Drone & Attic Roof Inspection',
      shortTitle: 'Roof Inspection ($149)',
      description:
        'Includes thermal attic check, aerial hail map, flashing audit, and same-week itemized repair/replacement quote.',
      priceUsd: 149,
      billingLabel: 'One-time fee · Credited to job',
      supportsSetupIntentVault: false,
      defaultProductId: 'prod_replace_with_yours',
      defaultVariantId: 'plan_replace_with_yours',
      deliverables: [
        'High-res photo packet + thermal leak scan',
        'Insurance & adjuster-ready storm documentation',
        'Automatic $149 credit toward full roof job',
      ],
    },
    deposit: {
      key: 'deposit',
      badge: 'Most Popular · Credited to Job',
      cardLabel: 'Project Deposit',
      title: 'Project Scheduling & Material Deposit',
      shortTitle: 'Project Deposit ($500)',
      description:
        'Secures your crew dispatch date, orders color-matched shingles, and reserves your closing balance billing option for installation day.',
      priceUsd: 500,
      billingLabel: 'One-time deposit · Credited in full',
      supportsSetupIntentVault: true,
      defaultProductId: 'prod_replace_with_yours',
      defaultVariantId: 'plan_replace_with_yours',
      deliverables: [
        'Locks permit filing & crew install window',
        'Fast final-balance settlement upon completion',
        'Credited 100% against your final roof invoice',
      ],
    },
    tuneup: {
      key: 'tuneup',
      badge: 'Flat-Rate Service',
      cardLabel: 'Flat Tune-Up',
      title: 'Flat-Rate Roof & Flashing Tune-Up',
      shortTitle: 'Flat-Rate Tune-Up ($299)',
      description:
        'Preventative sealing of boots, exposed nail heads, skylight perimeters, and roof valley debris clearing at a locked flat price.',
      priceUsd: 299,
      billingLabel: 'One-time flat rate · No hidden fees',
      supportsSetupIntentVault: false,
      defaultProductId: 'prod_replace_with_yours',
      defaultVariantId: 'plan_replace_with_yours',
      deliverables: [
        'Reseal all exposed fasteners & pipe collars',
        'Clear roof valleys, crickets & scupper drains',
        'Photo closeout receipt sent straight to email',
      ],
    },
  },
  financing: {
    eyebrow: 'Flexible Roofing Financing Built Into Checkout',
    headline: 'Protect Your Home Today. Split High-Ticket Costs Monthly.',
    description:
      'Roof replacements shouldn’t stall over lump-sum cash flow. Because checkout runs natively on Whop Payment Elements, eligible homeowners automatically see flexible installment and pay-later options at checkout—with zero third-party redirect portals.',
    providers: [
      {
        name: 'Klarna',
        terms: 'Pay in 4 interest-free installments or 6–36 mo financing',
        badge: 'Auto-Surfaced via Whop',
      },
      {
        name: 'Afterpay / Cash App Afterpay',
        terms: '4 bi-weekly interest-free payments on inspections & repairs',
        badge: 'Zero Contractor Setup',
      },
      {
        name: 'Splitit',
        terms: 'Split large deposits & balances across existing credit lines',
        badge: 'Ideal for $5k–$25k Jobs',
      },
    ],
    calculatorSampleTotal: 11800,
    calculatorPresets: [
      { label: '$5,500 Storm Repair', value: 5500 },
      { label: '$11,800 Shingle Roof', value: 11800 },
      { label: '$19,500 Standing Seam', value: 19500 },
    ],
    disclaimer:
      'Installment options (Klarna, Splitit, Afterpay, Zip) surface dynamically inside Whop Checkout based on merchant approval, order total, and homeowner eligibility.',
  },
  serviceArea: {
    regionLabel: 'Greater Austin & Texas Hill Country',
    headline: 'Local Crews Within 35 Minutes of Every Roof We Build.',
    description:
      'From limestone custom estates in Westlake to hail-corridor neighborhoods in Round Rock and Cedar Park, our in-house W-2 master installers keep trucks stocked locally for rapid storm dispatch.',
    emergencyDispatchText: 'Same-day emergency tarping available across Travis, Williamson & Hays counties.',
    radarLabel: 'Central Texas service coverage corridor map',
    cities: [
      {
        city: 'Austin Metro & Westlake',
        county: 'Travis County',
        zipPrefix: '78701–78759',
        dispatchEta: '25 mins',
        roofFocus: 'Architectural Slate & Standing Seam',
        mapLabel: 'Austin HQ',
        mapX: 180,
        mapY: 122,
        isHub: true,
      },
      {
        city: 'Round Rock & Pflugerville',
        county: 'Williamson County',
        zipPrefix: '78664 · 78660',
        dispatchEta: '30 mins',
        roofFocus: 'Class 4 Hail-Rated Shingle Systems',
        mapLabel: 'Round Rock',
        mapX: 222,
        mapY: 74,
      },
      {
        city: 'Cedar Park & Leander',
        county: 'Williamson County',
        zipPrefix: '78613 · 78641',
        dispatchEta: '35 mins',
        roofFocus: 'Wind & Hail Insurance Restorations',
        mapLabel: 'Cedar Park',
        mapX: 112,
        mapY: 66,
      },
      {
        city: 'Lakeway & Bee Cave',
        county: 'Travis County',
        zipPrefix: '78734 · 78738',
        dispatchEta: '20 mins',
        roofFocus: 'Standing-Seam Metal & Copper Accents',
        mapLabel: 'Lakeway',
        mapX: 88,
        mapY: 120,
      },
      {
        city: 'Dripping Springs & Buda',
        county: 'Hays County',
        zipPrefix: '78620 · 78610',
        dispatchEta: '35 mins',
        roofFocus: 'Ranch Metal Roofing & Ridge Ventilation',
        mapLabel: 'Dripping Springs',
        mapX: 100,
        mapY: 174,
      },
      {
        city: 'Georgetown',
        county: 'Williamson County',
        zipPrefix: '78626 · 78628',
        dispatchEta: '40 mins',
        roofFocus: 'Impact-Resistant Shingle Replacements',
        mapLabel: 'Georgetown',
        mapX: 190,
        mapY: 36,
      },
    ],
  },
  reviews: {
    headline: 'Trusted by Central Texas Homeowners Since 2012.',
    subheadline:
      'Rated 4.9/5 across 418 verified roof inspections, hail repairs, and complete architectural replacements.',
    trustCredentials: [
      { title: 'GAF Master Elite®', subtitle: 'Top 2% of North American Contractors' },
      { title: '$2M Liability & Workers Comp', subtitle: 'Full Certificate Included Pre-Tear-Off' },
      { title: 'BBB A+ Accredited', subtitle: 'Zero Unresolved Homeowner Disputes' },
      { title: 'Whop Verified Billing', subtitle: 'PCI-Isolated Deposits & Digital Invoices' },
    ],
    items: [
      {
        id: 'rev-1',
        homeowner: 'Marcus & Hannah Delgado',
        neighborhood: 'Westlake Hills, Austin TX',
        serviceDone: 'Class 4 Charcoal Replacement + Copper Porch',
        rating: 5,
        quote:
          'We paid the $500 deposit online in 60 seconds, had architectural samples on our driveway the next morning, and the crew finished our entire 3,400 sq ft roof in two spotless days. Final invoice auto-billed right after our magnet sweep walkthrough.',
        verifiedJobValue: '$14,800 Completed Roof',
        dateLabel: '2 weeks ago',
      },
      {
        id: 'rev-2',
        homeowner: 'Derek Holloway',
        neighborhood: 'Teravista, Round Rock TX',
        serviceDone: '19-Point Hail Inspection + Flashing Repair',
        rating: 5,
        quote:
          'After April hail hit Round Rock, Summit Shield sent drone thermal shots showing bruised ridge caps before any water reached our ceiling. Their $149 inspection fee went straight toward the repair credit.',
        verifiedJobValue: '$1,650 Storm Remediation',
        dateLabel: '1 month ago',
      },
      {
        id: 'rev-3',
        homeowner: 'Claire & Ben Whitfield',
        neighborhood: 'Dripping Springs, TX',
        serviceDone: 'Flat-Rate $299 Preventative Tune-Up',
        rating: 5,
        quote:
          'Booked the $299 flat-rate tune-up via Apple Pay before fall rains. They replaced three cracked rubber pipe boots, cleared cedar needles out of both dead-valleys, and emailed before/after photos the same afternoon.',
        verifiedJobValue: '$299 Flat-Rate Service',
        dateLabel: '6 weeks ago',
      },
    ],
  },
  invoiceFlowPresets: [
    {
      id: 'storm-repair-balance',
      label: 'Hail & Valley Flashing Repair ($1,250)',
      jobReference: 'JOB-TX-8424 · EastSlope Shingle & Chimney Cricket',
      grossJobTotalUsd: 1750,
      depositCreditedUsd: 500,
      finalBalanceUsd: 1250,
      lineTitle: 'Final Balance — Storm Flashing & Shingle Remediation (Net of $500 Deposit)',
      memo: 'Replaced 18 hail-damaged tabs, custom bent copper cricket around chimney chase, sealed pipe collars. $500 deposit credited.',
    },
    {
      id: 'standing-seam-balance',
      label: 'Standing-Seam Porch Canopy ($2,450)',
      jobReference: 'JOB-TX-8431 · 24ga Bronze Standing-Seam Canopy',
      grossJobTotalUsd: 2950,
      depositCreditedUsd: 500,
      finalBalanceUsd: 2450,
      lineTitle: 'Final Balance — 24ga Standing-Seam Accent Roof (Net of $500 Deposit)',
      memo: 'Fabricated and seamed concealed-fastener bronze metal panels over front entryway with custom drip edge.',
    },
    {
      id: 'decking-ridge-balance',
      label: 'South-Slope Tear-Off & Ridge ($1,950)',
      jobReference: 'JOB-TX-8419 · Class 4 Section + Ice & Water Shield',
      grossJobTotalUsd: 2450,
      depositCreditedUsd: 500,
      finalBalanceUsd: 1950,
      lineTitle: 'Final Balance — South-Slope Shingle Replacement (Net of $500 Deposit)',
      memo: 'Completed tear-off, synthetic underlayment, copper valley flashing, ridge vents, and final magnetic nail sweep. $500 deposit credited.',
    },
  ],
  formPlaceholders: {
    name: 'Jordan Alvarez',
    email: 'jordan@example.com',
    phone: '(512) 555-0148',
    zip: '78746',
    address: '1420 Barton Creek Blvd, Austin, TX',
    notes: 'e.g., 16-year-old 3-tab shingles, water spot near chimney flashing after last week\'s storm...',
    invoiceCustomerName: 'Homeowner Full Name',
  },
  whopDefaults: {
    accountId: '',
    environment: 'production',
  },
}
