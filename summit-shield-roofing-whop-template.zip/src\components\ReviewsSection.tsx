import { Award, CheckCircle2, Quote, ShieldCheck, Star } from 'lucide-react'
import { roofingTemplate } from '#/config/roofingTemplate'
import { MotionReveal } from './MotionReveal'

const CREDENTIAL_STYLES = [
  'bg-gradient-to-br from-[var(--roof-copper)] to-[var(--roof-amber)] text-white',
  'bg-gradient-to-br from-emerald-600 to-teal-500 text-white',
  'bg-gradient-to-br from-sky-600 to-indigo-600 text-white',
  'bg-gradient-to-br from-[var(--roof-ink)] to-[#374151] text-white',
]

export function ReviewsSection() {
  const { reviews } = roofingTemplate

  return (
    <section id="reviews" className="border-b border-[var(--roof-border)] bg-white py-14 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <MotionReveal>
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-amber-300/60 bg-amber-50 px-3.5 py-1 text-xs font-bold tracking-wider text-amber-800 uppercase">
              <Award className="h-3.5 w-3.5 text-[var(--roof-copper)]" />
              <span>Verified Credentials & Homeowner Reviews</span>
            </div>
            <h2 className="font-display mt-3 text-3xl font-extrabold text-[var(--roof-ink)] sm:text-4xl">
              {reviews.headline}
            </h2>
            <p className="mt-3 text-base text-[#4B5563] sm:text-lg">{reviews.subheadline}</p>
          </div>
        </MotionReveal>

        {/* Trust Credentials strip */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {reviews.trustCredentials.map((cred, idx) => (
            <MotionReveal key={cred.title} delayMs={idx * 60}>
              <div className="flex h-full items-start gap-3 rounded-2xl border border-[var(--roof-border)] bg-[var(--roof-canvas)] p-4 shadow-2xs transition-all duration-300 hover:-translate-y-1 hover:border-[var(--roof-ink)]/25 hover:bg-white hover:shadow-md">
                <span
                  className={`mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl shadow-sm ${
                    CREDENTIAL_STYLES[idx % CREDENTIAL_STYLES.length]
                  }`}
                >
                  <ShieldCheck className="h-5 w-5" />
                </span>
                <div>
                  <div className="font-display text-sm font-bold text-[var(--roof-ink)]">
                    {cred.title}
                  </div>
                  <div className="mt-0.5 text-xs text-[#4B5563]">{cred.subtitle}</div>
                </div>
              </div>
            </MotionReveal>
          ))}
        </div>

        {/* Review Cards */}
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {reviews.items.map((review, idx) => (
            <MotionReveal key={review.id} delayMs={idx * 80}>
              <article className="flex h-full flex-col justify-between rounded-3xl border border-[var(--roof-border)] bg-gradient-to-b from-[var(--roof-canvas)] to-white p-6 shadow-xs transition-all duration-300 hover:-translate-y-1.5 hover:border-[var(--roof-copper)]/40 hover:shadow-[0_22px_44px_-18px_color-mix(in_srgb,var(--roof-copper)_20%,transparent)]">
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-0.5 text-amber-500">
                      {Array.from({ length: review.rating }).map((_, sIdx) => (
                        <Star key={sIdx} className="h-4 w-4 fill-amber-400 text-amber-500" />
                      ))}
                    </div>
                    <Quote className="h-5 w-5 text-[var(--roof-copper)]/40" />
                  </div>

                  <p className="mt-4 text-sm leading-relaxed text-[#1F2937]">
                    &ldquo;{review.quote}&rdquo;
                  </p>
                </div>

                <div className="mt-6 border-t border-[var(--roof-border)] pt-4">
                  <div className="font-display text-sm font-bold text-[var(--roof-ink)]">
                    {review.homeowner}
                  </div>
                  <div className="text-xs text-[#4B5563]">{review.neighborhood}</div>
                  <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/12 px-2.5 py-0.5 text-[11px] font-bold text-emerald-800">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                      {review.verifiedJobValue}
                    </span>
                    <span className="text-[11px] text-[#6B7280]">{review.dateLabel}</span>
                  </div>
                </div>
              </article>
            </MotionReveal>
          ))}
        </div>
      </div>
    </section>
  )
}
