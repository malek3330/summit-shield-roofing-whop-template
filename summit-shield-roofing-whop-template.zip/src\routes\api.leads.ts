import { createFileRoute } from '@tanstack/react-router'
import { roofingTemplate } from '#/config/roofingTemplate'
import { getAdminSession } from '#/server/auth'
import {
  createWhopServerClient,
  getResolvedPlans,
  handleWhopApiError,
  jsonResponse,
  requireAccountId,
  resolveAuthorizedRuntimeMode,
} from '#/server/whopServer'

interface EstimateLeadPayload {
  name?: string
  email?: string
  phone?: string
  address?: string
  zipCode?: string
  whopUsername?: string
  userId?: string
  serviceType?: 'inspection' | 'repair' | 'replacement' | 'tuneup'
  roofDetails?: string
  urgency?: string
  referrer?: string
  environmentMode?: 'production' | 'sandbox'
}

export const Route = createFileRoute('/api/leads')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const isAdmin = await getAdminSession(request)
        if (!isAdmin) {
          return jsonResponse(
            {
              ok: false,
              code: 'UNAUTHORIZED',
              message: 'Contractor Portal sign-in is required to view homeowner leads.',
            },
            401,
          )
        }

        try {
          const url = new URL(request.url)
          const mode = resolveAuthorizedRuntimeMode(url.searchParams.get('mode'), isAdmin)
          const accountId = requireAccountId(mode)
          const whop = createWhopServerClient(mode)
          const nowIso = new Date().toISOString()
          const thirtyDaysAgoIso = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()

          const [leadsResult, eventsResult, peopleResult] = await Promise.allSettled([
            whop.leads.list({
              account_id: accountId,
              first: 20,
            }),
            whop.events.list({
              account_id: accountId,
              from: thirtyDaysAgoIso,
              to: nowIso,
              event: 'pixel.lead,lead,pixel.custom:estimate_requested',
              first: 30,
            }),
            whop.people.list({
              account_id: accountId,
              event_name: ['pixel.lead', 'lead'],
              first: 25,
            }),
          ])

          const leads =
            leadsResult.status === 'fulfilled' ? leadsResult.value.data : []

          const leadsScopeLimited =
            leadsResult.status === 'rejected' &&
            Number((leadsResult.reason as { statusCode?: number } | undefined)?.statusCode) === 403

          const leadEvents =
            eventsResult.status === 'fulfilled'
              ? (eventsResult.value.data ?? []).filter(
                  (ev) =>
                    ev.event_name === 'lead' ||
                    ev.event_name === 'pixel.lead' ||
                    ev.custom_name === 'estimate_requested' ||
                    ev.event_name.includes('estimate_requested'),
                )
              : []

          const peopleLeads =
            peopleResult.status === 'fulfilled' ? peopleResult.value.data : []

          return jsonResponse({
            ok: true,
            environment: mode,
            leads,
            leadEvents,
            peopleLeads,
            leadsScopeLimited,
          })
        } catch (error) {
          return handleWhopApiError(error, 'listing Whop leads')
        }
      },

      POST: async ({ request }) => {
        try {
          const isAdmin = await getAdminSession(request)
          const body = (await request.json().catch(() => null)) as EstimateLeadPayload | null
          if (!body) {
            return jsonResponse(
              { ok: false, code: 'INVALID_JSON', message: 'Invalid JSON request body.' },
              400,
            )
          }

          const mode = resolveAuthorizedRuntimeMode(body.environmentMode, isAdmin)
          const name = body.name?.trim() ?? ''
          const email = body.email?.trim() ?? ''
          const phone = body.phone?.trim() ?? ''
          const address = body.address?.trim() ?? ''
          const zipCode = body.zipCode?.trim() ?? ''
          const serviceType = body.serviceType ?? 'replacement'

          if (!name || !email || !email.includes('@')) {
            return jsonResponse(
              {
                ok: false,
                code: 'VALIDATION_ERROR',
                message:
                  'Please provide your full name and a valid email address for your estimate.',
              },
              400,
            )
          }

          const accountId = requireAccountId(mode)
          const whop = createWhopServerClient(mode)
          const plans = getResolvedPlans(mode)

          const planKey =
            serviceType === 'inspection'
              ? 'inspection'
              : serviceType === 'tuneup'
                ? 'tuneup'
                : 'deposit'
          const mappedProduct = plans[planKey]
          const productId = mappedProduct.isRealProductId ? mappedProduct.productId : undefined
          const variantId = mappedProduct.isRealVariantId ? mappedProduct.variantId : undefined

          // Only authenticated portal operators may explicitly query by Whop handle/userId
          let resolvedUserId: string | undefined
          if (isAdmin) {
            const rawHandle = (body.whopUsername ?? '').trim().replace(/^@+/, '')
            const explicitUserId = body.userId?.trim() ?? ''

            if (explicitUserId.startsWith('user_')) {
              resolvedUserId = explicitUserId
            } else if (rawHandle) {
              try {
                const user = await whop.users.retrieve({ id: rawHandle })
                if (user?.id) {
                  resolvedUserId = user.id
                }
              } catch {
                return jsonResponse(
                  {
                    ok: false,
                    code: 'WHOP_USER_NOT_FOUND',
                    message: `Could not find Whop user "${body.whopUsername?.trim()}".`,
                  },
                  400,
                )
              }
            }
          }

          if (!resolvedUserId) {
            try {
              const membersPage = await whop.members.list({
                account_id: accountId,
                query: email,
                first: 10,
              })
              const candidate = membersPage.data.find(
                (m) => m.email?.toLowerCase() === email.toLowerCase(),
              )
              if (candidate?.user?.id) {
                resolvedUserId = candidate.user.id
              }
            } catch {
              // Non-blocking lookup
            }
          }

          if (!resolvedUserId) {
            try {
              const person = await whop.people.retrieve({
                account_id: accountId,
                id: email,
              })
              const personUserId = person.user?.id ?? person.user_ids?.[0]
              if (personUserId) {
                resolvedUserId = personUserId
              }
            } catch {
              // First-time website visitors may not have a person record yet
            }
          }

          const referrerHeader = request.headers.get('referer')
          const referrerUrl = body.referrer?.trim() || referrerHeader || undefined

          const capturedEvent = await whop.events
            .create({
              account_id: accountId,
              action_source: 'website',
              event_name: 'lead',
              ...(productId ? { product_id: productId } : {}),
              ...(variantId ? { plan_id: variantId } : {}),
              ...(referrerUrl ? { url: referrerUrl } : {}),
              currency: 'usd',
              value: mappedProduct.priceUsd,
              user: {
                email,
                name,
                ...(phone ? { phone } : {}),
                ...(zipCode ? { postal_code: zipCode } : {}),
                ...(resolvedUserId ? { user_id: resolvedUserId } : {}),
              },
            })
            .catch(() => null)

          if (!resolvedUserId) {
            try {
              const createdPerson = await whop.people.retrieve({
                account_id: accountId,
                id: email,
              })
              const personUserId = createdPerson.user?.id ?? createdPerson.user_ids?.[0]
              if (personUserId) {
                resolvedUserId = personUserId
              }
            } catch {
              // Ignore if person has no linked Whop user ID
            }
          }

          // Create formal Whop CRM Lead record regardless of whether visitor already has a Whop user_id
          const createdLead = await whop.leads
            .create({
              account_id: accountId,
              ...(productId ? { product_id: productId } : {}),
              ...(resolvedUserId ? { user_id: resolvedUserId } : {}),
              ...(referrerUrl ? { referrer: referrerUrl } : {}),
              metadata: {
                source: `${roofingTemplate.brand.shortName.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_estimate_form`,
                homeowner_name: name,
                homeowner_email: email,
                homeowner_phone: phone || 'not_provided',
                property_address: address || 'not_provided',
                zip_code: zipCode || 'not_provided',
                service_interest: serviceType,
                roof_details: body.roofDetails?.trim() || 'standard_inquiry',
                urgency: body.urgency?.trim() || 'within_2_weeks',
                ...(capturedEvent?.id ? { whop_event_id: capturedEvent.id } : {}),
                submitted_at: new Date().toISOString(),
              },
            })
            .catch(() => null)

          if (!createdLead && !capturedEvent?.id) {
            return jsonResponse(
              {
                ok: false,
                code: 'LEAD_CAPTURE_FAILED',
                message: 'Unable to record estimate request at this moment. Please call our office.',
              },
              502,
            )
          }

          const referenceCode = `EST-${Math.floor(100000 + Math.random() * 900000)}`

          if (!isAdmin) {
            // Public response strictly redacts internal IDs (`lead_...`, `evnt_...`, `user_...`)
            return jsonResponse(
              {
                ok: true,
                mode: 'submitted',
                referenceCode,
                leadRecorded: true,
                message:
                  'Your written estimate request has been received. An estimator will review satellite roof imagery and reach out within 1 business day.',
              },
              201,
            )
          }

          return jsonResponse(
            {
              ok: true,
              mode: createdLead ? 'lead_created' : 'event_captured',
              referenceCode,
              leadRecorded: true,
              lead: createdLead,
              eventId: capturedEvent?.id ?? null,
              resolvedUserId: resolvedUserId ?? null,
              message: createdLead
                ? 'Estimate logged in both Whop Leads API (`lead_...`) and Events CRM.'
                : 'Estimate captured via server-side Whop Events API (`evnt_...`).',
            },
            createdLead ? 201 : 200,
          )
        } catch (error) {
          return handleWhopApiError(error, 'creating estimate lead')
        }
      },
    },
  },
})
