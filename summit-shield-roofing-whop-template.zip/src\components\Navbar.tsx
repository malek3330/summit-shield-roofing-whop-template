import { useEffect, useState } from 'react'
import { Link } from '@tanstack/react-router'
import { Menu, Phone, ShieldCheck, Sparkles, X } from 'lucide-react'
import { roofingTemplate } from '#/config/roofingTemplate'

interface NavbarProps {
  onSelectInspection?: () => void
}

const NAV_LINKS: Array<{ label: string; to: '/' | '/deposit'; hash?: string }> = [
  { label: 'Services', to: '/', hash: 'services' },
  { label: 'Plans & Booking', to: '/', hash: 'checkout-flow' },
  { label: 'Billing Flow', to: '/', hash: 'invoice-flow' },
  { label: 'Financing', to: '/', hash: 'financing' },
  { label: 'Service Area', to: '/', hash: 'service-area' },
  { label: 'Reviews', to: '/', hash: 'reviews' },
]

export function Navbar({ onSelectInspection }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [scrollProgress, setScrollProgress] = useState(0)
  const [scrolled, setScrolled] = useState(false)
  const logoUrl = roofingTemplate.brand.logoUrl?.trim()

  useEffect(() => {
    const updateScroll = () => {
      const top = window.scrollY
      const docHeight = document.documentElement.scrollHeight - window.innerHeight
      setScrolled(top > 24)
      setScrollProgress(docHeight > 0 ? Math.min(100, Math.round((top / docHeight) * 100)) : 0)
    }
    updateScroll()
    window.addEventListener('scroll', updateScroll, { passive: true })
    return () => window.removeEventListener('scroll', updateScroll)
  }, [])

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-300 ${
        scrolled
          ? 'border-b border-white/12 bg-[var(--roof-obsidian)]/94 shadow-[0_12px_32px_-12px_rgba(0,0,0,0.55)] backdrop-blur-xl'
          : 'border-b border-white/10 bg-[var(--roof-obsidian)]/88 backdrop-blur-lg'
      }`}
    >
      {/* Dynamic Brand-Accent-Emerald scroll indicator */}
      <div className="h-[2.5px] w-full bg-white/5">
        <div
          className="h-full bg-gradient-to-r from-[var(--roof-copper)] via-[var(--roof-amber)] to-[var(--roof-forest)] transition-[width] duration-150"
          style={{ width: `${scrollProgress}%` }}
        />
      </div>

      <div className="mx-auto flex max-w-[1360px] items-center justify-between gap-2 px-4 py-2.5 sm:px-5 xl:gap-3">
        {/* Brand lockup */}
        <Link
          to="/"
          hash="top"
          className="group flex shrink-0 items-center gap-2.5 focus-visible:rounded-md"
        >
          {logoUrl ? (
            <img
              src={logoUrl}
              alt={`${roofingTemplate.brand.name} logo`}
              className="h-9 w-9 shrink-0 rounded-xl border border-white/15 bg-white/5 object-cover shadow-md transition-transform duration-300 group-hover:scale-105 sm:h-10 sm:w-10"
            />
          ) : (
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-[var(--roof-copper)] via-[var(--roof-copper-deep)] to-[var(--roof-amber)] text-white shadow-[0_0_24px_-4px_color-mix(in_srgb,var(--roof-copper)_65%,transparent)] transition-transform duration-300 group-hover:scale-105 sm:h-10 sm:w-10">
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                aria-hidden="true"
                className="stroke-current"
              >
                <path
                  d="M2.5 12L12 4L21.5 12"
                  strokeWidth="2.3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M5.5 10.5V19.5H18.5V10.5"
                  strokeWidth="1.9"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path d="M9.5 19.5V14H14.5V19.5" strokeWidth="1.9" strokeLinecap="round" />
              </svg>
            </div>
          )}
          <div>
            <div className="font-display text-base font-bold tracking-tight whitespace-nowrap text-white">
              <span className="sm:hidden">{roofingTemplate.brand.shortName}</span>
              <span className="hidden sm:inline">{roofingTemplate.brand.name}</span>
            </div>
            <div className="hidden max-w-[205px] items-center gap-1.5 text-[11px] font-medium text-white/65 sm:flex">
              <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-emerald-400" />
              <span className="truncate">{roofingTemplate.brand.licenseNumber}</span>
            </div>
          </div>
        </Link>

        {/* Desktop navigation */}
        <nav aria-label="Primary" className="hidden shrink-0 items-center gap-0.5 lg:flex">
          {NAV_LINKS.map((item) => (
            <Link
              key={`${item.to}-${item.hash ?? ''}`}
              to={item.to}
              hash={item.hash}
              className="rounded-lg px-2.5 py-1.5 text-[12.5px] font-medium whitespace-nowrap text-white/75 transition-all hover:bg-white/8 hover:text-white xl:text-[13px]"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Actions */}
        <div className="flex shrink-0 items-center gap-2">
          <a
            href={roofingTemplate.brand.phoneHref}
            className="hidden min-h-9 shrink-0 items-center gap-1.5 rounded-xl border border-white/15 bg-white/6 px-2.5 py-1.5 text-xs font-semibold whitespace-nowrap text-white/90 transition-all hover:border-[var(--roof-amber)]/50 hover:bg-white/12 xl:inline-flex"
          >
            <Phone className="h-3.5 w-3.5 text-[var(--roof-amber-light)]" />
            <span className="font-mono-num whitespace-nowrap">{roofingTemplate.brand.phoneDisplay}</span>
          </a>

          <Link
            to="/book/$slug"
            params={{ slug: 'inspection' }}
            onClick={() => onSelectInspection?.()}
            className="btn-shimmer inline-flex min-h-9 shrink-0 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-[var(--roof-copper)] to-[var(--roof-amber)] px-3.5 py-1.5 text-xs font-bold whitespace-nowrap text-white shadow-[0_6px_20px_-4px_color-mix(in_srgb,var(--roof-copper)_65%,transparent)] transition-all hover:-translate-y-0.5 hover:shadow-[0_10px_24px_-4px_color-mix(in_srgb,var(--roof-copper)_80%,transparent)] 2xl:px-4 2xl:text-[13px]"
          >
            <Sparkles className="hidden h-3.5 w-3.5 sm:inline" />
            <span>Book ${roofingTemplate.plans.inspection.priceUsd} Check</span>
          </Link>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            className="inline-flex h-11 w-11 items-center justify-center rounded-xl border border-white/15 bg-white/8 text-white transition-colors hover:bg-white/15 lg:hidden"
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      {mobileOpen && (
        <div className="border-t border-white/10 bg-[var(--roof-obsidian)]/98 px-4 py-4 backdrop-blur-xl lg:hidden">
          <div className="flex flex-col gap-1.5">
            {NAV_LINKS.map((item) => (
              <Link
                key={`mob-${item.to}-${item.hash ?? ''}`}
                to={item.to}
                hash={item.hash}
                onClick={() => setMobileOpen(false)}
                className="flex min-h-11 items-center rounded-xl px-3 text-base font-medium text-white/85 transition-colors hover:bg-white/8 hover:text-white"
              >
                {item.label}
              </Link>
            ))}
            <Link
              to="/"
              hash="estimate-form"
              onClick={() => setMobileOpen(false)}
              className="flex min-h-11 items-center rounded-xl px-3 text-base font-semibold text-[var(--roof-copper-light)] hover:bg-white/8"
            >
              Request Free Estimate
            </Link>
            <div className="mt-2 grid grid-cols-2 gap-2 border-t border-white/10 pt-3">
              <a
                href={roofingTemplate.brand.phoneHref}
                className="flex min-h-11 items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/8 px-3 text-sm font-semibold text-white"
              >
                <Phone className="h-4 w-4 text-[var(--roof-amber-light)]" />
                <span>Call Crew</span>
              </a>
              <Link
                to="/deposit"
                onClick={() => setMobileOpen(false)}
                className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[var(--roof-copper)] to-[var(--roof-amber)] px-3 text-sm font-bold text-white"
              >
                <span>Pay ${roofingTemplate.plans.deposit.priceUsd} Deposit</span>
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
