import { readServerEnv } from '#/server/whopServer'

const ADMIN_COOKIE_NAME = 'summit_admin_session'
const RECEIPT_COOKIE_NAME = 'summit_buyer_receipt'
const ADMIN_SESSION_TTL_SEC = 8 * 60 * 60
const RECEIPT_TTL_SEC = 2 * 60 * 60

interface AdminTokenPayload {
  role: 'contractor'
  exp: number
}

interface ReceiptTokenPayload {
  ids: string[]
  exp: number
}

function toBase64Url(bytes: Uint8Array): string {
  let binary = ''
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i])
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
}

function fromBase64Url(str: string): Uint8Array | null {
  try {
    const padded = str.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((str.length + 3) % 4)
    const binary = atob(padded)
    const bytes = new Uint8Array(binary.length)
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i)
    }
    return bytes
  } catch {
    return null
  }
}

async function sha256Bytes(value: string): Promise<Uint8Array> {
  const encoded = new TextEncoder().encode(value)
  const digest = await crypto.subtle.digest('SHA-256', encoded)
  return new Uint8Array(digest)
}

function constantTimeEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false
  let diff = 0
  for (let i = 0; i < a.length; i++) {
    diff |= a[i] ^ b[i]
  }
  return diff === 0
}

function getSigningKeyMaterial(): string | undefined {
  return readServerEnv('SESSION_SECRET') ?? readServerEnv('ADMIN_PASSCODE')
}

async function signPayload(payloadB64: string): Promise<string | null> {
  const secret = getSigningKeyMaterial()
  if (!secret) return null

  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  )
  const sigBuffer = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(payloadB64))
  return toBase64Url(new Uint8Array(sigBuffer))
}

async function signToken(payload: object): Promise<string | null> {
  const payloadBytes = new TextEncoder().encode(JSON.stringify(payload))
  const payloadB64 = toBase64Url(payloadBytes)
  const sigB64 = await signPayload(payloadB64)
  if (!sigB64) return null
  return `${payloadB64}.${sigB64}`
}

async function verifyToken<T>(token: string | undefined): Promise<T | null> {
  if (!token) return null
  const parts = token.split('.')
  if (parts.length !== 2) return null

  const [payloadB64, sigB64] = parts
  const expectedSigB64 = await signPayload(payloadB64)
  if (!expectedSigB64) return null

  const a = new TextEncoder().encode(sigB64)
  const b = new TextEncoder().encode(expectedSigB64)
  if (!constantTimeEqual(a, b)) return null

  const rawBytes = fromBase64Url(payloadB64)
  if (!rawBytes) return null

  try {
    const parsed = JSON.parse(new TextDecoder().decode(rawBytes)) as T & { exp?: number }
    if (typeof parsed.exp !== 'number' || parsed.exp < Math.floor(Date.now() / 1000)) {
      return null
    }
    return parsed
  } catch {
    return null
  }
}

export function parseCookieHeader(request: Request): Record<string, string> {
  const header = request.headers.get('cookie')
  if (!header) return {}
  const map: Record<string, string> = {}
  for (const part of header.split(';')) {
    const eqIdx = part.indexOf('=')
    if (eqIdx <= 0) continue
    const k = part.slice(0, eqIdx).trim()
    const v = part.slice(eqIdx + 1).trim()
    try {
      map[k] = decodeURIComponent(v)
    } catch {
      map[k] = v
    }
  }
  return map
}

function buildCookieString(
  name: string,
  value: string,
  maxAgeSec: number,
  request: Request,
): string {
  const isHttps = new URL(request.url).protocol === 'https:'
  const parts = [
    `${name}=${encodeURIComponent(value)}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${maxAgeSec}`,
  ]
  if (isHttps) {
    parts.push('Secure')
  }
  return parts.join('; ')
}

export function isAdminPasscodeConfigured(): boolean {
  return Boolean(readServerEnv('ADMIN_PASSCODE'))
}

export async function verifyAdminPasscode(candidate: string): Promise<boolean> {
  const expected = readServerEnv('ADMIN_PASSCODE')
  if (!expected || !candidate) return false
  const [hashA, hashB] = await Promise.all([sha256Bytes(candidate), sha256Bytes(expected)])
  return constantTimeEqual(hashA, hashB)
}

export async function createAdminSetCookie(request: Request): Promise<string | null> {
  const payload: AdminTokenPayload = {
    role: 'contractor',
    exp: Math.floor(Date.now() / 1000) + ADMIN_SESSION_TTL_SEC,
  }
  const token = await signToken(payload)
  if (!token) return null
  return buildCookieString(ADMIN_COOKIE_NAME, token, ADMIN_SESSION_TTL_SEC, request)
}

export function createAdminClearCookie(request: Request): string {
  return buildCookieString(ADMIN_COOKIE_NAME, '', 0, request)
}

export async function getAdminSession(request: Request): Promise<boolean> {
  if (!isAdminPasscodeConfigured()) return false
  const cookies = parseCookieHeader(request)
  const payload = await verifyToken<AdminTokenPayload>(cookies[ADMIN_COOKIE_NAME])
  return payload?.role === 'contractor'
}

export async function createBuyerReceiptSetCookie(
  request: Request,
  newReceiptId: string,
): Promise<string | null> {
  const cookies = parseCookieHeader(request)
  const existing = await verifyToken<ReceiptTokenPayload>(cookies[RECEIPT_COOKIE_NAME])
  const ids = Array.from(
    new Set([newReceiptId, ...(existing?.ids ?? [])].filter(Boolean)),
  ).slice(0, 12)

  const payload: ReceiptTokenPayload = {
    ids,
    exp: Math.floor(Date.now() / 1000) + RECEIPT_TTL_SEC,
  }
  const token = await signToken(payload)
  if (!token) return null
  return buildCookieString(RECEIPT_COOKIE_NAME, token, RECEIPT_TTL_SEC, request)
}

export async function hasBuyerReceiptAccess(
  request: Request,
  targetId: string,
): Promise<boolean> {
  const cookies = parseCookieHeader(request)
  const payload = await verifyToken<ReceiptTokenPayload>(cookies[RECEIPT_COOKIE_NAME])
  return Boolean(payload?.ids?.includes(targetId))
}
