import { useEffect, useState } from 'react'
import { Activity, ChevronDown, ChevronUp, Sparkles, X } from 'lucide-react'
import { subscribeWhopPixelEvents, trackWhopEvent, type PixelEventRecord } from '#/lib/whopPixel'

interface PixelDebugPillProps {
  forceOpen?: boolean
  onClose?: () => void
}

export function PixelDebugPill({ forceOpen = false, onClose }: PixelDebugPillProps) {
  const [events, setEvents] = useState<PixelEventRecord[]>([])
  const [debugParamActive, setDebugParamActive] = useState(false)
  const [expanded, setExpanded] = useState(false)

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const hasDebug = new URLSearchParams(window.location.search).get('debug') === '1'
      setDebugParamActive(hasDebug)
      if (hasDebug) setExpanded(true)
    }

    const unsubscribe = subscribeWhopPixelEvents((next) => {
      setEvents(next)
    })

    return () => unsubscribe()
  }, [])

  useEffect(() => {
    if (forceOpen) setExpanded(true)
  }, [forceOpen])

  const shouldRender = debugParamActive || forceOpen || expanded
  if (!shouldRender) {
    // Always keep a discreet floating bottom-left pixel status indicator on desktop/mobile when events exist or ?debug=1
    return (
      <div className="fixed bottom-16 left-3 z-40 lg:bottom-4 lg:left-4 print:hidden">
        <button
          type="button"
          onClick={() => setExpanded(true)}
          className="font-mono-num inline-flex items-center gap-2 rounded-full border border-white/15 bg-[var(--roof-obsidian)]/90 px-3 py-1.5 text-[11px] font-semibold text-white/85 shadow-lg backdrop-blur-md transition-all hover:border-[var(--roof-copper-light)] hover:text-white"
          title="Inspect live Whop Pixel whop.track events"
        >
          <span className="h-2 w-2 rounded-full bg-emerald-400" />
          <Activity className="h-3.5 w-3.5 text-[var(--roof-copper-light)]" />
          <span>Pixel ({events.length})</span>
        </button>
      </div>
    )
  }

  return (
    <div
      className="fixed bottom-16 left-3 z-40 w-[min(23rem,calc(100vw-1.5rem))] lg:bottom-4 lg:left-4 print:hidden"
      aria-live="polite"
    >
      <div className="overflow-hidden rounded-2xl border border-white/15 bg-[var(--roof-obsidian)]/96 text-white shadow-2xl backdrop-blur-xl">
        <div className="flex items-center justify-between border-b border-white/10 px-3.5 py-2.5">
          <div className="flex items-center gap-2 text-xs font-bold">
            <span className="h-2 w-2 rounded-full bg-emerald-400" />
            <span className="font-mono-num">Whop Pixel Log ({events.length})</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setExpanded((prev) => !prev)}
              aria-label={expanded ? 'Collapse pixel log' : 'Expand pixel log'}
              className="inline-flex h-7 w-7 items-center justify-center rounded-lg text-white/70 hover:bg-white/10 hover:text-white"
            >
              {expanded ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
            </button>
            <button
              type="button"
              onClick={() => {
                setExpanded(false)
                setDebugParamActive(false)
                onClose?.()
              }}
              aria-label="Hide pixel log"
              className="inline-flex h-7 w-7 items-center justify-center rounded-lg text-white/70 hover:bg-white/10 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {expanded && (
          <div className="p-3 text-xs">
            <div className="mb-2.5 flex flex-wrap gap-1.5">
              {(
                [
                  { label: '+ service_viewed', name: 'service_viewed' as const },
                  { label: '+ deposit_started', name: 'deposit_started' as const },
                  { label: '+ estimate_requested', name: 'estimate_requested' as const },
                ]
              ).map((btn) => (
                <button
                  key={btn.name}
                  type="button"
                  onClick={() =>
                    trackWhopEvent(btn.name, {
                      source: 'pixel_debug_widget',
                    })
                  }
                  className="font-mono-num inline-flex items-center gap-1 rounded-lg border border-white/15 bg-white/8 px-2 py-1 text-[10px] font-semibold text-white/90 hover:border-[var(--roof-copper-light)]"
                >
                  <Sparkles className="h-2.5 w-2.5 text-[var(--roof-amber-light)]" />
                  {btn.label}
                </button>
              ))}
            </div>

            {events.length === 0 ? (
              <div className="rounded-xl border border-white/10 bg-white/[0.04] p-3 text-[11px] text-white/65">
                Interact with a service card, checkout plan, or estimate form to capture live{' '}
                <code className="font-mono-num text-[var(--roof-copper-light)]">whop.track()</code>{' '}
                events.
              </div>
            ) : (
              <ul className="max-h-56 space-y-2 overflow-y-auto pr-1">
                {events.slice(0, 12).map((evt) => (
                  <li
                    key={evt.id}
                    className="rounded-xl border border-white/10 bg-white/[0.05] p-2.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono-num font-bold text-[var(--roof-copper-light)]">
                        whop.track(&apos;{evt.eventName}&apos;)
                      </span>
                      <span
                        className={`font-mono-num rounded px-1.5 py-0.5 text-[9px] font-bold uppercase ${
                          evt.deliveredToWhopPixel
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-amber-500/20 text-amber-200'
                        }`}
                      >
                        {evt.deliveredToWhopPixel ? 'SENT' : 'QUEUED'}
                      </span>
                    </div>
                    <div className="font-mono-num mt-1 truncate text-[10px] text-white/65">
                      {JSON.stringify(evt.payload)}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
