import { useEffect, useState } from 'react'
import {
  AlertCircle,
  CheckCircle2,
  ClipboardList,
  Loader2,
  Phone,
  Send,
  ShieldCheck,
} from 'lucide-react'
import { roofingTemplate, type RoofingServiceItem } from '#/config/roofingTemplate'
import type { VaultedCustomerRecord } from '#/lib/types'
import { trackWhopEvent } from '#/lib/whopPixel'

interface EstimateLeadFormProps {
  preselectedService: RoofingServiceItem | null
  vaultedCustomer?: VaultedCustomerRecord | null
  environmentMode?: 'production' | 'sandbox'
  adminAuthenticated?: boolean
}

interface EstimateCaptureOutcome {
  mode: string
  referenceCode: string
  eventId?: string | null
  leadId?: string | null
  message: string
}

const INCLUDED_STEPS = [
  {
    step: '01',
    title: 'Satellite Roof Pitch & Square Measurement',
    detail: 'We calculate exact shingle bundles, ridge length, and valley flashing before visiting.',
  },
  {
    step: '02',
    title: 'Side-by-Side Repair vs. Replacement Quote',
    detail: 'Compare honest repair scope costs alongside Class 4 shingle and standing-seam metal tiers.',
  },
  {
    step: '03',
    title: 'Insurer-Ready Storm & Hail Documentation',
    detail: 'High-res drone and moisture checks structured cleanly if you file an insurance claim.',
  },
]

export function EstimateLeadForm({
  preselectedService,
  vaultedCustomer,
  environmentMode = 'production',
  adminAuthenticated = false,
}: EstimateLeadFormProps) {
  const { formPlaceholders, brand, plans } = roofingTemplate
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [address, setAddress] = useState('')
  const [zipCode, setZipCode] = useState('')
  const [serviceType, setServiceType] = useState<'inspection' | 'repair' | 'replacement' | 'tuneup'>(
    preselectedService?.id ?? 'replacement',
  )
  const [urgency, setUrgency] = useState('within_2_weeks')
  const [roofDetails, setRoofDetails] = useState('')

  const [submitting, setSubmitting] = useState(false)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)
  const [captureOutcome, setCaptureOutcome] = useState<EstimateCaptureOutcome | null>(null)

  useEffect(() => {
    if (preselectedService) {
      setServiceType(preselectedService.id)
    }
  }, [preselectedService])

  useEffect(() => {
    if (!adminAuthenticated || !vaultedCustomer) return
    if (vaultedCustomer.customerName && !name) setName(vaultedCustomer.customerName)
    if (vaultedCustomer.email && !email) setEmail(vaultedCustomer.email)
  }, [adminAuthenticated, vaultedCustomer, name, email])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setErrorMsg(null)
    setCaptureOutcome(null)
    setSubmitting(true)

    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          address: address.trim(),
          zipCode: zipCode.trim(),
          serviceType,
          urgency,
          roofDetails: roofDetails.trim(),
          referrer: typeof window !== 'undefined' ? window.location.href : undefined,
          environmentMode,
        }),
      })

      const data = (await res.json()) as {
        ok?: boolean
        mode?: string
        referenceCode?: string
        lead?: { id?: string } | null
        eventId?: string | null
        message?: string
      }

      if (!res.ok || !data.ok) {
        throw new Error(data.message || 'Unable to submit quote request right now.')
      }

      const refCode = data.referenceCode ?? `EST-${Date.now().toString().slice(-6)}`
      trackWhopEvent('estimate_requested', {
        event_id: refCode,
        service_type: serviceType,
        zip_code: zipCode.trim() || 'unspecified',
        urgency,
        form_id: 'roof_estimate_lead_form',
        lead_recorded: Boolean(data.lead?.id),
      })
      trackWhopEvent('lead', {
        event_id: refCode,
        service_type: serviceType,
        value: serviceType === 'inspection' ? plans.inspection.priceUsd : 500,
        currency: 'USD',
      })

      setCaptureOutcome({
        mode: data.mode ?? 'submitted',
        referenceCode: refCode,
        leadId: data.lead?.id ?? null,
        eventId: data.eventId ?? null,
        message:
          data.message ||
          'Thank you! Our senior estimator will prepare your written roof assessment and reply within 1 business day.',
      })
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to send estimate request.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <section
      id="estimate-form"
      className="border-b border-[var(--roof-border)] bg-gradient-to-b from-[var(--roof-canvas)] to-[var(--roof-surface)]/85 py-14 sm:py-20"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-start gap-10 lg:grid-cols-12">
          {/* Left intro & homeowner expectations */}
          <div className="lg:col-span-5">
            <div className="inline-flex items-center gap-2 rounded-full border border-[var(--roof-copper)]/25 bg-white px-3.5 py-1 text-xs font-bold tracking-wider text-[var(--roof-copper-deep)] uppercase shadow-2xs">
              <ClipboardList className="h-3.5 w-3.5 text-[var(--roof-copper)]" />
              <span>Free Written Estimate · 24-Hr Response</span>
            </div>
            <h2 className="font-display mt-3 text-3xl font-extrabold text-[var(--roof-ink)] sm:text-4xl">
              Request a Free Written Roof Estimate.
            </h2>
            <p className="mt-3 text-base leading-relaxed text-[#4B5563]">
              Share your property details and timeline below. Our estimators review satellite
              imagery and deliver an itemized repair or replacement proposal with zero obligation.
            </p>

            {/* Emergency hotline box */}
            <div className="mt-6 rounded-3xl border border-white/10 bg-gradient-to-br from-[var(--roof-obsidian)] to-[var(--roof-midnight)] p-5 text-white shadow-xl">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold tracking-wider text-[var(--roof-copper-light)] uppercase">
                  24/7 Active Leak & Storm Tarp Dispatch
                </span>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-[10px] font-bold text-emerald-300">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
                  CREWS READY
                </span>
              </div>
              <a
                href={brand.phoneHref}
                className="font-mono-num mt-2 inline-flex items-center gap-2 text-2xl font-extrabold text-white transition-colors hover:text-[var(--roof-amber-light)]"
              >
                <Phone className="h-5 w-5 text-[var(--roof-copper)]" />
                <span>{brand.phoneDisplay}</span>
              </a>
              <p className="mt-2 text-xs text-white/70">{brand.serviceHours}</p>
            </div>

            {/* Clean What Happens Next Homeowner Guide */}
            <div className="mt-6 rounded-3xl border border-[var(--roof-border)] bg-white p-5 shadow-xs">
              <div className="flex items-center gap-2 border-b border-[var(--roof-surface)] pb-3">
                <ShieldCheck className="h-4 w-4 text-emerald-600" />
                <h3 className="font-display text-sm font-bold text-[var(--roof-ink)]">
                  What Happens After You Submit
                </h3>
              </div>
              <ol className="mt-4 space-y-3.5">
                {INCLUDED_STEPS.map((item) => (
                  <li key={item.step} className="flex items-start gap-3">
                    <span className="font-mono-num flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-[var(--roof-copper)]/12 text-[11px] font-bold text-[var(--roof-copper-deep)]">
                      {item.step}
                    </span>
                    <div>
                      <div className="text-xs font-bold text-[var(--roof-ink)]">{item.title}</div>
                      <p className="mt-0.5 text-xs leading-relaxed text-[#4B5563]">{item.detail}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </div>
          </div>

          {/* Right Form Card */}
          <div className="lg:col-span-7">
            <form
              onSubmit={handleSubmit}
              className="rounded-3xl border border-[var(--roof-border)] bg-white p-6 shadow-[0_24px_60px_-24px_rgba(17,24,39,0.16)] sm:p-8"
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label htmlFor="lead-name" className="block text-xs font-semibold text-[#141A21]">
                    Full Name *
                  </label>
                  <input
                    id="lead-name"
                    required
                    type="text"
                    placeholder={formPlaceholders.name}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="mt-1.5 min-h-11 w-full rounded-xl border border-[#D8D1C4] bg-[var(--roof-surface)]/45 px-3.5 text-sm text-[#141A21]"
                  />
                </div>

                <div>
                  <label htmlFor="lead-email" className="block text-xs font-semibold text-[#141A21]">
                    Email Address *
                  </label>
                  <input
                    id="lead-email"
                    required
                    type="email"
                    placeholder={formPlaceholders.email}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="mt-1.5 min-h-11 w-full rounded-xl border border-[#D8D1C4] bg-[var(--roof-surface)]/45 px-3.5 text-sm text-[#141A21]"
                  />
                </div>

                <div>
                  <label htmlFor="lead-phone" className="block text-xs font-semibold text-[#141A21]">
                    Phone Number
                  </label>
                  <input
                    id="lead-phone"
                    type="tel"
                    placeholder={formPlaceholders.phone}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="mt-1.5 min-h-11 w-full rounded-xl border border-[#D8D1C4] bg-[var(--roof-surface)]/45 px-3.5 text-sm text-[#141A21]"
                  />
                </div>

                <div>
                  <label htmlFor="lead-zip" className="block text-xs font-semibold text-[#141A21]">
                    Property ZIP Code
                  </label>
                  <input
                    id="lead-zip"
                    type="text"
                    inputMode="numeric"
                    placeholder={formPlaceholders.zip}
                    value={zipCode}
                    onChange={(e) => setZipCode(e.target.value)}
                    className="font-mono-num mt-1.5 min-h-11 w-full rounded-xl border border-[#D8D1C4] bg-[var(--roof-surface)]/45 px-3.5 text-sm text-[#141A21]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label
                    htmlFor="lead-address"
                    className="block text-xs font-semibold text-[#141A21]"
                  >
                    Street Address (For Satellite Aerial Measurement)
                  </label>
                  <input
                    id="lead-address"
                    type="text"
                    placeholder={formPlaceholders.address}
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="mt-1.5 min-h-11 w-full rounded-xl border border-[#D8D1C4] bg-[var(--roof-surface)]/45 px-3.5 text-sm text-[#141A21]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="lead-service"
                    className="block text-xs font-semibold text-[#141A21]"
                  >
                    Service Needed
                  </label>
                  <select
                    id="lead-service"
                    value={serviceType}
                    onChange={(e) =>
                      setServiceType(
                        e.target.value as 'inspection' | 'repair' | 'replacement' | 'tuneup',
                      )
                    }
                    className="mt-1.5 min-h-11 w-full rounded-xl border border-[#D8D1C4] bg-[var(--roof-surface)]/45 px-3.5 text-sm text-[#141A21]"
                  >
                    <option value="replacement">Full Roof Replacement (Shingle or Metal)</option>
                    <option value="inspection">
                      {plans.inspection.title} (${plans.inspection.priceUsd})
                    </option>
                    <option value="repair">Active Leak / Flashing Storm Repair</option>
                    <option value="tuneup">
                      {plans.tuneup.title} (${plans.tuneup.priceUsd})
                    </option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="lead-urgency"
                    className="block text-xs font-semibold text-[#141A21]"
                  >
                    Project Timeline
                  </label>
                  <select
                    id="lead-urgency"
                    value={urgency}
                    onChange={(e) => setUrgency(e.target.value)}
                    className="mt-1.5 min-h-11 w-full rounded-xl border border-[#D8D1C4] bg-[var(--roof-surface)]/45 px-3.5 text-sm text-[#141A21]"
                  >
                    <option value="emergency_24h">Emergency Leak / Tarping (24 Hr)</option>
                    <option value="this_week">This Week (Storm Damage / Claim)</option>
                    <option value="within_2_weeks">Within 2–4 Weeks</option>
                    <option value="planning_budget">Planning & Financing Quote</option>
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label
                    htmlFor="lead-notes"
                    className="block text-xs font-semibold text-[#141A21]"
                  >
                    Roof Age, Current Material, or Hail Notes
                  </label>
                  <textarea
                    id="lead-notes"
                    rows={3}
                    placeholder={formPlaceholders.notes}
                    value={roofDetails}
                    onChange={(e) => setRoofDetails(e.target.value)}
                    className="mt-1.5 w-full rounded-xl border border-[#D8D1C4] bg-[var(--roof-surface)]/45 p-3.5 text-sm text-[#141A21]"
                  />
                </div>
              </div>

              {errorMsg && (
                <div
                  role="alert"
                  className="mt-4 flex items-start gap-2.5 rounded-xl border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-900"
                >
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {captureOutcome && (
                <div className="mt-4 rounded-xl border border-[#2F5241]/30 bg-[#2F5241]/10 p-4 text-sm text-[#141A21]">
                  <div className="flex items-center gap-2 font-bold text-[#2F5241]">
                    <CheckCircle2 className="h-5 w-5" />
                    <span>Estimate Request Confirmed!</span>
                  </div>
                  <p className="mt-1.5 text-xs leading-relaxed text-[#374151]">
                    {captureOutcome.message}
                  </p>
                  <div className="font-mono-num mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-[#374151]">
                    <span>
                      Reference:{' '}
                      <strong className="text-[#141A21]">{captureOutcome.referenceCode}</strong>
                    </span>
                    {adminAuthenticated && captureOutcome.leadId && (
                      <span>
                        Lead ID: <strong className="text-[#141A21]">{captureOutcome.leadId}</strong>
                      </span>
                    )}
                    {adminAuthenticated && captureOutcome.eventId && (
                      <span>
                        Event ID:{' '}
                        <strong className="text-[#141A21]">{captureOutcome.eventId}</strong>
                      </span>
                    )}
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="btn-shimmer mt-6 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--roof-copper)] via-[var(--roof-copper-deep)] to-[var(--roof-amber)] px-6 py-3.5 text-base font-bold text-white shadow-[0_12px_28px_-8px_color-mix(in_srgb,var(--roof-copper)_65%,transparent)] transition-all hover:-translate-y-0.5 hover:shadow-[0_18px_34px_-8px_color-mix(in_srgb,var(--roof-copper)_85%,transparent)] disabled:opacity-55"
              >
                {submitting ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    <span>Submitting Estimate Request…</span>
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    <span>Request My Free Roof Estimate</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
