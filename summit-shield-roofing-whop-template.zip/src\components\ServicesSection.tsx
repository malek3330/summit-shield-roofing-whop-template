import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import { ArrowRight, Check, Clock, Shield, Sparkles, Wrench } from 'lucide-react'
import {
  roofingTemplate,
  type RoofingServiceItem,
  type WhopPlanKey,
} from '#/config/roofingTemplate'
import { trackWhopEvent } from '#/lib/whopPixel'
import { MotionReveal } from './MotionReveal'

interface ServicesSectionProps {
  onRequestServiceQuote: (service: RoofingServiceItem) => void
}

function getServiceLinkProps(planKey: WhopPlanKey | null) {
  if (planKey === 'deposit') {
    return { to: '/deposit' as const }
  }
  return {
    to: '/book/$slug' as const,
    params: { slug: planKey === 'tuneup' ? 'tune-up' : 'inspection' },
  }
}

const SERVICE_THEMES: Record<
  RoofingServiceItem['id'],
  {
    accentBar: string
    pillBg: string
    priceBadge: string
    checkBg: string
    hoverBorder: string
    buttonHover: string
  }
> = {
  inspection: {
    accentBar: 'from-sky-500 to-indigo-500',
    pillBg: 'bg-sky-50 text-sky-700 border-sky-200',
    priceBadge: 'bg-gradient-to-r from-sky-600 to-indigo-600 text-white',
    checkBg: 'bg-sky-500/12 text-sky-700',
    hoverBorder: 'hover:border-sky-400/70 hover:shadow-[0_24px_48px_-16px_rgba(14,165,233,0.22)]',
    buttonHover: 'hover:bg-sky-600',
  },
  repair: {
    accentBar: 'from-[var(--roof-copper)] to-[var(--roof-amber)]',
    pillBg:
      'bg-[var(--roof-copper)]/10 text-[var(--roof-copper-deep)] border-[var(--roof-copper)]/25',
    priceBadge: 'bg-gradient-to-r from-[var(--roof-copper)] to-[var(--roof-amber)] text-white',
    checkBg: 'bg-[var(--roof-copper)]/12 text-[var(--roof-copper-deep)]',
    hoverBorder:
      'hover:border-[var(--roof-copper)]/70 hover:shadow-[0_24px_48px_-16px_color-mix(in_srgb,var(--roof-copper)_22%,transparent)]',
    buttonHover: 'hover:bg-[var(--roof-copper)]',
  },
  replacement: {
    accentBar: 'from-emerald-500 to-teal-500',
    pillBg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    priceBadge: 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white',
    checkBg: 'bg-emerald-500/12 text-emerald-700',
    hoverBorder: 'hover:border-emerald-400/70 hover:shadow-[0_24px_48px_-16px_rgba(16,185,129,0.22)]',
    buttonHover: 'hover:bg-emerald-600',
  },
  tuneup: {
    accentBar: 'from-[var(--roof-amber)] to-[var(--roof-copper)]',
    pillBg: 'bg-amber-50 text-amber-800 border-amber-200',
    priceBadge: 'bg-gradient-to-r from-amber-600 to-[var(--roof-copper)] text-white',
    checkBg: 'bg-amber-500/15 text-amber-800',
    hoverBorder: 'hover:border-amber-400/70 hover:shadow-[0_24px_48px_-16px_rgba(245,158,11,0.22)]',
    buttonHover: 'hover:bg-amber-600',
  },
}

const FILTER_TABS: Array<{ id: 'all' | RoofingServiceItem['id']; label: string }> = [
  { id: 'all', label: `All Scopes (${roofingTemplate.services.length})` },
  ...roofingTemplate.services.map((service) => ({
    id: service.id,
    label: service.filterLabel || service.categoryLabel,
  })),
]

export function ServicesSection({
  onRequestServiceQuote,
}: ServicesSectionProps) {
  const { services, hero, plans } = roofingTemplate
  const [activeFilter, setActiveFilter] = useState<'all' | RoofingServiceItem['id']>('all')

  const visibleServices =
    activeFilter === 'all' ? services : services.filter((s) => s.id === activeFilter)

  const featuredTurnkeyService =
    services.find((s) => s.id === 'replacement') ??
    services.find((s) => s.linkedPlanKey === 'deposit') ??
    services[0]

  const trackServiceClick = (service: RoofingServiceItem, intent: 'checkout' | 'estimate') => {
    trackWhopEvent('service_viewed', {
      service_id: service.id,
      service_title: service.title,
      price_usd: service.priceNumber,
      linked_plan: service.linkedPlanKey ?? 'custom_estimate',
      interaction_intent: intent,
    })
  }

  return (
    <section
      id="services"
      className="border-b border-[var(--roof-border)] bg-[var(--roof-canvas)] py-14 sm:py-20"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <MotionReveal>
          <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 rounded-full border border-[var(--roof-copper)]/25 bg-gradient-to-r from-[var(--roof-copper)]/12 to-[var(--roof-amber)]/12 px-3.5 py-1 text-xs font-bold tracking-wider text-[var(--roof-copper-deep)] uppercase">
                <Wrench className="h-3.5 w-3.5" />
                <span>Roofing Scopes & Transparent Pricing</span>
              </div>
              <h2 className="font-display mt-3 text-3xl font-extrabold text-[var(--roof-ink)] sm:text-4xl">
                Inspections, Storm Repairs, Full Replacements & Flat-Rate Tune-Ups.
              </h2>
              <p className="mt-3 text-base text-[#4B5563] sm:text-lg">
                Select any transparent scope below to view coverage, turnarounds, and warranty
                terms — or lock in your online appointment and deposit right away.
              </p>
            </div>

            <Link
              to="/deposit"
              className="inline-flex min-h-11 shrink-0 items-center gap-2 rounded-xl border border-[var(--roof-ink)]/15 bg-white px-4 py-2.5 text-sm font-semibold text-[var(--roof-ink)] shadow-2xs transition-all hover:-translate-y-0.5 hover:border-[var(--roof-copper)] hover:shadow-md"
            >
              <Sparkles className="h-4 w-4 text-[var(--roof-copper)]" />
              <span>Start Deposit Checkout</span>
              <ArrowRight className="h-4 w-4 text-[var(--roof-copper)]" />
            </Link>
          </div>

          {/* Interactive Scope Filter Pills */}
          <div className="mt-7 flex flex-wrap gap-2" role="group" aria-label="Filter roofing services">
            {FILTER_TABS.map((tab) => {
              const active = activeFilter === tab.id
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setActiveFilter(tab.id)
                    if (tab.id !== 'all') {
                      const matched = services.find((s) => s.id === tab.id)
                      if (matched) {
                        trackWhopEvent('service_viewed', {
                          service_id: matched.id,
                          service_title: matched.title,
                          price_usd: matched.priceNumber,
                          source: 'scope_filter_pill',
                        })
                      }
                    }
                  }}
                  className={`min-h-9 rounded-full px-4 py-1.5 text-xs font-bold transition-all ${
                    active
                      ? 'bg-[var(--roof-ink)] text-white shadow-sm'
                      : 'border border-[var(--roof-border)] bg-white text-[#4B5563] hover:border-[var(--roof-ink)]/40 hover:text-[var(--roof-ink)]'
                  }`}
                >
                  {tab.label}
                </button>
              )
            })}
          </div>
        </MotionReveal>

        {/* Service Cards */}
        <div
          className={`mt-8 grid gap-6 ${
            visibleServices.length === 1 ? 'max-w-2xl' : 'md:grid-cols-2'
          }`}
        >
          {visibleServices.map((service, idx) => {
            const theme = SERVICE_THEMES[service.id]
            return (
              <MotionReveal key={service.id} delayMs={idx * 70}>
                <article
                  className={`group relative flex h-full flex-col justify-between overflow-hidden rounded-3xl border border-[var(--roof-border)] bg-white shadow-xs transition-all duration-300 hover:-translate-y-1.5 ${theme.hoverBorder}`}
                >
                  {/* Top gradient accent bar */}
                  <div className={`h-1.5 w-full bg-gradient-to-r ${theme.accentBar}`} />

                  <div>
                    {/* Architectural photo header */}
                    <div className="relative aspect-[16/8] w-full overflow-hidden bg-[var(--roof-midnight)]">
                      <img
                        src={service.image}
                        alt={service.imageAlt}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[var(--roof-obsidian)]/80 via-[var(--roof-obsidian)]/15 to-transparent" />

                      <div className="absolute right-4 bottom-3 left-4 flex flex-wrap items-center justify-between gap-2">
                        <span
                          className={`rounded-full border px-3 py-1 text-[11px] font-bold tracking-wider uppercase shadow-sm ${theme.pillBg}`}
                        >
                          {service.categoryLabel}
                        </span>
                        <span
                          className={`font-mono-num rounded-xl px-3 py-1.5 text-xs font-extrabold shadow-md ${theme.priceBadge}`}
                        >
                          {service.startingPriceLabel}
                        </span>
                      </div>
                    </div>

                    <div className="p-6 pb-0">
                      <h3 className="font-display text-xl font-bold text-[var(--roof-ink)] sm:text-2xl">
                        {service.title}
                      </h3>

                      <p className="mt-2.5 text-sm leading-relaxed text-[#4B5563]">
                        {service.subtitle}
                      </p>

                      <ul className="mt-5 space-y-2.5">
                        {service.highlights.map((highlight) => (
                          <li
                            key={highlight}
                            className="flex items-start gap-2.5 text-sm text-[#1F2937]"
                          >
                            <span
                              className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${theme.checkBg}`}
                            >
                              <Check className="h-3.5 w-3.5" />
                            </span>
                            <span>{highlight}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="mt-6 border-t border-[var(--roof-surface)] bg-[var(--roof-canvas)]/60 p-6 pt-4">
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#4B5563]">
                      <span className="flex items-center gap-1.5 font-medium">
                        <Clock className="h-3.5 w-3.5 text-[var(--roof-copper)]" />
                        {service.turnaround}
                      </span>
                      <span className="flex items-center gap-1.5 font-semibold text-emerald-700">
                        <Shield className="h-3.5 w-3.5" />
                        {service.warranty}
                      </span>
                    </div>

                    <div className="mt-4 flex flex-col gap-2.5 sm:flex-row">
                      <Link
                        {...getServiceLinkProps(service.linkedPlanKey)}
                        onClick={() => trackServiceClick(service, 'checkout')}
                        className={`btn-shimmer inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-[var(--roof-ink)] px-4 py-2.5 text-sm font-semibold text-white transition-all ${theme.buttonHover}`}
                      >
                        <span>{service.ctaLabel}</span>
                        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                      </Link>

                      <button
                        type="button"
                        onClick={() => {
                          trackServiceClick(service, 'estimate')
                          onRequestServiceQuote(service)
                        }}
                        className="inline-flex min-h-11 items-center justify-center rounded-xl border border-[var(--roof-border)] bg-white px-4 py-2.5 text-sm font-semibold text-[var(--roof-ink)] transition-all hover:border-[var(--roof-ink)] hover:bg-[var(--roof-surface)]"
                      >
                        Custom Quote
                      </button>
                    </div>
                  </div>
                </article>
              </MotionReveal>
            )
          })}
        </div>

        {/* Craftsmanship Dual Photo Strip */}
        <MotionReveal delayMs={120}>
          <div className="mt-10 grid gap-6 lg:grid-cols-12">
            <div className="group overflow-hidden rounded-3xl border border-[var(--roof-border)] bg-white shadow-xs transition-all hover:shadow-lg lg:col-span-5">
              <div className="overflow-hidden">
                <img
                  src={hero.detailImage}
                  alt={hero.detailImageAlt}
                  className="aspect-[16/10] w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />
              </div>
              <div className="p-6">
                <span className="inline-block rounded-full bg-[var(--roof-copper)]/10 px-2.5 py-0.5 text-[11px] font-bold text-[var(--roof-copper-deep)] uppercase">
                  {hero.craftsmanshipShowcase.detailEyebrow}
                </span>
                <div className="font-display mt-2 text-lg font-bold text-[var(--roof-ink)]">
                  {hero.craftsmanshipShowcase.detailTitle}
                </div>
                <p className="mt-1.5 text-sm leading-relaxed text-[#4B5563]">
                  {hero.craftsmanshipShowcase.detailDescription}
                </p>
              </div>
            </div>

            <div className="group overflow-hidden rounded-3xl border border-[var(--roof-border)] bg-[var(--roof-midnight)] text-white shadow-md transition-all hover:shadow-xl lg:col-span-7">
              <div className="relative overflow-hidden">
                <img
                  src={hero.replacementImage}
                  alt={hero.replacementImageAlt}
                  className="aspect-[16/10] w-full object-cover transition-transform duration-700 group-hover:scale-105 lg:aspect-[21/9]"
                  loading="lazy"
                />
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[var(--roof-midnight)] via-transparent to-transparent" />
              </div>
              <div className="flex flex-col justify-between gap-4 p-6 sm:flex-row sm:items-center">
                <div>
                  <span className="inline-block rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-[11px] font-bold text-emerald-300 uppercase">
                    {hero.craftsmanshipShowcase.turnkeyEyebrow}
                  </span>
                  <div className="font-display mt-2 text-lg font-bold text-white">
                    {hero.craftsmanshipShowcase.turnkeyTitle}
                  </div>
                  <p className="mt-1 text-sm text-white/70">
                    {hero.craftsmanshipShowcase.turnkeyDescription}
                  </p>
                </div>
                <Link
                  {...getServiceLinkProps(featuredTurnkeyService.linkedPlanKey)}
                  onClick={() => trackServiceClick(featuredTurnkeyService, 'checkout')}
                  className="btn-shimmer inline-flex min-h-11 shrink-0 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[var(--roof-copper)] to-[var(--roof-amber)] px-5 py-2.5 text-sm font-bold text-white shadow-lg transition-all hover:-translate-y-0.5"
                >
                  <span>Lock Install Slot (${plans.deposit.priceUsd})</span>
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </MotionReveal>
      </div>
    </section>
  )
}
