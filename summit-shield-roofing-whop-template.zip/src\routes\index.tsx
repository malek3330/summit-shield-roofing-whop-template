import { createFileRoute } from '@tanstack/react-router'
import { useCallback, useEffect, useState } from 'react'
import { EstimateLeadForm } from '#/components/EstimateLeadForm'
import { FinalInvoiceStudio } from '#/components/FinalInvoiceStudio'
import { FinancingSection } from '#/components/FinancingSection'
import { Footer } from '#/components/Footer'
import { Hero } from '#/components/Hero'
import { Navbar } from '#/components/Navbar'
import { PixelDebugPill } from '#/components/PixelDebugPill'
import { PixelTelemetryDrawer } from '#/components/PixelTelemetryDrawer'
import { PlansShowcaseSection } from '#/components/PlansShowcaseSection'
import { ReviewsSection } from '#/components/ReviewsSection'
import { ServiceAreaSection } from '#/components/ServiceAreaSection'
import { ServicesSection } from '#/components/ServicesSection'
import type { RoofingServiceItem } from '#/config/roofingTemplate'
import type { PublicRuntimeConfig, VaultedCustomerRecord } from '#/lib/types'
import { loadSavedVaultCustomer, persistVaultCustomer } from '#/lib/vaultStorage'
import { subscribeWhopPixelEvents, type PixelEventRecord } from '#/lib/whopPixel'

export const Route = createFileRoute('/')({
  component: RoofingHomePage,
})

function scrollToSection(sectionId: string) {
  if (typeof document === 'undefined') return
  const target = document.getElementById(sectionId)
  if (target) {
    target.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }
}

function RoofingHomePage() {
  const [preselectedService, setPreselectedService] = useState<RoofingServiceItem | null>(null)
  const [runtimeConfig, setRuntimeConfig] = useState<PublicRuntimeConfig | null>(null)
  const [checkoutMode, setCheckoutMode] = useState<'production' | 'sandbox'>('production')
  const [vaultedCustomer, setVaultedCustomer] = useState<VaultedCustomerRecord | null>(null)
  const [pixelEvents, setPixelEvents] = useState<PixelEventRecord[]>([])
  const [telemetryOpen, setTelemetryOpen] = useState(false)

  const loadRuntimeConfig = useCallback(async (mode: 'production' | 'sandbox') => {
    try {
      const res = await fetch(`/api/config?mode=${mode}`)
      if (!res.ok) return
      const data = (await res.json()) as PublicRuntimeConfig
      setRuntimeConfig(data)
      if (!data.adminAuthenticated && data.environment !== 'sandbox') {
        setCheckoutMode('production')
      }
    } catch {
      // Ignore transient hiccups
    }
  }, [])

  useEffect(() => {
    setVaultedCustomer(loadSavedVaultCustomer())

    const unsubscribe = subscribeWhopPixelEvents((events) => {
      setPixelEvents(events)
    })

    void loadRuntimeConfig('production')

    return () => {
      unsubscribe()
    }
  }, [loadRuntimeConfig])

  const handleRequestServiceQuote = useCallback((service: RoofingServiceItem) => {
    setPreselectedService(service)
    scrollToSection('estimate-form')
  }, [])

  const handleSwitchCheckoutMode = useCallback(
    async (mode: 'production' | 'sandbox') => {
      setCheckoutMode(mode)
      await loadRuntimeConfig(mode)
    },
    [loadRuntimeConfig],
  )

  const handleAuthChanged = useCallback(
    async (authenticated: boolean) => {
      const nextMode: 'production' | 'sandbox' = authenticated ? checkoutMode : 'production'
      if (!authenticated) {
        setCheckoutMode('production')
        setVaultedCustomer(loadSavedVaultCustomer())
      }
      await loadRuntimeConfig(nextMode)
    },
    [checkoutMode, loadRuntimeConfig],
  )

  const handleApplyVaultTarget = useCallback((record: VaultedCustomerRecord) => {
    setVaultedCustomer(record)
    persistVaultCustomer(record)
  }, [])

  const activeEnvironment = runtimeConfig?.environment ?? 'production'
  const adminAuthenticated = Boolean(runtimeConfig?.adminAuthenticated)

  return (
    <div className="min-h-screen bg-[var(--roof-canvas)] text-[var(--roof-ink)]">
      <Navbar />

      <main>
        <Hero />

        <ServicesSection onRequestServiceQuote={handleRequestServiceQuote} />

        <PlansShowcaseSection runtimeConfig={runtimeConfig} />

        <FinalInvoiceStudio
          vaultedCustomer={vaultedCustomer}
          runtimeConfig={runtimeConfig}
          onOpenPortal={() => setTelemetryOpen(true)}
        />

        <FinancingSection />

        <EstimateLeadForm
          preselectedService={preselectedService}
          vaultedCustomer={vaultedCustomer}
          environmentMode={activeEnvironment}
          adminAuthenticated={adminAuthenticated}
        />

        <ServiceAreaSection />

        <ReviewsSection />
      </main>

      <Footer onOpenPortal={() => setTelemetryOpen(true)} />

      <PixelDebugPill />

      <PixelTelemetryDrawer
        open={telemetryOpen}
        onClose={() => setTelemetryOpen(false)}
        events={pixelEvents}
        runtimeConfig={runtimeConfig}
        vaultedCustomer={vaultedCustomer}
        checkoutMode={checkoutMode}
        onSwitchCheckoutMode={handleSwitchCheckoutMode}
        onAuthChanged={handleAuthChanged}
        onApplyVaultTarget={handleApplyVaultTarget}
      />
    </div>
  )
}
