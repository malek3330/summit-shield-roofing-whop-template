import { createFileRoute } from '@tanstack/react-router'
import { getAdminSession, hasBuyerReceiptAccess } from '#/server/auth'
import {
  createWhopServerClient,
  getResolvedPlans,
  handleWhopApiError,
  jsonResponse,
  requireAccountId,
  resolveAuthorizedRuntimeMode,
} from '#/server/whopServer'

interface InvoiceActionPayload {
  action?: 'auto_charge' | 'send_manual' | 'issue' | 'send' | 'pdf' | 'void'
  invoiceId?: string
  setupIntentId?: string
  paymentId?: string
  memberId?: string
  paymentMethodId?: string
  emailAddress?: string
  customerName?: string
  amountUsd?: number
  lineTitle?: string
  jobReference?: string
  memo?: string
  dueDays?: number
  environmentMode?: 'production' | 'sandbox'
}

function extractInnerWhopError(error: unknown): string {
  if (error && typeof error === 'object') {
    const err = error as {
      message?: string
      body?: { error?: { message?: string }; message?: string }
      error?: { message?: string; error?: { message?: string } }
    }
    const structured =
      err.body?.error?.message ||
      err.body?.message ||
      err.error?.error?.message ||
      err.error?.message

    if (structured) return structured

    if (err.message) {
      const jsonMatch = err.message.match(/"message"\s*:\s*"([^"]+)"/)
      if (jsonMatch?.[1]) return jsonMatch[1]
      return err.message.replace(/^\d+\s+/, '')
    }
  }
  return String(error)
}

function unauthorizedResponse() {
  return jsonResponse(
    {
      ok: false,
      code: 'UNAUTHORIZED',
      message: 'Contractor Portal sign-in or an active deposit receipt session is required.',
    },
    401,
  )
}

function redactInvoiceForBuyer(raw: unknown) {
  const r = raw as Record<string, unknown>
  return {
    id: r.id,
    number: r.number,
    status: r.status,
    total: r.total,
    amount_due: r.amount_due,
    checkout_link: r.checkout_link ?? null,
    created_at: r.created_at ?? null,
    due_at: r.due_at ?? null,
  }
}

export const Route = createFileRoute('/api/invoices')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const isAdmin = await getAdminSession(request)
        if (!isAdmin) return unauthorizedResponse()

        try {
          const url = new URL(request.url)
          const mode = resolveAuthorizedRuntimeMode(url.searchParams.get('mode'), isAdmin)
          const accountId = requireAccountId(mode)
          const whop = createWhopServerClient(mode)
          const page = await whop.invoices.list({
            account_id: accountId,
            first: 15,
          })

          return jsonResponse({
            ok: true,
            environment: mode,
            invoices: page.data,
          })
        } catch (error) {
          return handleWhopApiError(error, 'listing Whop invoices')
        }
      },

      POST: async ({ request }) => {
        const isAdmin = await getAdminSession(request)

        try {
          const body = (await request.json().catch(() => null)) as InvoiceActionPayload | null
          if (!body) {
            return jsonResponse(
              { ok: false, code: 'INVALID_JSON', message: 'Invalid JSON body.' },
              400,
            )
          }

          const action = body.action ?? 'send_manual'
          const setupIntentId = body.setupIntentId?.trim()
          const paymentId = body.paymentId?.trim()
          const buyerProofId =
            setupIntentId && setupIntentId.startsWith('sint_')
              ? setupIntentId
              : paymentId && paymentId.startsWith('pay_')
                ? paymentId
                : null

          const isBuyerDemoAuthorized =
            !isAdmin &&
            Boolean(buyerProofId) &&
            (action === 'auto_charge' || action === 'send_manual') &&
            (await hasBuyerReceiptAccess(request, buyerProofId!))

          if (!isAdmin && !isBuyerDemoAuthorized) {
            return unauthorizedResponse()
          }

          const mode = resolveAuthorizedRuntimeMode(
            body.environmentMode,
            isAdmin,
            isBuyerDemoAuthorized,
          )
          const whop = createWhopServerClient(mode)

          if (isAdmin && action === 'pdf') {
            if (!body.invoiceId?.trim()) {
              return jsonResponse(
                { ok: false, code: 'MISSING_INVOICE_ID', message: 'Missing invoiceId (`pay_...`).' },
                400,
              )
            }
            const pdf = await whop.invoices.generatePdf({ id: body.invoiceId.trim() })
            return jsonResponse({ ok: true, pdf })
          }

          if (isAdmin && action === 'issue' && body.invoiceId?.trim()) {
            const invoice = await whop.invoices.issue({ id: body.invoiceId.trim() })
            return jsonResponse({ ok: true, invoice })
          }

          if (isAdmin && action === 'send' && body.invoiceId?.trim()) {
            const invoice = await whop.invoices.send({ id: body.invoiceId.trim() })
            return jsonResponse({ ok: true, invoice })
          }

          if (isAdmin && action === 'void' && body.invoiceId?.trim()) {
            const invoice = await whop.invoices.void({ id: body.invoiceId.trim() })
            return jsonResponse({ ok: true, invoice })
          }

          const accountId = requireAccountId(mode)
          const amountUsd = Number(body.amountUsd)
          if (!Number.isFinite(amountUsd) || amountUsd <= 0 || (!isAdmin && amountUsd > 25000)) {
            return jsonResponse(
              {
                ok: false,
                code: 'INVALID_AMOUNT',
                message: 'Final balance USD amount must be between $1 and $25,000.',
              },
              400,
            )
          }

          // Resolve vaulted credentials server-side when invoked from a buyer's own deposit receipt
          let resolvedMemberId = isAdmin ? body.memberId?.trim() : undefined
          let resolvedPmId = isAdmin ? body.paymentMethodId?.trim() : undefined
          let resolvedEmail = isAdmin ? body.emailAddress?.trim() : undefined
          const customerName = isAdmin ? body.customerName?.trim() : undefined

          if (!isAdmin && buyerProofId) {
            if (buyerProofId.startsWith('sint_')) {
              const sint = await whop.setupIntents.retrieve({ id: buyerProofId })
              resolvedMemberId = sint.member_id ?? undefined
              resolvedPmId = sint.payment_method_id ?? undefined
              resolvedEmail = body.emailAddress?.trim() || undefined
            } else if (buyerProofId.startsWith('pay_')) {
              const pay = await whop.payments.retrieve({ id: buyerProofId })
              resolvedMemberId = pay.member_id ?? undefined
              resolvedPmId = pay.payment_method_id ?? undefined
              resolvedEmail = pay.customer_email ?? body.emailAddress?.trim() ?? undefined
            }
          }

          const plans = getResolvedPlans(mode)
          const depositProductId = plans.deposit.isRealProductId
            ? plans.deposit.productId
            : undefined

          const rawLineTitle =
            body.lineTitle?.trim() ||
            `Final Balance (${body.jobReference?.trim() || 'Completed Roof Scope'})`

          const cleanMemo = body.memo?.trim().slice(0, 1000) || undefined
          const itemDescription = [
            rawLineTitle.length > 30 ? rawLineTitle : null,
            cleanMemo,
          ]
            .filter(Boolean)
            .join('\n')
            .slice(0, 1000)

          const variantTitle =
            rawLineTitle.length <= 30
              ? rawLineTitle
              : `${rawLineTitle.slice(0, 27).trimEnd()}...`

          const itemPayload = {
            ...(itemDescription ? { description: itemDescription } : {}),
            variant: {
              ...(depositProductId ? { product_id: depositProductId } : {}),
              currency: 'usd',
              billing_type: 'one_time',
              initial_price: Math.round(amountUsd * 100) / 100,
              title: variantTitle,
            },
            quantity: 1,
          }

          const metadata: Record<string, string> = {
            flow: 'roofing_final_balance',
            billing_mode: action,
            ...(body.jobReference?.trim() ? { job_reference: body.jobReference.trim() } : {}),
            ...(rawLineTitle ? { line_item_title: rawLineTitle.slice(0, 200) } : {}),
            ...(cleanMemo ? { work_summary: cleanMemo.slice(0, 450) } : {}),
          }

          if (action === 'auto_charge') {
            if (!resolvedMemberId || !resolvedPmId) {
              return jsonResponse(
                {
                  ok: false,
                  code: 'MISSING_VAULTED_PAYMENT_METHOD',
                  message:
                    'Auto-charging requires a saved Member ID and Payment Method from a deposit checkout or card setup.',
                },
                400,
              )
            }

            const draft = await whop.invoices.create({
              account_id: accountId,
              member_id: resolvedMemberId,
              payment_method_id: resolvedPmId,
              ...(cleanMemo ? { memo: cleanMemo } : {}),
              items: [itemPayload],
              metadata,
            })

            try {
              const issued = await whop.invoices.issue({ id: draft.id })
              const pdf = await whop.invoices.generatePdf({ id: issued.id }).catch(() => null)

              return jsonResponse(
                {
                  ok: true,
                  mode: 'auto_charge',
                  environment: mode,
                  invoice: isAdmin ? issued : redactInvoiceForBuyer(issued),
                  pdfUrl: pdf?.url ?? null,
                },
                201,
              )
            } catch (issueErr) {
              const warning = extractInnerWhopError(issueErr)
              const pdf = await whop.invoices.generatePdf({ id: draft.id }).catch(() => null)
              return jsonResponse(
                {
                  ok: true,
                  mode: 'draft_verification_required',
                  requestedMode: 'auto_charge',
                  environment: mode,
                  invoice: isAdmin ? draft : redactInvoiceForBuyer(draft),
                  pdfUrl: pdf?.url ?? null,
                  verificationRequired: /verif|kyc|onboard|payout/i.test(warning),
                  warning,
                },
                201,
              )
            }
          }

          if (!resolvedMemberId && !resolvedEmail) {
            return jsonResponse(
              {
                ok: false,
                code: 'MISSING_RECIPIENT',
                message:
                  'Provide a homeowner email address (or saved deposit member) to send the final balance invoice.',
              },
              400,
            )
          }

          const dueDays = Math.max(1, Math.min(90, Number(body.dueDays ?? 7)))
          const dueAtIso = new Date(Date.now() + dueDays * 24 * 60 * 60 * 1000).toISOString()

          const draft = await whop.invoices.create({
            account_id: accountId,
            ...(resolvedMemberId ? { member_id: resolvedMemberId } : { email_address: resolvedEmail }),
            ...(!resolvedMemberId && customerName ? { customer_name: customerName } : {}),
            ...(resolvedEmail ? { recipient_emails: [resolvedEmail] } : {}),
            ...(cleanMemo ? { memo: cleanMemo } : {}),
            due_at: dueAtIso,
            items: [itemPayload],
            metadata,
          })

          try {
            const sentInvoice = await whop.invoices.send({ id: draft.id })
            const pdf = await whop.invoices.generatePdf({ id: sentInvoice.id }).catch(() => null)

            return jsonResponse(
              {
                ok: true,
                mode: 'send_manual',
                environment: mode,
                invoice: isAdmin ? sentInvoice : redactInvoiceForBuyer(sentInvoice),
                pdfUrl: pdf?.url ?? null,
              },
              201,
            )
          } catch (sendErr) {
            const warning = extractInnerWhopError(sendErr)
            const pdf = await whop.invoices.generatePdf({ id: draft.id }).catch(() => null)
            return jsonResponse(
              {
                ok: true,
                mode: 'draft_verification_required',
                requestedMode: 'send_manual',
                environment: mode,
                invoice: isAdmin ? draft : redactInvoiceForBuyer(draft),
                pdfUrl: pdf?.url ?? null,
                verificationRequired: /verif|kyc|onboard|payout/i.test(warning),
                warning,
              },
              201,
            )
          }
        } catch (error) {
          return handleWhopApiError(error, 'processing Whop invoice')
        }
      },
    },
  },
})
