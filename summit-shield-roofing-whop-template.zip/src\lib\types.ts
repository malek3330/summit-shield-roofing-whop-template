import type { WhopPlanKey } from '#/config/roofingTemplate'

export interface PublicPlanSummary {
  key: WhopPlanKey
  title: string
  shortTitle: string
  badge: string
  priceUsd: number
  billingLabel: string
  supportsSetupIntentVault: boolean
  productId: string
  variantId: string
  isRealVariantId: boolean
  isRealProductId: boolean
}

export interface PublicRuntimeConfig {
  configured: boolean
  checkoutReady: boolean
  environment: 'production' | 'sandbox'
  sandboxConfigured: boolean
  adminAuthenticated: boolean
  hasRealAccountId: boolean
  hasRealPlans: boolean
  checkoutAccountId: string
  plans: Record<WhopPlanKey, PublicPlanSummary>
  adminDiagnostics?: {
    authMode: 'api_key' | 'hosted_proxy' | 'unconfigured'
    accountId: string
    hasRealAccountId: boolean
    webhookConfigured: boolean
    sandboxConfigured: boolean
  }
}

export interface VaultedCustomerRecord {
  memberId?: string
  paymentMethodId?: string
  userId?: string | null
  whopUsername?: string | null
  email?: string
  customerName?: string
  sourceId: string
  sourceType: 'payment' | 'setup_intent' | 'checkout'
  cardSaved: boolean
  cardSummary?: string | null
  capturedAtIso: string
}

export interface InvoiceRecordSummary {
  id: string
  number: string
  status: string
  totalFormatted: string
  amountDueFormatted: string
  checkoutLink: string | null
  memberId: string | null
  paymentMethodId: string | null
  emailAddress: string | null
  customerName: string | null
  createdAt: string
  dueAt: string | null
  pdfUrl?: string | null
  verificationWarning?: string | null
}
