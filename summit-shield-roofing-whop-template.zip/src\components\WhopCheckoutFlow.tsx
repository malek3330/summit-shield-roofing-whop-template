import { useCallback, useEffect, useMemo, useState } from 'react'
import { loadWhop } from '@whop/elements'
import {
  BrandingElement,
  Checkout,
  CheckoutElement,
  EmailElement,
  ExpressCheckoutElement,
  PaymentElement,
  Payments,
  usePayments,
  useWhop,
  WhopElements,
  type PaymentElementChangeEvent,
} from '@whop/elements-react'
import {
  AlertCircle,
  CheckCircle2,
  CreditCard,
  KeyRound,
  Layers,
  Loader2,
  Lock,
  ShieldCheck,
  TestTube2,
} from 'lucide-react'
import { roofingTemplate, type WhopPlanKey } from '#/config/roofingTemplate'
import type { PublicRuntimeConfig } from '#/lib/types'
import { persistVaultCustomer } from '#/lib/vaultStorage'
import { trackWhopEvent } from '#/lib/whopPixel'

interface WhopCheckoutFlowProps {
  planKey: WhopPlanKey
  initialCustomerName?: string
  initialCustomerEmail?: string
  initialMode?: 'production' | 'sandbox'
}

type SurfaceTab = 'payment_elements' | 'hosted_checkout'
type DepositExecutionMode = 'deposit_and_vault' | 'setup_only'

interface InnerCheckoutFormProps {
  planKey: WhopPlanKey
  priceUsd: number
  variantId: string
  mode: 'payment' | 'setup'
  depositExecutionMode: DepositExecutionMode
  environmentMode: 'production' | 'sandbox'
  returnBaseUrl: string
  customerName: string
  customerEmail: string
  onElementReady: () => void
  onElementError: (msg: string) => void
  onCompleted: (params: {
    setupIntentId?: string | null
    paymentId?: string | null
    status: string
  }) => void
}

function InnerCheckoutForm({
  planKey,
  priceUsd,
  variantId,
  mode,
  depositExecutionMode,
  environmentMode,
  returnBaseUrl,
  customerName,
  customerEmail,
  onElementReady,
  onElementError,
  onCompleted,
}: InnerCheckoutFormProps) {
  const whop = useWhop()
  const payments = usePayments()

  const [elementReady, setElementReady] = useState(false)
  const [paymentComplete, setPaymentComplete] = useState(false)
  const [selectedMethod, setSelectedMethod] = useState<string>('card')
  const [emailComplete, setEmailComplete] = useState(Boolean(customerEmail))
  const [typedEmail, setTypedEmail] = useState(customerEmail)
  const [submitting, setSubmitting] = useState(false)
  const [statusMessage, setStatusMessage] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const handlePaymentChange = (event: PaymentElementChangeEvent) => {
    setPaymentComplete(event.complete)
    if (event.paymentMethod?.type) {
      setSelectedMethod(event.paymentMethod.type)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!payments || !whop) return

    setErrorMessage(null)
    setSubmitting(true)
    setStatusMessage('Encrypting card details securely via Whop Elements…')

    const isDepositSetupFlow = mode === 'setup'
    trackWhopEvent('deposit_started', {
      plan_key: planKey,
      plan_variant_id:
        isDepositSetupFlow && depositExecutionMode === 'setup_only' ? 'setup_intent' : variantId,
      amount_usd: depositExecutionMode === 'setup_only' ? 0 : priceUsd,
      checkout_surface: isDepositSetupFlow ? 'setup_intent_element' : 'payment_element',
      payment_method_type: selectedMethod,
      vaults_card_on_file: planKey === 'deposit' || isDepositSetupFlow,
      environment_mode: environmentMode,
    })

    try {
      const effectiveEmail = typedEmail.trim() || customerEmail.trim() || undefined
      const { confirmationToken, type } = await payments.createConfirmationToken({
        billingDetails: {
          ...(effectiveEmail ? { email: effectiveEmail } : {}),
          ...(customerName.trim() ? { name: customerName.trim() } : {}),
        },
      })

      if (isDepositSetupFlow) {
        // Step 1: Create SetupIntent to tokenize & store payment method on Whop Member
        setStatusMessage('Authorizing payment method on file (SetupIntent)…')
        const setupReturnUrl = `${returnBaseUrl}?plan=${planKey}&mode=setup${
          environmentMode === 'sandbox' ? '&env=sandbox' : ''
        }`
        const setupRes = await fetch('/api/setup-intents', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            confirmationToken,
            returnUrl: setupReturnUrl,
            email: effectiveEmail,
            environmentMode,
            metadata: {
              plan_key: planKey,
              homeowner_name: customerName.trim() || 'homeowner',
              flow: depositExecutionMode,
            },
          }),
        })

        const setupData = (await setupRes.json()) as {
          ok?: boolean
          message?: string
          setupIntent?: { id: string; client_secret: string | null; status: string }
          clientSecret?: string | null
        }

        if (!setupRes.ok || !setupData.setupIntent) {
          throw new Error(setupData.message || 'Unable to save payment method on file.')
        }

        const setupSecret = setupData.clientSecret ?? setupData.setupIntent.client_secret
        if (setupSecret) {
          setStatusMessage('Completing bank/card verification…')
          const nextRes = await whop.payments.handleNextAction({
            clientSecret: setupSecret,
            returnUrl: setupReturnUrl,
          })
          if (nextRes.lastPaymentError?.message) {
            throw new Error(nextRes.lastPaymentError.message)
          }
        }

        const setupId = setupData.setupIntent.id

        if (depositExecutionMode === 'setup_only') {
          persistVaultCustomer({
            sourceId: '',
            sourceType: 'setup_intent',
            cardSaved: true,
            cardSummary: type || 'Authorized Card',
            capturedAtIso: new Date().toISOString(),
          })
          setStatusMessage('Card authorized! Redirecting to confirmation…')
          onCompleted({
            setupIntentId: setupId,
            status: 'succeeded',
          })
          return
        }

        // Step 2: Charge $500 Deposit using the freshly vaulted SetupIntent
        setStatusMessage(`Charging $${priceUsd} scheduling deposit using your saved card…`)
        const depositReturnUrl = `${returnBaseUrl}?plan=${planKey}&setup=${encodeURIComponent(setupId)}${
          environmentMode === 'sandbox' ? '&env=sandbox' : ''
        }`
        const confirmRes = await fetch('/api/payments/confirm', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            setupIntentId: setupId,
            planKey,
            email: effectiveEmail,
            returnUrl: depositReturnUrl,
            environmentMode,
            metadata: {
              homeowner_name: customerName.trim() || 'homeowner',
            },
          }),
        })

        const confirmData = (await confirmRes.json()) as {
          ok?: boolean
          message?: string
          payment?: { id: string; status: string; client_secret: string | null }
          clientSecret?: string | null
        }

        if (!confirmRes.ok || !confirmData.payment) {
          throw new Error(confirmData.message || 'Deposit payment confirmation failed.')
        }

        const paySecret = confirmData.clientSecret ?? confirmData.payment.client_secret
        if (paySecret) {
          setStatusMessage('Verifying deposit settlement…')
          const outcome = await whop.payments.handleNextAction({
            clientSecret: paySecret,
            returnUrl: depositReturnUrl,
          })
          if (outcome.lastPaymentError?.message) {
            throw new Error(outcome.lastPaymentError.message)
          }
        }

        const paymentId = confirmData.payment.id
        let finalStatus = confirmData.payment.status ?? 'succeeded'
        let finalCardSummary: string | null = null
        let failureMessage: string | null = null

        for (let poll = 0; poll < 5; poll++) {
          const statusRes = await fetch(
            `/api/payments/confirm?id=${encodeURIComponent(paymentId)}&mode=${environmentMode}`,
          )
          const statusData = (await statusRes.json().catch(() => null)) as {
            payment?: {
              status?: string
              cardSaved?: boolean
              cardSummary?: string | null
              failure_message?: string | null
            }
          } | null

          if (statusData?.payment) {
            finalStatus = statusData.payment.status ?? finalStatus
            finalCardSummary = statusData.payment.cardSummary ?? finalCardSummary
            failureMessage = statusData.payment.failure_message ?? null
          }

          if (finalStatus === 'paid' || finalStatus === 'succeeded' || failureMessage) break
          if (poll < 4) await new Promise((r) => setTimeout(r, 700))
        }

        if (failureMessage && finalStatus !== 'paid' && finalStatus !== 'succeeded') {
          throw new Error(failureMessage)
        }

        persistVaultCustomer({
          sourceId: '',
          sourceType: 'setup_intent',
          cardSaved: true,
          cardSummary: finalCardSummary ?? type ?? 'Saved Card',
          capturedAtIso: new Date().toISOString(),
        })

        setStatusMessage('Deposit paid & card saved! Redirecting…')
        onCompleted({
          setupIntentId: setupId,
          paymentId,
          status: finalStatus === 'paid' ? 'succeeded' : finalStatus,
        })
        return
      }

      // Standard one-time payment flow ($149 inspection or $299 flat-rate tune-up)
      setStatusMessage(`Processing $${priceUsd} payment securely…`)
      const directReturnUrl = `${returnBaseUrl}?plan=${planKey}${
        environmentMode === 'sandbox' ? '&env=sandbox' : ''
      }`

      const confirmRes = await fetch('/api/payments/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          confirmationToken,
          planKey,
          email: effectiveEmail,
          returnUrl: directReturnUrl,
          environmentMode,
          metadata: {
            homeowner_name: customerName.trim() || 'homeowner',
          },
        }),
      })

      const confirmData = (await confirmRes.json()) as {
        ok?: boolean
        message?: string
        payment?: { id: string; status: string; client_secret: string | null }
        clientSecret?: string | null
      }

      if (!confirmRes.ok || !confirmData.payment) {
        throw new Error(confirmData.message || 'Payment confirmation failed.')
      }

      const secret = confirmData.clientSecret ?? confirmData.payment.client_secret
      if (secret) {
        setStatusMessage('Verifying card authorization…')
        const actionOutcome = await whop.payments.handleNextAction({
          clientSecret: secret,
          returnUrl: directReturnUrl,
        })
        if (actionOutcome.lastPaymentError?.message) {
          throw new Error(actionOutcome.lastPaymentError.message)
        }
      }

      const paymentId = confirmData.payment.id
      const statusRes = await fetch(
        `/api/payments/confirm?id=${encodeURIComponent(paymentId)}&mode=${environmentMode}`,
      )
      const statusData = (await statusRes.json().catch(() => null)) as {
        payment?: {
          status?: string
          cardSummary?: string | null
          failure_message?: string | null
        }
      } | null

      const finalStatus = statusData?.payment?.status ?? confirmData.payment.status ?? 'succeeded'
      if (
        statusData?.payment?.failure_message &&
        finalStatus !== 'paid' &&
        finalStatus !== 'succeeded'
      ) {
        throw new Error(statusData.payment.failure_message)
      }

      persistVaultCustomer({
        sourceId: '',
        sourceType: 'payment',
        cardSaved: false,
        cardSummary: statusData?.payment?.cardSummary ?? type ?? 'Verified Card',
        capturedAtIso: new Date().toISOString(),
      })

      setStatusMessage('Confirmed! Opening your receipt…')
      onCompleted({
        paymentId,
        status: finalStatus === 'paid' ? 'succeeded' : finalStatus,
      })
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      if (msg.includes('payment_request_cancelled')) {
        setErrorMessage('Wallet sheet was closed before authorization. You can try again anytime.')
      } else {
        setErrorMessage(msg)
      }
      setStatusMessage(null)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {!elementReady && (
        <div className="space-y-3 rounded-2xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/70 p-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#4B5563]">
            <Loader2 className="h-4 w-4 animate-spin text-[var(--roof-copper)]" />
            <span>Initializing encrypted Whop Payment Elements…</span>
          </div>
          <div className="h-10 animate-pulse rounded-xl bg-[var(--roof-border)]/50" />
          <div className="h-24 animate-pulse rounded-xl bg-[var(--roof-border)]/40" />
        </div>
      )}

      {/* Email Receipt Delivery */}
      <div className="rounded-2xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/75 p-4 transition-colors focus-within:border-[var(--roof-copper)]/50">
        <div className="mb-2.5 flex items-center justify-between text-xs font-bold tracking-wider text-[#4B5563] uppercase">
          <span>1. Homeowner Email &amp; Invoice Delivery</span>
          {emailComplete && (
            <span className="rounded-full bg-emerald-500/15 px-2.5 py-0.5 text-[11px] font-bold text-emerald-700">
              Valid Email
            </span>
          )}
        </div>
        <EmailElement
          defaultValue={customerEmail || undefined}
          onChange={(ev) => {
            setTypedEmail(ev.email)
            setEmailComplete(ev.complete)
          }}
        />
      </div>

      {/* Main Card / BNPL Payment Element */}
      <div className="rounded-2xl border border-[var(--roof-border)] bg-white p-4 shadow-2xs">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-bold tracking-wider text-[#4B5563] uppercase">
            2. Card, Wallets or Monthly Financing (Klarna, Afterpay, Splitit)
          </span>
          {mode === 'setup' && (
            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2.5 py-0.5 text-[11px] font-bold text-emerald-800">
              <KeyRound className="h-3 w-3" />
              SetupIntent · Card Saved on File
            </span>
          )}
        </div>

        <PaymentElement
          layout="accordion"
          separated
          onReady={() => {
            setElementReady(true)
            onElementReady()
          }}
          onError={(err) => onElementError(err.message)}
          onChange={handlePaymentChange}
          defaultValues={{
            billingDetails: {
              ...(customerName.trim() ? { name: customerName.trim() } : {}),
              address: { country: 'US' },
            },
          }}
        />
      </div>

      {/* Required Whop BrandingElement — visible alongside PaymentElement confirmation */}
      <div className="rounded-2xl border border-[var(--roof-border)] bg-[var(--roof-canvas)] px-4 py-3">
        <BrandingElement />
      </div>

      {statusMessage && (
        <div className="flex items-center gap-2.5 rounded-xl border border-[#141A21]/15 bg-[var(--roof-surface)] px-4 py-3 text-sm font-medium text-[#141A21]">
          <Loader2 className="h-4 w-4 shrink-0 animate-spin text-[var(--roof-copper-deep)]" />
          <span>{statusMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div
          role="alert"
          className="flex items-start gap-2.5 rounded-xl border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-900"
        >
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
          <span>{errorMessage}</span>
        </div>
      )}

      <button
        type="submit"
        disabled={submitting || !paymentComplete}
        className="btn-shimmer inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[var(--roof-copper)] via-[var(--roof-copper-deep)] to-[var(--roof-amber)] px-6 py-3.5 text-base font-bold text-white shadow-[0_12px_28px_-8px_color-mix(in_srgb,var(--roof-copper)_65%,transparent)] transition-all hover:-translate-y-0.5 hover:shadow-[0_18px_34px_-8px_color-mix(in_srgb,var(--roof-copper)_85%,transparent)] disabled:cursor-not-allowed disabled:opacity-55 disabled:hover:translate-y-0"
      >
        {submitting ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>Confirming with Whop…</span>
          </>
        ) : (
          <>
            <Lock className="h-4 w-4" />
            <span>
              {mode === 'setup'
                ? depositExecutionMode === 'setup_only'
                  ? 'Authorize Card on File ($0.00 Due Today)'
                  : `Authorize Card & Pay $${priceUsd} Deposit`
                : `Pay $${priceUsd} Securely Now`}
            </span>
          </>
        )}
      </button>
    </form>
  )
}

export function WhopCheckoutFlow({
  planKey,
  initialCustomerName = '',
  initialCustomerEmail = '',
  initialMode = 'production',
}: WhopCheckoutFlowProps) {
  const [runtimeConfig, setRuntimeConfig] = useState<PublicRuntimeConfig | null>(null)
  const [configLoading, setConfigLoading] = useState(true)
  const [environmentMode, setEnvironmentMode] = useState<'production' | 'sandbox'>(initialMode)
  const [activeTab, setActiveTab] = useState<SurfaceTab>('payment_elements')
  const [depositExecutionMode, setDepositExecutionMode] =
    useState<DepositExecutionMode>('deposit_and_vault')
  const [customerName, setCustomerName] = useState(initialCustomerName)
  const [customerEmail, setCustomerEmail] = useState(initialCustomerEmail)
  const [mountedClient, setMountedClient] = useState(false)
  const [sdkLoadError, setSdkLoadError] = useState<string | null>(null)
  const [hostedReady, setHostedReady] = useState(false)

  useEffect(() => {
    setMountedClient(true)
  }, [])

  const loadConfig = useCallback(async (mode: 'production' | 'sandbox') => {
    setConfigLoading(true)
    try {
      const res = await fetch(`/api/config?mode=${mode}`)
      if (!res.ok) return
      const data = (await res.json()) as PublicRuntimeConfig
      setRuntimeConfig(data)
      if (data.environment === 'sandbox' || data.environment === 'production') {
        setEnvironmentMode(data.environment)
      }
    } catch {
      // ignore transient network errors
    } finally {
      setConfigLoading(false)
    }
  }, [])

  useEffect(() => {
    void loadConfig(initialMode)
  }, [initialMode, loadConfig])

  const whopElementsPromise = useMemo(() => {
    if (!mountedClient) return null
    return loadWhop()
  }, [mountedClient])

  const templatePlan = roofingTemplate.plans[planKey]
  const resolvedPlan = runtimeConfig?.plans?.[planKey]
  const variantId = resolvedPlan?.variantId ?? ''
  const productId = resolvedPlan?.productId ?? ''
  const accountId = runtimeConfig?.checkoutAccountId ?? ''
  const sandboxConfigured = Boolean(runtimeConfig?.sandboxConfigured)

  const canMountElements = Boolean(
    mountedClient &&
      runtimeConfig?.hasRealAccountId &&
      resolvedPlan?.isRealVariantId &&
      accountId.startsWith('biz_') &&
      variantId.startsWith('plan_'),
  )

  const returnBaseUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/checkout/return`
      : 'https://example.whop.site/checkout/return'

  const hostedReturnUrl = `${returnBaseUrl}?plan=${planKey}${
    environmentMode === 'sandbox' ? '&env=sandbox' : ''
  }`

  const elementsAppearance = useMemo(
    () => ({
      theme: {
        appearance: 'light' as const,
        accentColor: roofingTemplate.theme.elementsAccentColor,
        grayColor: roofingTemplate.theme.elementsGrayColor,
      },
      variables: {
        '--radius-2': '8px',
        '--radius-3': '10px',
      },
    }),
    [],
  )

  const handleCheckoutCompleted = useCallback(
    ({
      setupIntentId,
      paymentId,
      status,
    }: {
      setupIntentId?: string | null
      paymentId?: string | null
      status: string
    }) => {
      if (typeof window === 'undefined') return
      const q = new URLSearchParams()
      q.set('plan', planKey)
      q.set('status', status)
      if (setupIntentId) q.set('setup', setupIntentId)
      if (paymentId) q.set('payment', paymentId)
      if (environmentMode === 'sandbox') q.set('env', 'sandbox')
      if (planKey === 'deposit' && depositExecutionMode === 'setup_only') {
        q.set('mode', 'setup')
      }
      window.location.assign(`/checkout/return?${q.toString()}`)
    },
    [planKey, environmentMode, depositExecutionMode],
  )

  return (
    <div
      data-whop-product-id={productId || undefined}
      data-whop-variant-id={variantId || undefined}
      data-whop-price={String(templatePlan.priceUsd)}
      data-whop-currency="USD"
      className="rounded-3xl border border-[var(--roof-border)] bg-white p-5 shadow-[0_24px_60px_-24px_rgba(17,24,39,0.18)] sm:p-7"
    >
      {/* Top environment & test card switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--roof-border)]/70 pb-4">
        <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Checkout presentation">
          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'payment_elements'}
            onClick={() => setActiveTab('payment_elements')}
            className={`inline-flex min-h-10 items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition-all ${
              activeTab === 'payment_elements'
                ? 'bg-[var(--roof-ink)] text-white shadow-sm'
                : 'bg-[var(--roof-canvas)] text-[#374151] hover:bg-[var(--roof-surface)]'
            }`}
          >
            <CreditCard className="h-3.5 w-3.5" />
            <span>Card, Apple Pay &amp; Klarna</span>
          </button>

          <button
            type="button"
            role="tab"
            aria-selected={activeTab === 'hosted_checkout'}
            onClick={() => {
              setActiveTab('hosted_checkout')
              trackWhopEvent('initiate_checkout', {
                plan_key: planKey,
                amount_usd: templatePlan.priceUsd,
                checkout_surface: 'hosted_checkout_element',
              })
            }}
            className={`inline-flex min-h-10 items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition-all ${
              activeTab === 'hosted_checkout'
                ? 'bg-gradient-to-r from-[var(--roof-copper)] to-[var(--roof-amber)] text-white shadow-sm'
                : 'bg-[var(--roof-canvas)] text-[#374151] hover:bg-[var(--roof-surface)]'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            <span>Hosted Checkout Sheet</span>
          </button>
        </div>

        {/* 1-click Live vs Sandbox Test Card 4242 Switch */}
        {sandboxConfigured ? (
          <div className="inline-flex rounded-xl border border-[var(--roof-border)] bg-[var(--roof-canvas)] p-1 text-xs font-bold">
            <button
              type="button"
              onClick={() => loadConfig('production')}
              className={`rounded-lg px-2.5 py-1 transition-colors ${
                environmentMode === 'production'
                  ? 'bg-[var(--roof-ink)] text-white'
                  : 'text-[#4B5563] hover:text-[var(--roof-ink)]'
              }`}
            >
              Live Checkout
            </button>
            <button
              type="button"
              onClick={() => loadConfig('sandbox')}
              className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 transition-colors ${
                environmentMode === 'sandbox'
                  ? 'bg-amber-500 text-white'
                  : 'text-[#4B5563] hover:text-[var(--roof-ink)]'
              }`}
            >
              <TestTube2 className="h-3 w-3" />
              <span>Test Card (4242)</span>
            </button>
          </div>
        ) : (
          <span className="font-mono-num inline-flex items-center gap-1.5 rounded-full border border-emerald-300/60 bg-emerald-50 px-3 py-1 text-[11px] font-bold text-emerald-800">
            <ShieldCheck className="h-3.5 w-3.5" />
            WHOP ENCRYPTED
          </span>
        )}
      </div>

      {environmentMode === 'sandbox' && (
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-amber-300 bg-amber-50 px-4 py-2.5 text-xs text-amber-950">
          <div className="flex items-center gap-2 font-semibold">
            <TestTube2 className="h-4 w-4 shrink-0 text-amber-700" />
            <span>
              Sandbox Test Mode Active · Test Visa:{' '}
              <code className="font-mono-num rounded bg-white px-1.5 py-0.5 font-bold">
                4242 4242 4242 4242
              </code>{' '}
              (any future exp + 3-digit CVC)
            </span>
          </div>
          <span className="font-mono-num rounded-full bg-amber-200/80 px-2 py-0.5 text-[10px] font-bold">
            NO REAL CHARGE
          </span>
        </div>
      )}

      {/* Optional deposit execution toggle: $500 Deposit + Save Card vs $0 Authorize Only */}
      {planKey === 'deposit' && activeTab === 'payment_elements' && (
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-emerald-200 bg-emerald-50/75 px-4 py-2.5 text-xs">
          <div className="flex items-center gap-2 font-semibold text-emerald-900">
            <KeyRound className="h-4 w-4 text-emerald-700" />
            <span>SetupIntent Card-on-File Enabled for Final Balance Invoicing</span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setDepositExecutionMode('deposit_and_vault')}
              className={`rounded-lg px-2.5 py-1 text-[11px] font-bold transition-colors ${
                depositExecutionMode === 'deposit_and_vault'
                  ? 'bg-emerald-700 text-white'
                  : 'bg-white text-emerald-900 hover:bg-emerald-100'
              }`}
            >
              Pay ${templatePlan.priceUsd} + Save Card
            </button>
            <button
              type="button"
              onClick={() => setDepositExecutionMode('setup_only')}
              className={`rounded-lg px-2.5 py-1 text-[11px] font-bold transition-colors ${
                depositExecutionMode === 'setup_only'
                  ? 'bg-emerald-700 text-white'
                  : 'bg-white text-emerald-900 hover:bg-emerald-100'
              }`}
            >
              $0 Card Setup Only
            </button>
          </div>
        </div>
      )}

      {/* Compact Optional Pre-fill */}
      <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
        <input
          type="text"
          aria-label="Homeowner full name"
          placeholder={roofingTemplate.formPlaceholders.name}
          value={customerName}
          onChange={(e) => setCustomerName(e.target.value)}
          className="min-h-10 rounded-xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/70 px-3 text-xs text-[var(--roof-ink)] placeholder:text-[#6B7280] focus:border-[var(--roof-copper)]"
        />
        <input
          type="email"
          aria-label="Homeowner email"
          placeholder={`${roofingTemplate.formPlaceholders.email} (optional receipt prefill)`}
          value={customerEmail}
          onChange={(e) => setCustomerEmail(e.target.value)}
          className="min-h-10 rounded-xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/70 px-3 text-xs text-[var(--roof-ink)] placeholder:text-[#6B7280] focus:border-[var(--roof-copper)]"
        />
      </div>

      {configLoading ? (
        <div className="flex min-h-72 flex-col items-center justify-center gap-3 py-12 text-sm text-[#4B5563]">
          <Loader2 className="h-6 w-6 animate-spin text-[var(--roof-copper)]" />
          <span>Loading live Whop Payment Elements…</span>
        </div>
      ) : !canMountElements ? (
        <div className="mt-5 rounded-2xl border border-amber-300 bg-amber-50/75 p-6 text-sm text-[#141A21]">
          <div className="flex items-start gap-3">
            <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-[var(--roof-copper)]" />
            <div>
              <h3 className="font-display text-base font-bold text-[#141A21]">
                Checkout Pending Plan Provisioning
              </h3>
              <p className="mt-1.5 leading-relaxed text-[#374151]">
                Online checkout for this environment requires configured plan IDs. Call{' '}
                <a
                  href={roofingTemplate.brand.phoneHref}
                  className="font-semibold text-[var(--roof-copper-deep)] underline"
                >
                  {roofingTemplate.brand.phoneDisplay}
                </a>{' '}
                or switch to Test Card Mode if configured.
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="mt-5">
          {sdkLoadError && (
            <div className="mb-4 flex items-start gap-2 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-xs text-amber-900">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{sdkLoadError}</span>
            </div>
          )}

          {whopElementsPromise && (
            <WhopElements
              key={`${environmentMode}-${planKey}`}
              elements={whopElementsPromise}
              environment={environmentMode}
            >
              {/* Express Apple Pay / Google Pay Bar (Official Checkout Controller) */}
              <div className="mb-4 rounded-2xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/65 p-3.5">
                <div className="mb-2 flex items-center justify-between text-[11px] font-bold tracking-wider text-[#4B5563] uppercase">
                  <span>Express Wallet Checkout</span>
                  <span className="text-emerald-700">Apple Pay · Google Pay</span>
                </div>
                <Checkout
                  key={`express-${environmentMode}-${variantId}`}
                  plan={variantId}
                  returnUrl={hostedReturnUrl}
                  appearance={elementsAppearance}
                  onComplete={(payload) => {
                    handleCheckoutCompleted({
                      paymentId: payload.result === 'payment' ? payload.paymentId : null,
                      setupIntentId: payload.result === 'setup' ? payload.setupIntentId : null,
                      status: 'succeeded',
                    })
                  }}
                >
                  <ExpressCheckoutElement />
                </Checkout>
              </div>

              {activeTab === 'payment_elements' ? (
                planKey === 'deposit' ? (
                  <Payments
                    key={`setup-${environmentMode}-${planKey}`}
                    accountId={accountId}
                    mode="setup"
                    currency="usd"
                    appearance={elementsAppearance}
                  >
                    <InnerCheckoutForm
                      planKey={planKey}
                      priceUsd={templatePlan.priceUsd}
                      variantId={variantId}
                      mode="setup"
                      depositExecutionMode={depositExecutionMode}
                      environmentMode={environmentMode}
                      returnBaseUrl={returnBaseUrl}
                      customerName={customerName}
                      customerEmail={customerEmail}
                      onElementReady={() => setSdkLoadError(null)}
                      onElementError={(msg) => setSdkLoadError(msg)}
                      onCompleted={handleCheckoutCompleted}
                    />
                  </Payments>
                ) : (
                  <Payments
                    key={`pay-${environmentMode}-${variantId}`}
                    accountId={accountId}
                    plan={variantId}
                    appearance={elementsAppearance}
                  >
                    <InnerCheckoutForm
                      planKey={planKey}
                      priceUsd={templatePlan.priceUsd}
                      variantId={variantId}
                      mode="payment"
                      depositExecutionMode="deposit_and_vault"
                      environmentMode={environmentMode}
                      returnBaseUrl={returnBaseUrl}
                      customerName={customerName}
                      customerEmail={customerEmail}
                      onElementReady={() => setSdkLoadError(null)}
                      onElementError={(msg) => setSdkLoadError(msg)}
                      onCompleted={handleCheckoutCompleted}
                    />
                  </Payments>
                )
              ) : (
                <div className="space-y-4">
                  <div className="rounded-xl border border-[var(--roof-border)] bg-[var(--roof-canvas)] p-3.5 text-xs text-[#374151]">
                    <div className="flex items-center gap-2 font-semibold text-[#111827]">
                      <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                      <span>
                        Hosted Whop Checkout ({templatePlan.shortTitle}) ·{' '}
                        {environmentMode === 'sandbox' ? 'Sandbox' : 'Live'}
                      </span>
                    </div>
                    <p className="mt-1 text-[#4B5563]">
                      Supports 1-click Whop account checkout, Apple Pay, Google Pay, and automatic
                      Klarna / Afterpay / Splitit financing when enabled on the merchant account.
                    </p>
                  </div>

                  {!hostedReady && (
                    <div className="flex items-center gap-2 rounded-xl border border-[var(--roof-border)] bg-[var(--roof-canvas)]/70 p-4 text-xs text-[#4B5563]">
                      <Loader2 className="h-4 w-4 animate-spin text-[var(--roof-copper)]" />
                      <span>Loading Whop Checkout Sheet…</span>
                    </div>
                  )}

                  <Checkout
                    key={`hosted-${environmentMode}-${variantId}`}
                    plan={variantId}
                    returnUrl={hostedReturnUrl}
                    appearance={elementsAppearance}
                    onComplete={(payload) => {
                      handleCheckoutCompleted({
                        paymentId: payload.result === 'payment' ? payload.paymentId : null,
                        setupIntentId: payload.result === 'setup' ? payload.setupIntentId : null,
                        status: 'succeeded',
                      })
                    }}
                  >
                    <CheckoutElement
                      buyerEmail={customerEmail.trim() || undefined}
                      onReady={() => {
                        setHostedReady(true)
                        setSdkLoadError(null)
                      }}
                      onError={(err) => setSdkLoadError(err.message)}
                    />
                  </Checkout>
                </div>
              )}
            </WhopElements>
          )}
        </div>
      )}
    </div>
  )
}
