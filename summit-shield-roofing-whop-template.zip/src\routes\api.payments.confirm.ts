import { createFileRoute } from '@tanstack/react-router'
import type { WhopPlanKey } from '#/config/roofingTemplate'
import {
  createBuyerReceiptSetCookie,
  getAdminSession,
  hasBuyerReceiptAccess,
} from '#/server/auth'
import {
  createWhopServerClient,
  getResolvedPlans,
  handleWhopApiError,
  jsonResponse,
  requireAccountId,
  resolveAuthorizedRuntimeMode,
} from '#/server/whopServer'

interface ConfirmPaymentPayload {
  confirmationToken?: string
  setupIntentId?: string
  planKey?: WhopPlanKey
  email?: string
  returnUrl?: string
  metadata?: Record<string, string | null>
  environmentMode?: 'production' | 'sandbox'
}

export const Route = createFileRoute('/api/payments/confirm')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        try {
          const isAdmin = await getAdminSession(request)
          const url = new URL(request.url)
          const id = url.searchParams.get('id')?.trim()
          if (!id || !id.startsWith('pay_')) {
            return jsonResponse(
              { ok: false, code: 'INVALID_ID', message: 'Missing valid payment identifier.' },
              400,
            )
          }

          const hasReceipt = isAdmin || (await hasBuyerReceiptAccess(request, id))
          if (!hasReceipt) {
            return jsonResponse(
              {
                ok: false,
                code: 'UNAUTHORIZED',
                message: 'Not authorized to inspect this payment record.',
              },
              401,
            )
          }

          const mode = resolveAuthorizedRuntimeMode(url.searchParams.get('mode'), isAdmin, true)
          const whop = createWhopServerClient(mode)
          const [payment, status] = await Promise.all([
            whop.payments.retrieve({ id }),
            whop.payments.retrieveStatus({ payment_id: id }).catch(() => null),
          ])

          if (!isAdmin) {
            return jsonResponse({
              ok: true,
              redacted: true,
              payment: {
                status: payment.status,
                cardSaved: Boolean(payment.payment_method_id && payment.member_id),
                cardSummary: payment.payment_instrument?.display_name ?? null,
                failure_message: payment.failure_message ?? null,
              },
            })
          }

          return jsonResponse({
            ok: true,
            environment: mode,
            payment,
            paymentStatus: status,
          })
        } catch (error) {
          return handleWhopApiError(error, 'retrieving Whop payment')
        }
      },

      POST: async ({ request }) => {
        try {
          const isAdmin = await getAdminSession(request)
          const body = (await request.json().catch(() => null)) as ConfirmPaymentPayload | null
          const confirmationToken = body?.confirmationToken?.trim()
          const setupIntentId = body?.setupIntentId?.trim()
          const planKey: WhopPlanKey = body?.planKey ?? 'deposit'

          if (!confirmationToken && !setupIntentId) {
            return jsonResponse(
              {
                ok: false,
                code: 'MISSING_PAYMENT_CREDENTIAL',
                message: 'Missing confirmation token or saved SetupIntent identifier.',
              },
              400,
            )
          }

          const mode = resolveAuthorizedRuntimeMode(body?.environmentMode, isAdmin, true)
          const accountId = requireAccountId(mode)
          const plans = getResolvedPlans(mode)
          const planConfig = plans[planKey]

          if (!planConfig || !planConfig.isRealVariantId) {
            return jsonResponse(
              {
                ok: false,
                code: 'PLAN_NOT_PROVISIONED',
                message: `Selected plan "${planKey}" is not currently enabled.`,
              },
              503,
            )
          }

          const whop = createWhopServerClient(mode)
          const requestOrigin = new URL(request.url).origin
          const safeReturnUrl =
            body?.returnUrl?.trim() || `${requestOrigin}/checkout/return?plan=${planKey}`

          let payment
          if (setupIntentId) {
            if (!setupIntentId.startsWith('sint_')) {
              return jsonResponse(
                { ok: false, code: 'INVALID_SETUP_INTENT', message: 'Invalid setupIntentId.' },
                400,
              )
            }
            const hasSetupReceipt = isAdmin || (await hasBuyerReceiptAccess(request, setupIntentId))
            if (!hasSetupReceipt) {
              return jsonResponse(
                {
                  ok: false,
                  code: 'UNAUTHORIZED_SETUP_INTENT',
                  message: 'Not authorized to charge this card setup session.',
                },
                401,
              )
            }

            const setupIntent = await whop.setupIntents.retrieve({ id: setupIntentId })
            if (!setupIntent.member_id || !setupIntent.payment_method_id) {
              return jsonResponse(
                {
                  ok: false,
                  code: 'SETUP_METHOD_NOT_READY',
                  message:
                    'Your card setup did not produce a saved payment method yet. Please retry authorization.',
                },
                400,
              )
            }

            payment = await whop.payments.create({
              account_id: accountId,
              variant_id: planConfig.variantId,
              member_id: setupIntent.member_id,
              payment_method_id: setupIntent.payment_method_id,
              off_session: false,
              return_url: safeReturnUrl,
              metadata: {
                template_plan_key: planKey,
                setup_intent_id: setupIntentId,
                vaulted_for_final_invoice: 'true',
                ...(body?.metadata ?? {}),
              },
            })
          } else {
            payment = await whop.payments.create({
              account_id: accountId,
              variant_id: planConfig.variantId,
              confirmation_token: confirmationToken!,
              return_url: safeReturnUrl,
              ...(body?.email?.trim() ? { email: body.email.trim() } : {}),
              metadata: {
                template_plan_key: planKey,
                vaulted_for_final_invoice: planConfig.supportsSetupIntentVault ? 'true' : 'false',
                ...(body?.metadata ?? {}),
              },
            })
          }

          const receiptCookie = await createBuyerReceiptSetCookie(request, payment.id)
          const extraHeaders = receiptCookie ? { 'Set-Cookie': receiptCookie } : undefined

          if (!isAdmin) {
            return jsonResponse(
              {
                ok: true,
                payment: {
                  id: payment.id,
                  status: payment.status,
                  client_secret: payment.client_secret,
                },
                clientSecret: payment.client_secret,
              },
              201,
              extraHeaders,
            )
          }

          return jsonResponse(
            {
              ok: true,
              environment: mode,
              payment,
              clientSecret: payment.client_secret,
            },
            201,
            extraHeaders,
          )
        } catch (error) {
          return handleWhopApiError(error, 'confirming Whop payment')
        }
      },
    },
  },
})
