import { createFileRoute } from '@tanstack/react-router'
import {
  createAdminClearCookie,
  createAdminSetCookie,
  getAdminSession,
  isAdminPasscodeConfigured,
  verifyAdminPasscode,
} from '#/server/auth'
import { jsonResponse } from '#/server/whopServer'

interface AdminLoginPayload {
  passcode?: string
}

export const Route = createFileRoute('/api/admin/auth')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const authenticated = await getAdminSession(request)
        return jsonResponse({
          ok: true,
          authenticated,
          passcodeConfigured: isAdminPasscodeConfigured(),
        })
      },

      POST: async ({ request }) => {
        if (!isAdminPasscodeConfigured()) {
          return jsonResponse(
            {
              ok: false,
              code: 'PORTAL_AUTH_UNCONFIGURED',
              message: 'Contractor Portal passcode is not configured on this server yet.',
            },
            503,
          )
        }

        const body = (await request.json().catch(() => null)) as AdminLoginPayload | null
        const passcode = body?.passcode?.trim() ?? ''

        if (!passcode) {
          return jsonResponse(
            {
              ok: false,
              code: 'MISSING_PASSCODE',
              message: 'Enter your contractor portal passcode.',
            },
            400,
          )
        }

        const valid = await verifyAdminPasscode(passcode)
        if (!valid) {
          return jsonResponse(
            {
              ok: false,
              code: 'INVALID_PASSCODE',
              message: 'Invalid contractor portal passcode.',
            },
            401,
          )
        }

        const cookie = await createAdminSetCookie(request)
        if (!cookie) {
          return jsonResponse(
            {
              ok: false,
              code: 'SESSION_SIGNING_FAILED',
              message: 'Unable to issue signed portal session cookie.',
            },
            500,
          )
        }

        return new Response(
          JSON.stringify({
            ok: true,
            authenticated: true,
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json; charset=utf-8',
              'Cache-Control': 'no-store',
              'Set-Cookie': cookie,
            },
          },
        )
      },

      DELETE: async ({ request }) => {
        return new Response(
          JSON.stringify({
            ok: true,
            authenticated: false,
          }),
          {
            status: 200,
            headers: {
              'Content-Type': 'application/json; charset=utf-8',
              'Cache-Control': 'no-store',
              'Set-Cookie': createAdminClearCookie(request),
            },
          },
        )
      },
    },
  },
})
