import { Link } from '@tanstack/react-router'
import { Clock, Lock, Mail, MapPin, Phone, ShieldCheck } from 'lucide-react'
import { roofingTemplate } from '#/config/roofingTemplate'

interface FooterProps {
  onOpenPortal?: () => void
}

export function Footer({ onOpenPortal }: FooterProps) {
  const { brand, plans, serviceArea, templateMeta } = roofingTemplate

  return (
    <footer
      id="contact"
      className="bg-architectural-grid-dark relative overflow-hidden bg-[var(--roof-obsidian)] pt-14 pb-24 text-white lg:pb-14"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute right-10 -bottom-24 h-72 w-72 rounded-full bg-[var(--roof-copper)]/14 blur-[110px]"
      />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-12">
          {/* Brand Summary */}
          <div className="md:col-span-5">
            <div className="font-display text-xl font-extrabold text-white">{brand.name}</div>
            <p className="mt-2 max-w-md text-sm leading-relaxed text-white/70">{brand.tagline}</p>
            <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-emerald-400/25 bg-emerald-500/12 px-3.5 py-1.5 text-xs font-semibold text-emerald-300">
              <ShieldCheck className="h-4 w-4" />
              <span>{brand.licenseNumber}</span>
            </div>
            <div className="mt-5 flex items-start gap-2.5 rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-xs text-white/75">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[var(--roof-copper-light)]" />
              <span>{templateMeta.rebrandInstructions}</span>
            </div>
          </div>

          {/* Contact */}
          <div className="space-y-3 text-sm md:col-span-4">
            <div className="font-display text-xs font-bold tracking-wider text-[var(--roof-copper-light)] uppercase">
              Dispatch & Office
            </div>
            <a
              href={brand.phoneHref}
              className="flex items-center gap-2.5 text-white transition-colors hover:text-[var(--roof-amber-light)]"
            >
              <Phone className="h-4 w-4 text-[var(--roof-copper)]" />
              <span className="font-mono-num font-semibold">{brand.phoneDisplay}</span>
            </a>
            <a
              href={`mailto:${brand.email}`}
              className="flex items-center gap-2.5 text-white/80 transition-colors hover:text-white"
            >
              <Mail className="h-4 w-4 text-[var(--roof-copper)]" />
              <span>{brand.email}</span>
            </a>
            <div className="flex items-start gap-2.5 text-white/75">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[var(--roof-copper)]" />
              <span>
                {brand.streetAddress}
                <br />
                {brand.cityStateZip}
              </span>
            </div>
            <div className="flex items-start gap-2.5 text-white/75">
              <Clock className="mt-0.5 h-4 w-4 shrink-0 text-[var(--roof-copper)]" />
              <span>{brand.serviceHours}</span>
            </div>
          </div>

          {/* Quick Sections */}
          <div className="md:col-span-3">
            <div className="font-display text-xs font-bold tracking-wider text-[var(--roof-copper-light)] uppercase">
              Services & Billing
            </div>
            <ul className="mt-3 space-y-2 text-sm text-white/75">
              <li>
                <Link to="/" hash="services" className="transition-colors hover:text-white">
                  Inspection & Repair Scopes
                </Link>
              </li>
              <li>
                <Link
                  to="/book/$slug"
                  params={{ slug: 'inspection' }}
                  className="transition-colors hover:text-white"
                >
                  Book ${plans.inspection.priceUsd} Roof Inspection
                </Link>
              </li>
              <li>
                <Link to="/deposit" className="transition-colors hover:text-white">
                  Lock ${plans.deposit.priceUsd} Project Deposit
                </Link>
              </li>
              <li>
                <Link
                  to="/book/$slug"
                  params={{ slug: 'tune-up' }}
                  className="transition-colors hover:text-white"
                >
                  Flat-Rate ${plans.tuneup.priceUsd} Tune-Up
                </Link>
              </li>
              <li>
                <Link to="/" hash="estimate-form" className="transition-colors hover:text-white">
                  Request a Free Written Estimate
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-start justify-between gap-4 border-t border-white/10 pt-6 text-xs text-white/55 sm:flex-row sm:items-center">
          <div>
            © {new Date().getFullYear()} {brand.name} · Serving {serviceArea.regionLabel}
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <span>Encrypted checkout powered by Whop Payments</span>
            {onOpenPortal && (
              <button
                type="button"
                onClick={onOpenPortal}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-2.5 py-1 text-xs font-medium text-white/75 transition-colors hover:border-white/30 hover:text-white"
              >
                <Lock className="h-3 w-3 text-[var(--roof-copper-light)]" />
                <span>Contractor Portal</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Modern Dark Frosted Mobile Sticky Action Bar */}
      <div className="fixed right-0 bottom-0 left-0 z-30 border-t border-white/12 bg-[var(--roof-obsidian)]/92 px-3 py-2.5 backdrop-blur-xl lg:hidden">
        <div className="mx-auto grid max-w-md grid-cols-3 gap-2">
          <a
            href={brand.phoneHref}
            className="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-xl border border-white/15 bg-white/8 px-2 text-xs font-bold text-white"
          >
            <Phone className="h-3.5 w-3.5 text-[var(--roof-amber-light)]" />
            <span>Call Crew</span>
          </a>
          <Link
            to="/"
            hash="estimate-form"
            className="inline-flex min-h-11 items-center justify-center rounded-xl border border-white/20 bg-white/12 px-2 text-xs font-bold text-white"
          >
            Free Estimate
          </Link>
          <Link
            to="/deposit"
            className="btn-shimmer inline-flex min-h-11 items-center justify-center rounded-xl bg-gradient-to-r from-[var(--roof-copper)] to-[var(--roof-amber)] px-2 text-xs font-bold text-white shadow-md"
          >
            Pay ${plans.deposit.priceUsd} Deposit
          </Link>
        </div>
      </div>
    </footer>
  )
}
