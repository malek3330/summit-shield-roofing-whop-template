import { Link } from '@tanstack/react-router'
import { ArrowRight, CheckCircle2, KeyRound, ShieldCheck, Wallet } from 'lucide-react'
import { roofingTemplate, type WhopPlanKey } from '#/config/roofingTemplate'
import type { PublicRuntimeConfig } from '#/lib/types'
import { trackWhopEvent } from '#/lib/whopPixel'

interface PlansShowcaseSectionProps {
  runtimeConfig: PublicRuntimeConfig | null
}

function getPlanRouteProps(key: WhopPlanKey) {
  if (key === 'deposit') {
    return { to: '/deposit' as const }
  }
  return {
    to: '/book/$slug' as const,
    params: { slug: key === 'tuneup' ? 'tune-up' : 'inspection' },
  }
}

export function PlansShowcaseSection({ runtimeConfig }: PlansShowcaseSectionProps) {
  const planOrder: WhopPlanKey[] = ['inspection', 'deposit', 'tuneup']

  return (
    <section
      id="checkout-flow"
      className="relative border-b border-[var(--roof-border)] bg-gradient-to-b from-[var(--roof-canvas)] via-[var(--roof-surface)] to-[var(--roof-canvas)] py-14 sm:py-20"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-[var(--roof-copper)]/25 bg-white px-3.5 py-1 text-xs font-bold tracking-wider text-[var(--roof-copper-deep)] uppercase shadow-2xs">
              <Wallet className="h-3.5 w-3.5 text-[var(--roof-copper)]" />
              <span>Step 1 &amp; 2 · Instant Whop Checkout Plans</span>
            </div>
            <h2 className="font-display mt-3 text-3xl font-extrabold text-[var(--roof-ink)] sm:text-4xl">
              Zero-Friction Inspection, Deposit &amp; Flat-Rate Booking.
            </h2>
            <p className="mt-3 text-base text-[#4B5563]">
              Select any plan to open encrypted, PCI-isolated Whop Payment Elements checkout—pay by
              card, Apple Pay, Google Pay, or split eligible balances with Klarna, Afterpay, and
              Splitit.
            </p>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {[
              { label: 'Apple Pay', cls: 'bg-[#111827] text-white' },
              { label: 'Google Pay', cls: 'bg-white text-[#111827] border border-[#E2DACB]' },
              { label: 'Klarna', cls: 'bg-pink-100 text-pink-900 border border-pink-200' },
              { label: 'Afterpay', cls: 'bg-emerald-100 text-emerald-900 border border-emerald-200' },
              { label: 'Splitit', cls: 'bg-sky-100 text-sky-900 border border-sky-200' },
            ].map((pill) => (
              <span
                key={pill.label}
                className={`rounded-full px-3 py-1 text-[11px] font-bold shadow-2xs ${pill.cls}`}
              >
                {pill.label}
              </span>
            ))}
          </div>
        </div>

        {/* 3 Real Whop Plans Grid */}
        <div className="mt-9 grid gap-6 lg:grid-cols-3">
          {planOrder.map((key) => {
            const plan = roofingTemplate.plans[key]
            const liveMeta = runtimeConfig?.plans?.[key]
            const isDeposit = key === 'deposit'
            const routeProps = getPlanRouteProps(key)

            return (
              <article
                key={key}
                data-whop-product-id={liveMeta?.productId || undefined}
                data-whop-variant-id={liveMeta?.variantId || undefined}
                data-whop-price={String(plan.priceUsd)}
                data-whop-currency="USD"
                className={`flex flex-col justify-between rounded-3xl border p-6 transition-all duration-300 hover:-translate-y-1 ${
                  isDeposit
                    ? 'border-[var(--roof-copper)] bg-gradient-to-b from-[var(--roof-obsidian)] to-[var(--roof-midnight)] text-white shadow-[0_24px_60px_-20px_rgba(17,24,39,0.5)]'
                    : 'border-[var(--roof-border)] bg-white text-[var(--roof-ink)] shadow-sm hover:border-[var(--roof-copper)]/60 hover:shadow-lg'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <span
                      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-bold tracking-wider uppercase ${
                        isDeposit
                          ? 'border border-emerald-400/35 bg-emerald-500/20 text-emerald-300'
                          : 'bg-[var(--roof-copper)]/10 text-[var(--roof-copper-deep)]'
                      }`}
                    >
                      {isDeposit && <KeyRound className="h-3 w-3" />}
                      {plan.badge}
                    </span>
                    <div
                      className={`font-mono-num text-2xl font-extrabold ${
                        isDeposit ? 'text-[var(--roof-copper-light)]' : 'text-[var(--roof-copper)]'
                      }`}
                    >
                      ${plan.priceUsd}
                    </div>
                  </div>

                  <h3
                    className={`font-display mt-3 text-xl font-bold ${
                      isDeposit ? 'text-white' : 'text-[var(--roof-ink)]'
                    }`}
                  >
                    {plan.title}
                  </h3>

                  <p
                    className={`mt-2 text-sm leading-relaxed ${
                      isDeposit ? 'text-white/75' : 'text-[#4B5563]'
                    }`}
                  >
                    {plan.description}
                  </p>

                  <ul
                    className={`mt-5 space-y-2.5 border-t pt-4 text-xs ${
                      isDeposit
                        ? 'border-white/12 text-white/85'
                        : 'border-[var(--roof-border)]/70 text-[#374151]'
                    }`}
                  >
                    {plan.deliverables.map((item) => (
                      <li key={item} className="flex items-start gap-2">
                        <CheckCircle2
                          className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${
                            isDeposit ? 'text-emerald-400' : 'text-emerald-600'
                          }`}
                        />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-6 space-y-3">
                  <div
                    className={`flex items-center justify-between text-[11px] ${
                      isDeposit ? 'text-white/65' : 'text-[#6B7280]'
                    }`}
                  >
                    <span>{plan.billingLabel}</span>
                    <span className="inline-flex items-center gap-1 font-semibold text-emerald-600">
                      <ShieldCheck
                        className={`h-3.5 w-3.5 ${isDeposit ? 'text-emerald-400' : 'text-emerald-600'}`}
                      />
                      <span className={isDeposit ? 'text-emerald-300' : 'text-emerald-700'}>
                        {liveMeta?.isRealVariantId ? 'Whop Live & Sandbox Ready' : 'Ready'}
                      </span>
                    </span>
                  </div>

                  <Link
                    {...routeProps}
                    onClick={() => {
                      trackWhopEvent('service_viewed', {
                        service_id: key,
                        service_title: plan.title,
                        price_usd: plan.priceUsd,
                        source: 'plans_showcase_grid',
                      })
                      if (isDeposit) {
                        trackWhopEvent('deposit_started', {
                          plan_key: 'deposit',
                          amount_usd: plan.priceUsd,
                          source: 'plans_showcase_cta',
                        })
                      }
                    }}
                    className={`btn-shimmer inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition-all ${
                      isDeposit
                        ? 'bg-gradient-to-r from-[var(--roof-copper)] via-[var(--roof-copper-deep)] to-[var(--roof-amber)] text-white shadow-lg'
                        : 'bg-[var(--roof-ink)] text-white hover:bg-[var(--roof-copper)]'
                    }`}
                  >
                    <span>
                      {isDeposit
                        ? `Pay $${plan.priceUsd} Deposit & Save Card`
                        : `Continue to $${plan.priceUsd} Checkout`}
                    </span>
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
              </article>
            )
          })}
        </div>
      </div>
    </section>
  )
}
