import type { ReactNode } from 'react'
import { Link } from '@tanstack/react-router'
import {
  ArrowRight,
  Award,
  CheckCircle2,
  FileText,
  MapPin,
  Radar,
  ShieldCheck,
  Sparkles,
  Star,
  Zap,
} from 'lucide-react'
import { roofingTemplate, type WhopPlanKey } from '#/config/roofingTemplate'
import { trackWhopEvent } from '#/lib/whopPixel'

interface HeroProps {
  selectedPlanKey?: WhopPlanKey
  onChoosePlanAndScroll?: (planKey: WhopPlanKey) => void
}

const PLAN_ACCENTS: Record<
  WhopPlanKey,
  { ring: string; badge: string; price: string; dot: string }
> = {
  inspection: {
    ring: 'border-sky-400/70 bg-sky-500/15 shadow-[0_0_24px_-6px_rgba(56,189,248,0.55)]',
    badge: 'text-sky-300',
    price: 'text-sky-300',
    dot: 'bg-sky-400',
  },
  deposit: {
    ring: 'border-[var(--roof-copper-light)]/80 bg-gradient-to-br from-[var(--roof-copper)]/25 to-[var(--roof-amber)]/15 shadow-[0_0_28px_-6px_color-mix(in_srgb,var(--roof-copper)_65%,transparent)]',
    badge: 'text-[var(--roof-amber-light)]',
    price: 'text-[var(--roof-copper-light)]',
    dot: 'bg-[var(--roof-copper-light)]',
  },
  tuneup: {
    ring: 'border-emerald-400/70 bg-emerald-500/15 shadow-[0_0_24px_-6px_rgba(16,185,129,0.55)]',
    badge: 'text-emerald-300',
    price: 'text-emerald-300',
    dot: 'bg-emerald-400',
  },
}

function renderHighlightedHeadline(
  headline: string,
  primary?: string,
  secondary?: string,
): ReactNode {
  const targets = [
    primary
      ? {
          phrase: primary,
          cls: 'bg-gradient-to-r from-[var(--roof-copper-light)] via-[var(--roof-amber-light)] to-[var(--roof-copper)] bg-clip-text text-transparent',
        }
      : null,
    secondary
      ? {
          phrase: secondary,
          cls: 'bg-gradient-to-r from-sky-300 via-emerald-300 to-teal-200 bg-clip-text text-transparent',
        }
      : null,
  ].filter((t): t is { phrase: string; cls: string } => Boolean(t?.phrase))

  if (targets.length === 0) return headline

  let segments: Array<{ text: string; cls?: string }> = [{ text: headline }]
  for (const target of targets) {
    const nextSegments: Array<{ text: string; cls?: string }> = []
    for (const seg of segments) {
      if (seg.cls) {
        nextSegments.push(seg)
        continue
      }
      const idx = seg.text.indexOf(target.phrase)
      if (idx === -1) {
        nextSegments.push(seg)
        continue
      }
      if (idx > 0) nextSegments.push({ text: seg.text.slice(0, idx) })
      nextSegments.push({ text: target.phrase, cls: target.cls })
      const after = seg.text.slice(idx + target.phrase.length)
      if (after) nextSegments.push({ text: after })
    }
    segments = nextSegments
  }

  return segments.map((seg, i) =>
    seg.cls ? (
      <span key={`${seg.text}-${i}`} className={seg.cls}>
        {seg.text}
      </span>
    ) : (
      <span key={`${seg.text}-${i}`}>{seg.text}</span>
    ),
  )
}

export function Hero({ selectedPlanKey = 'deposit' }: HeroProps) {
  const { hero, brand, plans, serviceArea } = roofingTemplate
  const marqueeItems = [
    brand.licenseNumber,
    'Class 4 Hail-Impact Shingles & Standing-Seam Metal',
    'Secure Whop Payments · Apple Pay · Google Pay',
    'Klarna · Afterpay · Splitit Installments Ready',
    `Protected $${plans.deposit.priceUsd} Project Deposit · Digital Closing Invoice`,
    `${serviceArea.regionLabel} · 24-Hr Emergency Storm Tarping`,
  ]

  const getPlanLink = (key: WhopPlanKey) =>
    key === 'deposit'
      ? { to: '/deposit' as const }
      : {
          to: '/book/$slug' as const,
          params: { slug: key === 'tuneup' ? 'tune-up' : 'inspection' },
        }

  return (
    <section
      id="top"
      className="bg-architectural-grid-dark relative overflow-hidden bg-[var(--roof-obsidian)] text-white"
    >
      {/* Animated multi-hue architectural aurora ambient lights */}
      <div
        aria-hidden="true"
        className="animate-aurora-slow pointer-events-none absolute -top-28 -left-24 h-96 w-96 rounded-full bg-[var(--roof-copper)]/24 blur-[120px]"
      />
      <div
        aria-hidden="true"
        className="animate-aurora-reverse pointer-events-none absolute top-24 right-[-6rem] h-[28rem] w-[28rem] rounded-full bg-emerald-500/14 blur-[130px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute bottom-12 left-1/3 h-64 w-64 rounded-full bg-[var(--roof-amber)]/10 blur-[110px]"
      />

      <div className="relative mx-auto max-w-7xl px-4 pt-9 pb-12 sm:px-6 sm:pt-14 sm:pb-16 lg:px-8 lg:pt-16 lg:pb-20">
        <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Left column */}
          <div className="lg:col-span-6">
            <div className="inline-flex max-w-full items-center gap-2 rounded-full border border-white/15 bg-white/8 px-3.5 py-1.5 text-xs font-semibold text-white/90 shadow-sm backdrop-blur-md">
              <span className="relative flex h-2 w-2 shrink-0">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[var(--roof-copper-light)] opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-[var(--roof-copper-light)]" />
              </span>
              <MapPin className="h-3.5 w-3.5 shrink-0 text-[var(--roof-amber-light)]" />
              <span className="leading-snug">{hero.eyebrow}</span>
            </div>

            <h1 className="font-display mt-5 text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-[3.5rem] lg:leading-[1.04]">
              {renderHighlightedHeadline(
                hero.headline,
                hero.headlineHighlightPrimary,
                hero.headlineHighlightSecondary,
              )}
            </h1>

            <p className="mt-5 max-w-xl text-base leading-relaxed text-white/75 sm:text-lg">
              {hero.subheadline}
            </p>

            {/* Primary conversion CTAs */}
            <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:items-center">
              <Link
                to="/book/$slug"
                params={{ slug: 'inspection' }}
                onClick={() =>
                  trackWhopEvent('service_viewed', {
                    service_id: 'inspection',
                    service_title: plans.inspection.title,
                    price_usd: plans.inspection.priceUsd,
                    source: 'hero_primary_cta',
                  })
                }
                className="btn-shimmer inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[var(--roof-copper)] via-[var(--roof-copper-deep)] to-[var(--roof-amber)] px-6 py-3.5 text-base font-bold text-white shadow-[0_12px_30px_-8px_color-mix(in_srgb,var(--roof-copper)_75%,transparent)] transition-all hover:-translate-y-0.5 hover:shadow-[0_18px_36px_-8px_color-mix(in_srgb,var(--roof-copper)_90%,transparent)]"
              >
                <span>{hero.primaryCta}</span>
                <ArrowRight className="h-4 w-4" />
              </Link>

              <a
                href="#estimate-form"
                className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/8 px-6 py-3.5 text-base font-semibold text-white backdrop-blur-md transition-all hover:-translate-y-0.5 hover:border-white/40 hover:bg-white/14"
              >
                <FileText className="h-4 w-4 text-[var(--roof-amber-light)]" />
                <span>{hero.secondaryCta}</span>
              </a>
            </div>

            {/* Direct 3-Plan Whop Billing Switcher Strip */}
            <div className="mt-8 rounded-2xl border border-white/15 bg-white/[0.06] p-4 shadow-2xl backdrop-blur-xl">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 text-xs font-semibold tracking-wider text-white/70 uppercase">
                <span className="flex items-center gap-1.5 text-white/90">
                  <Sparkles className="h-3.5 w-3.5 text-[var(--roof-amber-light)]" />
                  Instant Whop Checkout Plans
                </span>
                <span className="font-mono-num rounded-full border border-emerald-400/30 bg-emerald-500/15 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-300">
                  Apple Pay · Cards · Klarna
                </span>
              </div>
              <div className="grid gap-2.5 sm:grid-cols-3">
                {(['inspection', 'deposit', 'tuneup'] as const).map((key) => {
                  const plan = plans[key]
                  const active = selectedPlanKey === key
                  const accent = PLAN_ACCENTS[key]
                  const compactTitle =
                    plan.cardLabel || plan.shortTitle.replace(/\s*\([^)]+\)\s*$/, '')
                  return (
                    <Link
                      key={key}
                      {...getPlanLink(key)}
                      onClick={() =>
                        trackWhopEvent('service_viewed', {
                          service_id: key,
                          service_title: plan.title,
                          price_usd: plan.priceUsd,
                          source: 'hero_plan_strip',
                        })
                      }
                      className={`group flex min-h-16 flex-col items-start justify-between rounded-xl border px-3.5 py-2.5 text-left transition-all duration-200 hover:-translate-y-0.5 ${
                        active
                          ? accent.ring
                          : 'border-white/12 bg-white/[0.04] hover:border-white/30 hover:bg-white/10'
                      }`}
                    >
                      <span
                        className={`flex items-center gap-1.5 text-[10px] font-bold tracking-wider uppercase ${
                          active ? accent.badge : 'text-white/60'
                        }`}
                      >
                        <span className={`h-1.5 w-1.5 rounded-full ${accent.dot}`} />
                        {plan.badge}
                      </span>
                      <div className="mt-1.5 flex w-full items-baseline justify-between gap-2">
                        <span className="font-display text-sm font-bold text-white">
                          {compactTitle}
                        </span>
                        <span
                          className={`font-mono-num text-sm font-extrabold ${
                            active ? accent.price : 'text-[var(--roof-copper-light)]'
                          }`}
                        >
                          ${plan.priceUsd}
                        </span>
                      </div>
                    </Link>
                  )
                })}
              </div>
            </div>

            {/* Stat bar */}
            <dl className="mt-7 grid grid-cols-2 gap-4 border-t border-white/12 pt-6 sm:grid-cols-4">
              {hero.stats.map((stat, idx) => {
                const statGradients = [
                  'from-white to-white/80',
                  'from-[var(--roof-amber-light)] to-yellow-200',
                  'from-emerald-300 to-teal-200',
                  'from-[var(--roof-copper-light)] to-[var(--roof-amber-light)]',
                ]
                return (
                  <div
                    key={stat.label}
                    className="rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2.5 transition-colors hover:border-white/20"
                  >
                    <dt
                      className={`font-mono-num bg-gradient-to-r ${statGradients[idx % statGradients.length]} bg-clip-text text-xl font-extrabold text-transparent sm:text-2xl`}
                    >
                      {stat.value}
                    </dt>
                    <dd className="mt-0.5 text-xs font-medium text-white/65">{stat.label}</dd>
                  </div>
                )
              })}
            </dl>
          </div>

          {/* Right column: cinematic architectural composition */}
          <div className="lg:col-span-6">
            <div className="relative">
              {/* Glowing gradient frame */}
              <div className="relative rounded-3xl bg-gradient-to-br from-[var(--roof-copper-light)]/45 via-white/15 to-emerald-400/40 p-[1.5px] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.85)]">
                <div className="relative overflow-hidden rounded-[calc(1.5rem-1.5px)] bg-[var(--roof-midnight)]">
                  <img
                    src={hero.heroImage}
                    alt={hero.heroImageAlt}
                    className="animate-ken-burns aspect-[4/3] w-full object-cover"
                  />
                  {/* Subtle cinematic contrast scrim */}
                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[var(--roof-obsidian)]/90 via-[var(--roof-obsidian)]/20 to-transparent" />

                  {/* Floating Live Drone / Thermal Chip */}
                  <div className="animate-float-subtle absolute top-4 right-4 hidden items-center gap-2 rounded-full border border-white/20 bg-[var(--roof-obsidian)]/80 px-3.5 py-1.5 text-xs font-semibold text-white shadow-lg backdrop-blur-md sm:inline-flex">
                    <Radar className="h-3.5 w-3.5 text-sky-400" />
                    <span>{hero.topRightBadge}</span>
                  </div>

                  <div className="animate-float-subtle absolute top-4 left-4 hidden items-center gap-1.5 rounded-full border border-[var(--roof-amber)]/35 bg-[var(--roof-obsidian)]/80 px-3 py-1.5 text-xs font-semibold text-[var(--roof-amber-light)] shadow-lg backdrop-blur-md sm:inline-flex">
                    <Award className="h-3.5 w-3.5" />
                    <span>{hero.topLeftBadge}</span>
                  </div>
                </div>
              </div>

              {/* Floating Deposit -> Job -> Final Balance Workflow Card */}
              <div className="mt-4 rounded-2xl border border-white/18 bg-[var(--roof-midnight)]/95 p-4 text-white shadow-2xl backdrop-blur-xl sm:absolute sm:right-4 sm:bottom-4 sm:left-4 sm:mt-0">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/12 pb-3">
                  <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-[var(--roof-copper-light)] uppercase">
                    <ShieldCheck className="h-4 w-4 text-[var(--roof-copper)]" />
                    <span>{hero.workflowCardTitle}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs font-semibold text-[var(--roof-amber-light)]">
                    <Star className="h-3.5 w-3.5 fill-amber-300 text-amber-300" />
                    <span>
                      {brand.rating} ({brand.reviewCount} reviews)
                    </span>
                  </div>
                </div>

                <div className="mt-3 grid grid-cols-1 gap-2 text-xs sm:grid-cols-3">
                  <Link
                    to="/deposit"
                    onClick={() =>
                      trackWhopEvent('deposit_started', {
                        plan_key: 'deposit',
                        amount_usd: plans.deposit.priceUsd,
                        source: 'hero_workflow_card',
                      })
                    }
                    className="rounded-xl border border-white/10 bg-white/6 p-2.5 text-left transition-all hover:border-[var(--roof-copper-light)]/60 hover:bg-white/12"
                  >
                    <div className="font-mono-num flex items-center justify-between text-[11px] text-[var(--roof-copper-light)]">
                      <span>STEP 01</span>
                      <Zap className="h-3 w-3" />
                    </div>
                    <div className="mt-0.5 font-semibold text-white">
                      ${plans.inspection.priceUsd} Inspect / ${plans.deposit.priceUsd} Deposit
                    </div>
                    <div className="mt-0.5 text-[11px] text-white/65">100% credited to job</div>
                  </Link>
                  <div className="rounded-xl border border-sky-400/20 bg-sky-500/10 p-2.5">
                    <div className="font-mono-num text-[11px] text-sky-300">STEP 02</div>
                    <div className="mt-0.5 font-semibold text-white">Materials & Tear-Off</div>
                    <div className="mt-0.5 text-[11px] text-white/70">1–2 day crew install</div>
                  </div>
                  <a
                    href="#invoice-flow"
                    className="rounded-xl border border-emerald-400/35 bg-emerald-500/15 p-2.5 transition-all hover:bg-emerald-500/25"
                  >
                    <div className="font-mono-num text-[11px] text-emerald-300">STEP 03</div>
                    <div className="mt-0.5 flex items-center gap-1 font-semibold text-white">
                      <CheckCircle2 className="h-3 w-3 shrink-0 text-emerald-300" />
                      Final Invoice
                    </div>
                    <div className="mt-0.5 text-[11px] text-emerald-100/80">Online pay or auto-settle</div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Live scrolling architectural trust ticker */}
      <div className="overflow-hidden border-t border-white/10 bg-gradient-to-r from-[var(--roof-midnight)] via-[#1C2635] to-[var(--roof-midnight)] py-3">
        <div className="animate-marquee flex items-center gap-8 text-xs font-semibold tracking-wider text-white/75 uppercase">
          {[...marqueeItems, ...marqueeItems].map((item, index) => (
            <span key={`${item}-${index}`} className="inline-flex shrink-0 items-center gap-3">
              <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-r from-[var(--roof-copper-light)] to-[var(--roof-amber-light)]" />
              <span>{item}</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}
