import { useCallback, useEffect, useState } from 'react'
import {
  Activity,
  AlertCircle,
  Check,
  ClipboardList,
  Copy,
  CreditCard,
  KeyRound,
  Loader2,
  Lock,
  LogOut,
  ReceiptText,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  TestTube2,
  Unlock,
  X,
} from 'lucide-react'
import { roofingTemplate } from '#/config/roofingTemplate'
import type { PublicRuntimeConfig, VaultedCustomerRecord } from '#/lib/types'
import { trackWhopEvent, type PixelEventRecord } from '#/lib/whopPixel'

type PortalTab = 'leads' | 'vault' | 'pixel' | 'sandbox'

interface PortalLeadItem {
  id: string
  created_at?: string
  metadata?: Record<string, string> | null
  product?: { title?: string } | null
  user?: { email?: string | null; name?: string | null; username?: string | null } | null
}

interface PortalLeadEventItem {
  id: string
  event_id?: string
  event_name: string
  custom_name?: string | null
  event_time: string
  total_usd_amount?: number | null
  user?: {
    email?: string | null
    name?: string | null
    phone?: string | null
    city?: string | null
  } | null
  related?: {
    product?: { title?: string | null } | null
    user?: { name?: string | null; username?: string | null } | null
  } | null
}

interface PortalPersonLeadItem {
  id: string
  email?: string | null
  name?: string | null
  phone?: string | null
  last_seen_at?: string
  event_count?: number
  user?: { id?: string; name?: string | null; username?: string } | null
}

interface PortalVaultItem {
  id: string
  kind: 'setup_intent' | 'payment'
  status: string
  memberId: string
  paymentMethodId: string
  email: string
  name: string
  cardLabel: string
  createdAt: string
}

interface PixelTelemetryDrawerProps {
  open: boolean
  onClose: () => void
  events: PixelEventRecord[]
  runtimeConfig: PublicRuntimeConfig | null
  vaultedCustomer: VaultedCustomerRecord | null
  checkoutMode: 'production' | 'sandbox'
  onSwitchCheckoutMode: (mode: 'production' | 'sandbox') => Promise<void> | void
  onAuthChanged: (authenticated: boolean) => Promise<void> | void
  onApplyVaultTarget: (record: VaultedCustomerRecord) => void
}

export function PixelTelemetryDrawer({
  open,
  onClose,
  events,
  runtimeConfig,
  vaultedCustomer,
  checkoutMode,
  onSwitchCheckoutMode,
  onAuthChanged,
  onApplyVaultTarget,
}: PixelTelemetryDrawerProps) {
  const [activeTab, setActiveTab] = useState<PortalTab>('leads')
  const [passcode, setPasscode] = useState('')
  const [loggingIn, setLoggingIn] = useState(false)
  const [loginError, setLoginError] = useState<string | null>(null)

  const [leads, setLeads] = useState<PortalLeadItem[]>([])
  const [leadEvents, setLeadEvents] = useState<PortalLeadEventItem[]>([])
  const [peopleLeads, setPeopleLeads] = useState<PortalPersonLeadItem[]>([])
  const [leadsScopeLimited, setLeadsScopeLimited] = useState(false)
  const [vaultTargets, setVaultTargets] = useState<PortalVaultItem[]>([])
  const [loadingData, setLoadingData] = useState(false)
  const [dataError, setDataError] = useState<string | null>(null)
  const [copiedId, setCopiedId] = useState<string | null>(null)

  const adminAuthenticated = Boolean(runtimeConfig?.adminAuthenticated)
  const sandboxConfigured = Boolean(runtimeConfig?.sandboxConfigured)
  const activeEnvironment = runtimeConfig?.environment ?? 'production'

  const fetchPortalRecords = useCallback(async () => {
    if (!adminAuthenticated) return
    setLoadingData(true)
    setDataError(null)
    try {
      const [leadsRes, setupRes] = await Promise.all([
        fetch(`/api/leads?mode=${activeEnvironment}`),
        fetch(`/api/setup-intents?mode=${activeEnvironment}`),
      ])

      if (leadsRes.ok) {
        const lData = (await leadsRes.json()) as {
          leads?: PortalLeadItem[]
          leadEvents?: PortalLeadEventItem[]
          peopleLeads?: PortalPersonLeadItem[]
          leadsScopeLimited?: boolean
        }
        setLeads(Array.isArray(lData.leads) ? lData.leads : [])
        setLeadEvents(Array.isArray(lData.leadEvents) ? lData.leadEvents : [])
        setPeopleLeads(Array.isArray(lData.peopleLeads) ? lData.peopleLeads : [])
        setLeadsScopeLimited(Boolean(lData.leadsScopeLimited))
      } else {
        const err = (await leadsRes.json().catch(() => null)) as { message?: string } | null
        if (err?.message) setDataError(err.message)
      }

      if (setupRes.ok) {
        const sData = (await setupRes.json()) as {
          setupIntents?: Array<{
            id: string
            status: string
            created_at?: string
            member_id: string | null
            payment_method_id: string | null
            payment_instrument?: { display_name?: string | null } | null
            user?: { email?: string | null; name?: string | null } | null
          }>
          vaultedPayments?: Array<{
            id: string
            status: string
            created_at?: string
            member_id: string | null
            payment_method_id: string | null
            customer_email?: string | null
            payment_instrument?: { display_name?: string | null } | null
            user?: { email?: string | null; name?: string | null } | null
          }>
        }

        const merged: PortalVaultItem[] = []
        for (const s of sData.setupIntents ?? []) {
          if (s.member_id && s.payment_method_id) {
            merged.push({
              id: s.id,
              kind: 'setup_intent',
              status: s.status,
              memberId: s.member_id,
              paymentMethodId: s.payment_method_id,
              email: s.user?.email ?? '',
              name: s.user?.name ?? '',
              cardLabel: s.payment_instrument?.display_name ?? 'Saved Card',
              createdAt: s.created_at ?? '',
            })
          }
        }
        for (const p of sData.vaultedPayments ?? []) {
          if (p.member_id && p.payment_method_id) {
            merged.push({
              id: p.id,
              kind: 'payment',
              status: p.status,
              memberId: p.member_id,
              paymentMethodId: p.payment_method_id,
              email: p.customer_email ?? p.user?.email ?? '',
              name: p.user?.name ?? '',
              cardLabel: p.payment_instrument?.display_name ?? 'Deposit Card',
              createdAt: p.created_at ?? '',
            })
          }
        }
        setVaultTargets(merged)
      }
    } catch (err) {
      setDataError(err instanceof Error ? err.message : 'Unable to sync portal records.')
    } finally {
      setLoadingData(false)
    }
  }, [adminAuthenticated, activeEnvironment])

  useEffect(() => {
    if (open && adminAuthenticated) {
      void fetchPortalRecords()
    }
  }, [open, adminAuthenticated, fetchPortalRecords])

  if (!open) return null

  const copyText = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedId(id)
      setTimeout(() => setCopiedId(null), 1500)
    } catch {
      // Ignore clipboard denials gracefully
    }
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoginError(null)
    setLoggingIn(true)
    try {
      const res = await fetch('/api/admin/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ passcode: passcode.trim() }),
      })
      const data = (await res.json()) as { ok?: boolean; message?: string }
      if (!res.ok || !data.ok) {
        throw new Error(data.message || 'Authentication failed.')
      }
      setPasscode('')
      await onAuthChanged(true)
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : 'Invalid contractor passcode.')
    } finally {
      setLoggingIn(false)
    }
  }

  const handleLogout = async () => {
    await fetch('/api/admin/auth', { method: 'DELETE' }).catch(() => null)
    setLeads([])
    setLeadEvents([])
    setPeopleLeads([])
    setLeadsScopeLimited(false)
    setVaultTargets([])
    await onAuthChanged(false)
  }

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/55 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-label="Contractor Operations Portal"
    >
      <div className="flex h-full w-full max-w-xl flex-col border-l border-[var(--roof-border)] bg-[var(--roof-canvas)] shadow-2xl">
        {/* Drawer header */}
        <div className="flex items-center justify-between border-b border-white/10 bg-[var(--roof-obsidian)] px-5 py-4 text-white">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[var(--roof-copper)] to-[var(--roof-amber)] text-white shadow-md">
              {adminAuthenticated ? (
                <Unlock className="h-4 w-4" />
              ) : (
                <Lock className="h-4 w-4" />
              )}
            </span>
            <div>
              <h2 className="font-display text-base font-bold text-white">
                Contractor Operations Portal
              </h2>
              <p className="text-xs text-white/65">
                {adminAuthenticated
                  ? `Authenticated · ${activeEnvironment === 'sandbox' ? 'Whop Sandbox Mode' : 'Live Production Mode'}`
                  : 'Protected CRM Leads, Closing Invoices & Test Card Mode'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {adminAuthenticated && (
              <button
                type="button"
                onClick={handleLogout}
                title="Sign out of Contractor Portal"
                className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-white/15 bg-white/8 px-2.5 text-xs font-semibold text-white/85 hover:bg-white/15"
              >
                <LogOut className="h-3.5 w-3.5 text-[var(--roof-copper-light)]" />
                <span className="hidden sm:inline">Lock</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close contractor portal"
              className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-white/15 bg-white/8 text-white transition-colors hover:bg-white/15"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* LOCKED VIEW: Passcode Login */}
        {!adminAuthenticated ? (
          <div className="flex flex-1 flex-col justify-center p-6 sm:p-8">
            <div className="rounded-3xl border border-[var(--roof-border)] bg-white p-6 shadow-md sm:p-7">
              <div className="inline-flex items-center gap-2 rounded-full bg-[var(--roof-copper)]/10 px-3 py-1 text-xs font-bold text-[var(--roof-copper-deep)] uppercase">
                <ShieldCheck className="h-3.5 w-3.5" />
                <span>Restricted Access</span>
              </div>
              <h3 className="font-display mt-3 text-xl font-extrabold text-[var(--roof-ink)]">
                Enter Contractor Portal Passcode
              </h3>
              <p className="mt-2 text-xs leading-relaxed text-[#4B5563]">
                Homeowner leads, phone/email PII, vaulted payment method IDs, closing invoices,
                conversion pixel logs, and Sandbox test-card controls are encrypted behind server
                authentication.
              </p>

              <form onSubmit={handleLogin} className="mt-5 space-y-4">
                <div>
                  <label
                    htmlFor="portal-passcode"
                    className="block text-xs font-bold text-[#141A21]"
                  >
                    Portal Passcode
                  </label>
                  <input
                    id="portal-passcode"
                    type="password"
                    required
                    autoComplete="current-password"
                    placeholder="Enter contractor passcode"
                    value={passcode}
                    onChange={(e) => setPasscode(e.target.value)}
                    className="font-mono-num mt-1.5 min-h-11 w-full rounded-xl border border-[#D8D1C4] bg-[var(--roof-canvas)] px-3.5 text-sm text-[var(--roof-ink)] focus:border-[var(--roof-copper)]"
                  />
                </div>

                {loginError && (
                  <div
                    role="alert"
                    className="flex items-start gap-2 rounded-xl border border-red-300 bg-red-50 px-3.5 py-2.5 text-xs text-red-900"
                  >
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
                    <span>{loginError}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loggingIn || !passcode.trim()}
                  className="btn-shimmer inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[var(--roof-copper)] to-[var(--roof-amber)] px-5 py-2.5 text-sm font-bold text-white shadow-md disabled:opacity-55"
                >
                  {loggingIn ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>Verifying Session…</span>
                    </>
                  ) : (
                    <>
                      <KeyRound className="h-4 w-4" />
                      <span>Unlock Contractor Portal</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        ) : (
          <>
            {/* Mode Banner + Tab Bar */}
            <div className="border-b border-[#E2DACB] bg-white px-5 py-3">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3">
                <div className="flex items-center gap-2 text-xs">
                  <span
                    className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 font-bold ${
                      activeEnvironment === 'sandbox'
                        ? 'bg-amber-100 text-amber-900'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    <span
                      className={`h-2 w-2 rounded-full ${
                        activeEnvironment === 'sandbox' ? 'bg-amber-500' : 'bg-emerald-500'
                      }`}
                    />
                    {activeEnvironment === 'sandbox' ? 'Sandbox Test Mode' : 'Production Live'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {sandboxConfigured && (
                    <button
                      type="button"
                      onClick={() =>
                        onSwitchCheckoutMode(
                          checkoutMode === 'sandbox' ? 'production' : 'sandbox',
                        )
                      }
                      className="inline-flex min-h-8 items-center gap-1 rounded-lg border border-[#D8D1C4] bg-[#FAF8F3] px-2.5 text-[11px] font-bold text-[#111827] hover:border-[#E05A2B]"
                    >
                      <TestTube2 className="h-3 w-3 text-[#E05A2B]" />
                      <span>
                        {checkoutMode === 'sandbox' ? 'Switch to Prod' : 'Switch to Sandbox'}
                      </span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={fetchPortalRecords}
                    disabled={loadingData}
                    className="inline-flex min-h-8 items-center gap-1 rounded-lg border border-[#D8D1C4] bg-white px-2.5 text-[11px] font-bold text-[#111827] hover:border-[#111827]"
                  >
                    <RefreshCw
                      className={`h-3 w-3 text-[#E05A2B] ${loadingData ? 'animate-spin' : ''}`}
                    />
                    <span>Sync</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-1.5" role="tablist">
                {(
                  [
                    { id: 'leads', label: 'Leads', icon: ClipboardList },
                    { id: 'vault', label: 'Vault/Inv', icon: ReceiptText },
                    { id: 'pixel', label: 'Pixel', icon: Activity },
                    { id: 'sandbox', label: 'Card 4242', icon: TestTube2 },
                  ] as const
                ).map((t) => {
                  const Icon = t.icon
                  const active = activeTab === t.id
                  return (
                    <button
                      key={t.id}
                      type="button"
                      role="tab"
                      aria-selected={active}
                      onClick={() => setActiveTab(t.id)}
                      className={`inline-flex min-h-9 items-center justify-center gap-1 rounded-xl px-2 text-xs font-bold transition-colors ${
                        active
                          ? 'bg-[#111827] text-white'
                          : 'bg-[#FAF8F3] text-[#4B5563] hover:bg-[#EDE9DF] hover:text-[#111827]'
                      }`}
                    >
                      <Icon className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate">{t.label}</span>
                    </button>
                  )
                })}
              </div>
            </div>

            {/* UNLOCKED SCROLLABLE CONTENT */}
            <div className="flex-1 space-y-4 overflow-y-auto p-5">
              {dataError && (
                <div className="flex items-start gap-2 rounded-xl border border-red-300 bg-red-50 p-3 text-xs text-red-900">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
                  <span>{dataError}</span>
                </div>
              )}

              {/* TAB 1: LEADS CRM */}
              {activeTab === 'leads' && (
                <div className="space-y-4">
                  <div className="rounded-2xl border border-[#E2DACB] bg-white p-3.5 text-xs leading-relaxed text-[#4B5563]">
                    <div className="font-bold text-[#111827]">
                      Where Free Estimate Submissions Go on Whop
                    </div>
                    <p className="mt-1">
                      Every quote request fires <code className="font-mono-num">estimate_requested</code>{' '}
                      and writes a <code className="font-mono-num">lead</code> event +{' '}
                      <strong>Person CRM profile</strong> in Whop. Requests matching a Whop user
                      account also create a full <code className="font-mono-num">lead_...</code>{' '}
                      record in <strong>Whop Leads CRM</strong>.
                    </p>
                  </div>

                  {leadsScopeLimited && (
                    <div className="rounded-xl border border-amber-300 bg-amber-50 p-3 text-xs text-amber-950">
                      Sandbox API key does not include <code className="font-mono-num">lead:basic:read</code>{' '}
                      for <code className="font-mono-num">/leads</code>. Showing Events/People
                      estimate captures below; switch to <strong>Production Live</strong> to list
                      full <code className="font-mono-num">lead_...</code> records.
                    </div>
                  )}

                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between text-xs font-bold text-[#4B5563] uppercase">
                      <span>Whop CRM Leads ({leads.length})</span>
                      <span>{activeEnvironment}</span>
                    </div>

                    {leads.length === 0 ? (
                      <div className="rounded-2xl border border-dashed border-[#D8D1C4] bg-white p-4 text-xs text-[#4B5563]">
                        No <code className="font-mono-num">lead_...</code> records synced yet in{' '}
                        {activeEnvironment} mode. Submit the Estimate Form and click{' '}
                        <strong>Sync</strong>.
                      </div>
                    ) : (
                      leads.map((lead) => {
                        const meta = lead.metadata ?? {}
                        return (
                          <div
                            key={lead.id}
                            className="rounded-2xl border border-[#D8D1C4] bg-white p-4 text-xs shadow-2xs"
                          >
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-mono-num font-bold text-[#111827]">
                                {lead.id}
                              </span>
                              <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800 uppercase">
                                {meta.service_interest || lead.product?.title || 'Estimate'}
                              </span>
                            </div>
                            <div className="mt-2 font-semibold text-[#111827]">
                              {meta.homeowner_name || lead.user?.name || 'Homeowner'}
                            </div>
                            <div className="mt-0.5 text-[#4B5563]">
                              {meta.homeowner_email || lead.user?.email || 'No email'} ·{' '}
                              {meta.homeowner_phone || 'No phone'}
                            </div>
                            {(meta.property_address || meta.zip_code) && (
                              <div className="mt-1 text-[#6B7280]">
                                {meta.property_address || ''} ({meta.zip_code || ''})
                              </div>
                            )}
                          </div>
                        )
                      })
                    )}
                  </div>

                  {/* Guest & Website Estimate Events + People CRM */}
                  <div className="space-y-2.5 border-t border-[#E2DACB] pt-3">
                    <div className="flex items-center justify-between text-xs font-bold text-[#4B5563] uppercase">
                      <span>
                        All Website Quote Requests — Events & People ({leadEvents.length || peopleLeads.length})
                      </span>
                      <span>evnt / prsn</span>
                    </div>

                    {leadEvents.length > 0 ? (
                      leadEvents.slice(0, 12).map((ev) => (
                        <div
                          key={ev.id}
                          className="rounded-2xl border border-[#D8D1C4] bg-white p-3.5 text-xs shadow-2xs"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-mono-num font-bold text-[#B83D14]">
                              {ev.event_id || ev.id}
                            </span>
                            <span className="rounded-full bg-orange-100 px-2 py-0.5 text-[10px] font-bold text-[#B83D14] uppercase">
                              {ev.related?.product?.title || ev.custom_name || ev.event_name}
                            </span>
                          </div>
                          <div className="mt-1.5 font-semibold text-[#111827]">
                            {ev.user?.name || ev.related?.user?.name || 'Website Visitor'}
                          </div>
                          <div className="mt-0.5 text-[#4B5563]">
                            {ev.user?.email || 'No email'}
                            {ev.user?.phone ? ` · ${ev.user.phone}` : ''}
                            {ev.user?.city ? ` · ${ev.user.city}` : ''}
                          </div>
                          <div className="font-mono-num mt-1 text-[10px] text-[#6B7280]">
                            {new Date(ev.event_time).toLocaleString()}
                          </div>
                        </div>
                      ))
                    ) : peopleLeads.length > 0 ? (
                      peopleLeads.slice(0, 12).map((person) => (
                        <div
                          key={person.id}
                          className="rounded-2xl border border-[#D8D1C4] bg-white p-3.5 text-xs shadow-2xs"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-mono-num font-bold text-[#111827]">
                              {person.id}
                            </span>
                            <span className="rounded-full bg-sky-100 px-2 py-0.5 text-[10px] font-bold text-sky-800 uppercase">
                              {person.event_count ?? 1} events
                            </span>
                          </div>
                          <div className="mt-1.5 font-semibold text-[#111827]">
                            {person.name || person.user?.name || 'Homeowner'}
                          </div>
                          <div className="mt-0.5 text-[#4B5563]">
                            {person.email || 'No email'}
                            {person.phone ? ` · ${person.phone}` : ''}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="rounded-2xl border border-dashed border-[#D8D1C4] bg-white p-4 text-xs text-[#6B7280]">
                        No guest <code className="font-mono-num">lead</code> events synced yet in
                        this environment.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 2: VAULTED CARDS & QUICK JUMP TO FINAL INVOICING */}
              {activeTab === 'vault' && (
                <div className="space-y-4">
                  <div className="rounded-2xl border border-[#E2DACB] bg-white p-4 text-xs">
                    <div className="font-bold text-[#111827]">
                      Vaulted Customers Ready for Auto-Charge Final Invoice
                    </div>
                    <p className="mt-1 text-[#4B5563]">
                      Click <strong>Load in Invoice Studio</strong> on any customer who completed a
                      ${roofingTemplate.plans.deposit.priceUsd} Deposit or $0 Card Setup to
                      auto-fill Step 3 below.
                    </p>
                  </div>

                  {vaultTargets.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-[#D8D1C4] bg-white p-5 text-xs text-[#4B5563]">
                      No vaulted payment methods found yet in {activeEnvironment} mode. Complete a
                      Deposit or Card Setup to generate a saved <code className="font-mono-num">mber_</code>{' '}
                      + <code className="font-mono-num">payt_</code> pair.
                    </div>
                  ) : (
                    vaultTargets.map((item) => (
                      <div
                        key={item.id}
                        className="rounded-2xl border border-[#D8D1C4] bg-white p-4 text-xs shadow-2xs"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="inline-flex items-center gap-1.5 font-bold text-[#111827]">
                            <CreditCard className="h-3.5 w-3.5 text-[#E05A2B]" />
                            {item.cardLabel}
                          </span>
                          <span className="font-mono-num rounded bg-emerald-100 px-2 py-0.5 text-[10px] font-bold text-emerald-800 uppercase">
                            {item.status}
                          </span>
                        </div>
                        <div className="mt-1.5 text-[#374151]">
                          {item.name || 'Customer'} · {item.email || 'No email'}
                        </div>
                        <div className="font-mono-num mt-2 grid gap-1 text-[11px] text-[#6B7280]">
                          <div>Member: {item.memberId}</div>
                          <div>Method: {item.paymentMethodId}</div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            onApplyVaultTarget({
                              memberId: item.memberId,
                              paymentMethodId: item.paymentMethodId,
                              email: item.email,
                              customerName: item.name,
                              sourceId: item.id,
                              sourceType: item.kind,
                              cardSaved: true,
                              cardSummary: item.cardLabel,
                              capturedAtIso: item.createdAt || new Date().toISOString(),
                            })
                            onClose()
                            document
                              .getElementById('invoice-flow')
                              ?.scrollIntoView({ behavior: 'smooth' })
                          }}
                          className="mt-3 inline-flex min-h-9 w-full items-center justify-center gap-1.5 rounded-xl bg-[#111827] px-3 py-1.5 text-xs font-bold text-white hover:bg-[#E05A2B]"
                        >
                          <ReceiptText className="h-3.5 w-3.5" />
                          <span>Load in Step 3 Final Invoice Studio</span>
                        </button>
                      </div>
                    ))
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      onClose()
                      document
                        .getElementById('invoice-flow')
                        ?.scrollIntoView({ behavior: 'smooth' })
                    }}
                    className="inline-flex min-h-10 w-full items-center justify-center rounded-xl border border-[#D8D1C4] bg-white px-4 text-xs font-bold text-[#111827] hover:border-[#E05A2B]"
                  >
                    Open Full Invoice Composer on Page →
                  </button>
                </div>
              )}

              {/* TAB 3: PIXEL TELEMETRY & DIAGNOSTICS */}
              {activeTab === 'pixel' && (
                <div className="space-y-4">
                  {/* Connection Snapshot */}
                  <div className="rounded-2xl border border-white/10 bg-[#0B1016] p-4 text-xs text-white shadow-lg">
                    <div className="font-semibold text-[#FF9E6D]">Whop Server Diagnostics</div>
                    <dl className="font-mono-num mt-2 grid grid-cols-2 gap-2">
                      <div className="rounded bg-white/8 p-2">
                        <dt className="text-white/60">Auth Mode</dt>
                        <dd className="mt-0.5 font-semibold">
                          {runtimeConfig?.adminDiagnostics?.authMode ?? 'configured'}
                        </dd>
                      </div>
                      <div className="rounded bg-white/8 p-2">
                        <dt className="text-white/60">Environment</dt>
                        <dd className="mt-0.5 font-semibold">{activeEnvironment}</dd>
                      </div>
                      <div className="rounded bg-white/8 p-2">
                        <dt className="text-white/60">Account ID</dt>
                        <dd className="mt-0.5 truncate font-semibold">
                          {runtimeConfig?.adminDiagnostics?.accountId || 'Unset'}
                        </dd>
                      </div>
                      <div className="rounded bg-white/8 p-2">
                        <dt className="text-white/60">Vaulted Card</dt>
                        <dd className="mt-0.5 truncate font-semibold text-emerald-300">
                          {vaultedCustomer?.paymentMethodId || 'None synced'}
                        </dd>
                      </div>
                    </dl>
                  </div>

                  {/* Quick triggers */}
                  <div className="rounded-2xl border border-[#E2DACB] bg-white p-4 shadow-2xs">
                    <div className="flex items-center gap-1.5 text-xs font-bold tracking-wider text-[#B83D14] uppercase">
                      <Sparkles className="h-3.5 w-3.5 text-[#E05A2B]" />
                      <span>Fire Custom whop.track Events</span>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          trackWhopEvent('service_viewed', {
                            service_id: 'replacement',
                            service_title:
                              roofingTemplate.services[2]?.title ??
                              roofingTemplate.services[0]?.title ??
                              'Roofing Scope',
                            price_usd: roofingTemplate.services[2]?.priceNumber ?? 8400,
                            manual_trigger: true,
                          })
                        }
                        className="font-mono-num min-h-9 rounded-xl border border-sky-200 bg-sky-50 px-3 py-1.5 text-xs font-bold text-sky-800 hover:bg-sky-100"
                      >
                        + service_viewed
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          trackWhopEvent('estimate_requested', {
                            service_type: 'inspection',
                            zip_code: roofingTemplate.formPlaceholders.zip,
                            manual_trigger: true,
                          })
                        }
                        className="font-mono-num min-h-9 rounded-xl border border-[var(--roof-copper)]/25 bg-[var(--roof-copper)]/10 px-3 py-1.5 text-xs font-bold text-[var(--roof-copper-deep)] hover:bg-[var(--roof-copper)]/18"
                      >
                        + estimate_requested
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          trackWhopEvent('deposit_started', {
                            plan_key: 'deposit',
                            amount_usd: roofingTemplate.plans.deposit.priceUsd,
                            manual_trigger: true,
                          })
                        }
                        className="font-mono-num min-h-9 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-800 hover:bg-emerald-100"
                      >
                        + deposit_started
                      </button>
                    </div>
                  </div>

                  {/* Event Stream */}
                  <div>
                    <div className="flex items-center justify-between text-xs font-bold tracking-wider text-[#4B5563] uppercase">
                      <span>Dispatched Events ({events.length})</span>
                      <span>whop.track</span>
                    </div>
                    {events.length === 0 ? (
                      <div className="mt-2 rounded-xl border border-dashed border-[#D8D1C4] bg-white p-4 text-xs text-[#4B5563]">
                        No custom events fired yet in this session.
                      </div>
                    ) : (
                      <div className="mt-2 space-y-2.5">
                        {events.map((evt) => (
                          <div
                            key={evt.id}
                            className="rounded-xl border border-[#D8D1C4] bg-white p-3.5 text-xs shadow-2xs"
                          >
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-mono-num rounded bg-[#C2491D]/12 px-2 py-0.5 font-bold text-[#9E3712]">
                                whop.track(&apos;{evt.eventName}&apos;)
                              </span>
                              <div className="flex items-center gap-2">
                                <span
                                  className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${
                                    evt.deliveredToWhopPixel
                                      ? 'bg-[#2F5241]/15 text-[#2F5241]'
                                      : 'bg-[#EDE9DF] text-[#4B5563]'
                                  }`}
                                >
                                  {evt.deliveredToWhopPixel ? 'Pixel OK' : 'Trace OK'}
                                </span>
                                <button
                                  type="button"
                                  onClick={() =>
                                    copyText(evt.id, JSON.stringify(evt, null, 2))
                                  }
                                  className="inline-flex h-7 w-7 items-center justify-center rounded border border-[#E5DFD3] text-[#4B5563] hover:text-[#141A21]"
                                  title="Copy JSON payload"
                                >
                                  {copiedId === evt.id ? (
                                    <Check className="h-3.5 w-3.5 text-[#2F5241]" />
                                  ) : (
                                    <Copy className="h-3.5 w-3.5" />
                                  )}
                                </button>
                              </div>
                            </div>
                            <pre className="font-mono-num mt-2 overflow-x-auto rounded-lg bg-[#F6F4EF] p-2.5 text-[11px] text-[#1F2933]">
                              {JSON.stringify(evt.payload, null, 2)}
                            </pre>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: SANDBOX TEST CARD (4242 4242 4242 4242) */}
              {activeTab === 'sandbox' && (
                <div className="space-y-4 text-xs">
                  <div
                    className={`rounded-2xl border p-4 ${
                      sandboxConfigured
                        ? 'border-emerald-300 bg-emerald-50 text-emerald-950'
                        : 'border-amber-300 bg-amber-50 text-amber-950'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 font-bold">
                      <span>
                        {sandboxConfigured
                          ? 'Whop Sandbox Environment Ready'
                          : 'Sandbox Test Mode Not Linked Yet'}
                      </span>
                      <span className="font-mono-num rounded bg-white px-2 py-0.5 text-[11px]">
                        {sandboxConfigured ? 'CONFIGURED' : 'PROD ONLY'}
                      </span>
                    </div>
                    <p className="mt-1.5 leading-relaxed">
                      {sandboxConfigured
                        ? 'You can safely switch the live checkout form to Sandbox Mode right here, test deposits with 4242 4242 4242 4242, vault a test card, and run Final Balance Auto-Charge.'
                        : 'Whop never accepts test card numbers against Production keys. To test Visa 4242 without charging real money, provision your free Sandbox API key from sandbox.whop.com.'}
                    </p>

                    {sandboxConfigured && (
                      <button
                        type="button"
                        onClick={() =>
                          onSwitchCheckoutMode(
                            checkoutMode === 'sandbox' ? 'production' : 'sandbox',
                          )
                        }
                        className="mt-3 inline-flex min-h-9 items-center gap-1.5 rounded-xl bg-[#111827] px-4 py-2 text-xs font-bold text-white hover:bg-[#E05A2B]"
                      >
                        <TestTube2 className="h-3.5 w-3.5 text-[#FBBF24]" />
                        <span>
                          {checkoutMode === 'sandbox'
                            ? 'Return Checkout to Production'
                            : 'Activate Sandbox Checkout Mode'}
                        </span>
                      </button>
                    )}
                  </div>

                  {/* Official Test Card Numbers */}
                  <div className="rounded-2xl border border-[#D8D1C4] bg-white p-4">
                    <div className="font-bold text-[#111827]">
                      Official Whop Sandbox Test Cards
                    </div>
                    <div className="mt-3 space-y-2.5">
                      <div className="flex items-center justify-between rounded-xl border border-[#E5DFD3] bg-[#FAF8F3] p-3">
                        <div>
                          <div className="font-semibold text-[#111827]">
                            Instant Success Card (Visa)
                          </div>
                          <div className="font-mono-num mt-0.5 text-[#B83D14]">
                            4242 4242 4242 4242 · Exp 12/30 · CVC 123
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => copyText('card1', '4242424242424242')}
                          className="inline-flex h-8 items-center gap-1 rounded-lg border border-[#D8D1C4] bg-white px-2.5 font-semibold text-[#111827]"
                        >
                          {copiedId === 'card1' ? (
                            <Check className="h-3.5 w-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="h-3.5 w-3.5" />
                          )}
                          <span>Copy</span>
                        </button>
                      </div>

                      <div className="flex items-center justify-between rounded-xl border border-[#E5DFD3] bg-[#FAF8F3] p-3">
                        <div>
                          <div className="font-semibold text-[#111827]">
                            3D Secure Verification Card
                          </div>
                          <div className="font-mono-num mt-0.5 text-[#374151]">
                            5385 3083 6013 5181 · OTP: Checkout1!
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => copyText('card2', '5385308360135181')}
                          className="inline-flex h-8 items-center gap-1 rounded-lg border border-[#D8D1C4] bg-white px-2.5 font-semibold text-[#111827]"
                        >
                          {copiedId === 'card2' ? (
                            <Check className="h-3.5 w-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="h-3.5 w-3.5" />
                          )}
                          <span>Copy</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* CLI Helper Instructions */}
                  <div className="rounded-2xl border border-[#D8D1C4] bg-[#0B1016] p-4 text-white/85">
                    <div className="font-bold text-[#FBBF24]">
                      1-Command Sandbox Setup (Local CLI)
                    </div>
                    <ol className="mt-2 list-decimal space-y-1.5 pl-4 text-[11px] leading-relaxed">
                      <li>
                        Sign in at{' '}
                        <span className="font-mono-num text-emerald-300">
                          sandbox.whop.com/dashboard/developer
                        </span>{' '}
                        and create a Sandbox Company API key (<code className="font-mono-num">apik_...</code>) + copy its{' '}
                        <code className="font-mono-num">biz_...</code> ID.
                      </li>
                      <li>
                        Run:{' '}
                        <code className="font-mono-num block rounded bg-white/10 p-2 text-amber-200">
                          node scripts/setup-sandbox.mjs --key &lt;apik_...&gt; --account &lt;biz_...&gt;
                        </code>
                      </li>
                      <li>Deploy with <code className="font-mono-num">npx whop apps deploy</code> and toggle Sandbox above.</li>
                    </ol>
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
