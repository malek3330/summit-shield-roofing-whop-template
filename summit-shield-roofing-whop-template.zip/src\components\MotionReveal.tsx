import type { ReactNode } from 'react'

interface MotionRevealProps {
  children: ReactNode
  className?: string
  delayMs?: number
  immediate?: boolean
}

/**
 * Always-visible section wrapper so below-the-fold sections render immediately
 * without blank gaps during fast scroll, anchor navigation, or full-page capture.
 */
export function MotionReveal({ children, className = '' }: MotionRevealProps) {
  return <div className={className}>{children}</div>
}
