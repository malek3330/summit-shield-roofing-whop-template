export type CustomWhopEventName =
  | 'service_viewed'
  | 'estimate_requested'
  | 'deposit_started'
  | 'view_content'
  | 'initiate_checkout'
  | 'lead'

export interface PixelEventRecord {
  id: string
  eventName: CustomWhopEventName
  timestampIso: string
  deliveredToWhopPixel: boolean
  payload: Record<string, string | number | boolean | null | undefined>
}

declare global {
  interface Window {
    whop?: {
      track?: (
        event: string,
        properties?: Record<string, string | number | boolean | null | undefined>,
      ) => void
      visitorId?: string
    }
    __whopPixelEvents?: PixelEventRecord[]
  }
}

type PixelListener = (events: PixelEventRecord[]) => void

const listeners = new Set<PixelListener>()
const eventHistory: PixelEventRecord[] = []

function notifyListeners() {
  const snapshot = [...eventHistory]
  for (const listener of listeners) {
    listener(snapshot)
  }
}

export function subscribeWhopPixelEvents(listener: PixelListener): () => void {
  listeners.add(listener)
  listener([...eventHistory])
  return () => {
    listeners.delete(listener)
  }
}

export function getWhopPixelHistory(): PixelEventRecord[] {
  return [...eventHistory]
}

export function getWhopVisitorId(): string | null {
  if (typeof window === 'undefined') return null
  return window.whop?.visitorId ?? null
}

/**
 * Fires events to Whop's auto-injected whop.site pixel (`window.whop.track`),
 * preserving caller-provided `event_id` when present for Whop deduplication.
 */
export function trackWhopEvent(
  eventName: CustomWhopEventName,
  properties: Record<string, string | number | boolean | null | undefined> = {},
): PixelEventRecord {
  const callerEventId =
    typeof properties.event_id === 'string' && properties.event_id.trim()
      ? properties.event_id.trim()
      : null
  const eventId =
    callerEventId ??
    `evt_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`
  const enrichedPayload = {
    currency: 'USD',
    ...properties,
    event_id: eventId,
  }

  let deliveredToWhopPixel = false

  if (typeof window !== 'undefined') {
    if (typeof window.whop?.track === 'function') {
      try {
        window.whop.track(eventName, enrichedPayload)
        deliveredToWhopPixel = true
      } catch (err) {
        console.warn('[whop.track] dispatch warning:', err)
      }
    }
    window.__whopPixelEvents = window.__whopPixelEvents ?? []
  }

  const record: PixelEventRecord = {
    id: `${eventName}_${eventId}_${Date.now()}`,
    eventName,
    timestampIso: new Date().toISOString(),
    deliveredToWhopPixel,
    payload: enrichedPayload,
  }

  eventHistory.unshift(record)
  if (eventHistory.length > 50) {
    eventHistory.length = 50
  }

  if (typeof window !== 'undefined') {
    window.__whopPixelEvents = [...eventHistory]
    window.dispatchEvent(new CustomEvent('summit:whop-track', { detail: record }))
    console.info(`[whop.track] ${eventName}`, enrichedPayload)
  }

  notifyListeners()
  return record
}
