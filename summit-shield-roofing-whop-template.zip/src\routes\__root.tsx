import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'
import { roofingTemplate } from '#/config/roofingTemplate'
import appCss from '../styles.css?url'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      {
        charSet: 'utf-8',
      },
      {
        name: 'viewport',
        content: 'width=device-width, initial-scale=1',
      },
      {
        title: `${roofingTemplate.brand.name} — ${roofingTemplate.serviceArea.regionLabel} Roofing & Instant Estimates`,
      },
      {
        name: 'description',
        content: `${roofingTemplate.brand.name}: Storm-rated roof replacements, $${roofingTemplate.plans.inspection.priceUsd} drone inspections, $${roofingTemplate.plans.deposit.priceUsd} project deposits, and seamless final-balance invoicing powered by Whop Payments.`,
      },
      {
        name: 'theme-color',
        content: roofingTemplate.theme.inkHex,
      },
    ],
    links: [
      {
        rel: 'icon',
        type: 'image/svg+xml',
        href: '/favicon.svg',
      },
      {
        rel: 'preconnect',
        href: 'https://fonts.googleapis.com',
      },
      {
        rel: 'preconnect',
        href: 'https://fonts.gstatic.com',
        crossOrigin: 'anonymous',
      },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400..700&family=Outfit:wght@500;600;700;800&family=Plus+Jakarta+Sans:wght@400..700&display=swap',
      },
      {
        rel: 'stylesheet',
        href: appCss,
      },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  const { theme } = roofingTemplate
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body
        style={
          {
            '--roof-canvas': theme.canvasHex,
            '--roof-surface': theme.surfaceHex,
            '--roof-border': theme.borderHex,
            '--roof-ink': theme.inkHex,
            '--roof-obsidian': theme.obsidianHex,
            '--roof-midnight': theme.midnightHex,
            '--roof-copper': theme.accentHex,
            '--roof-copper-deep': theme.accentDeepHex,
            '--roof-amber': theme.secondaryAccentHex,
            '--roof-forest': theme.forestHex,
          } as React.CSSProperties
        }
        className="min-h-screen bg-[var(--roof-canvas)] text-[var(--roof-ink)] antialiased selection:bg-[var(--roof-copper)] selection:text-white"
      >
        {children}
        <Scripts />
      </body>
    </html>
  )
}
