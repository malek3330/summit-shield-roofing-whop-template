#!/usr/bin/env node
/**
 * 1-Command Whop Sandbox Provisioning Script for the Roofing Whop Website Template
 *
 * Usage:
 *   node scripts/setup-sandbox.mjs --key <apik_sandbox_key> [--account <biz_sandbox_id>]
 *
 * What it does:
 * 1. Connects to Whop Sandbox API (`WhopEnvironment.Sandbox`) using your Sandbox Company API key.
 * 2. Auto-detects the Sandbox business account (`biz_...`) even when `company:balance:read` is omitted.
 * 3. Creates or reuses the 3 roofing USD one-time plans ($149 / $500 / $299) — attaches to Products if
 *    `access_pass:create` is granted, or creates standalone buyable Variants cleanly if not.
 * 4. Uploads encrypted secrets (`WHOP_SANDBOX_API_KEY`, `WHOP_SANDBOX_ACCOUNT_ID`,
 *    `WHOP_SANDBOX_PLAN_*`, plus `WHOP_SANDBOX_PRODUCT_*` when created) to Whop app secrets.
 */
import { execFileSync } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import path from 'node:path'
import { WhopClient, WhopEnvironment } from '@whop/sdk'

const ROOFING_SANDBOX_CATALOG = [
  {
    key: 'INSPECTION',
    title: '19-Point Drone & Attic Roof Inspection',
    variantTitle: 'Roof Inspection ($149)',
    priceUsd: 149,
    description:
      'Includes thermal attic check, aerial hail map, flashing audit, and itemized repair/replacement quote.',
  },
  {
    key: 'DEPOSIT',
    title: 'Project Scheduling & Material Deposit',
    variantTitle: 'Project Deposit ($500)',
    priceUsd: 500,
    description:
      'Secures crew dispatch date, color-matched shingle order, and saves payment method for job closeout.',
  },
  {
    key: 'TUNEUP',
    title: 'Flat-Rate Roof & Flashing Preventative Tune-Up',
    variantTitle: 'Flat-Rate Tune-Up ($299)',
    priceUsd: 299,
    description:
      'Preventative sealing of pipe boots, exposed fasteners, skylight perimeters, and roof valley debris clearing.',
  },
]

function parseCliArgs(argv) {
  const args = {}
  for (let i = 0; i < argv.length; i++) {
    const token = argv[i]
    if (token === '--key' && argv[i + 1]) {
      args.key = argv[++i]
    } else if (token === '--account' && argv[i + 1]) {
      args.account = argv[++i]
    } else if (token === '--app' && argv[i + 1]) {
      args.app = argv[++i]
    } else if (token === '--dry-run') {
      args.dryRun = true
    }
  }
  return args
}

function resolveAppId(cliAppId) {
  if (cliAppId) return cliAppId
  const cfgPath = path.resolve(process.cwd(), 'whop.app.json')
  if (existsSync(cfgPath)) {
    try {
      const parsed = JSON.parse(readFileSync(cfgPath, 'utf8'))
      if (parsed?.app_id) return parsed.app_id
    } catch {
      // ignore parse fallback
    }
  }
  return null
}

async function resolveSandboxAccountId(whop, explicitAccountId, apiKey) {
  if (explicitAccountId && explicitAccountId.startsWith('biz_')) {
    return explicitAccountId
  }

  try {
    const me = await whop.accounts.me()
    if (me?.id?.startsWith('biz_')) return me.id
  } catch {
    // Some Company API keys omit `company:balance:read`
  }

  try {
    const listed = await whop.accounts.list({ first: 1 })
    const firstId = listed.data?.[0]?.id
    if (firstId?.startsWith('biz_')) return firstId
  } catch {
    // Fallback below
  }

  // Fallback: Whop `/products?first=1` includes `recommended_action` referencing `/accounts/biz_...`
  const probe = await fetch('https://sandbox-api.whop.com/api/v1/products?first=1', {
    headers: { Authorization: `Bearer ${apiKey}` },
  })
  if (probe.ok) {
    const raw = await probe.text()
    const match = raw.match(/accounts\/(biz_[A-Za-z0-9]+)/)
    if (match?.[1]) return match[1]
  }

  throw new Error(
    'Could not auto-detect your Sandbox Business ID (`biz_...`). Pass `--account biz_xxx` explicitly.',
  )
}

async function main() {
  const args = parseCliArgs(process.argv.slice(2))
  const sandboxKey = (args.key ?? process.env.WHOP_SANDBOX_API_KEY ?? '').trim()
  const appId = resolveAppId(args.app)

  if (!sandboxKey) {
    console.error('\nMissing Sandbox API Key.\n')
    console.error('Steps to obtain it:')
    console.error('  1. Open https://sandbox.whop.com/dashboard/developer')
    console.error('  2. Create a Company API Key (`apik_...`) for your Sandbox company')
    console.error('\nThen run:')
    console.error('  node scripts/setup-sandbox.mjs --key apik_xxx\n')
    process.exit(1)
  }

  console.log('\nConnecting to Whop Sandbox API...')
  const whop = new WhopClient({
    token: sandboxKey,
    environment: WhopEnvironment.Sandbox,
    apiVersionDate: '2026-10-28',
  })

  const sandboxAccount = await resolveSandboxAccountId(
    whop,
    (args.account ?? process.env.WHOP_SANDBOX_ACCOUNT_ID ?? '').trim(),
    sandboxKey,
  )
  console.log(`Verified Sandbox account: ${sandboxAccount}`)

  const existingProducts = await whop.products
    .list({ account_id: sandboxAccount, first: 50 })
    .catch(() => ({ data: [] }))
  const existingVariants = await whop.variants
    .list({ account_id: sandboxAccount, first: 50 })
    .catch(() => ({ data: [] }))

  const secretPairs = [
    `WHOP_SANDBOX_API_KEY=${sandboxKey}`,
    `WHOP_SANDBOX_ACCOUNT_ID=${sandboxAccount}`,
  ]

  let canCreateProducts = true

  for (const item of ROOFING_SANDBOX_CATALOG) {
    let product = (existingProducts.data ?? []).find(
      (p) => p.title?.trim().toLowerCase() === item.title.toLowerCase(),
    )

    if (!product && canCreateProducts) {
      try {
        product = await whop.products.create({
          account_id: sandboxAccount,
          title: item.title,
          description: item.description,
          visibility: 'visible',
        })
        console.log(`Created Sandbox product: ${product.title} -> ${product.id}`)
      } catch (err) {
        if (err?.statusCode === 403) {
          canCreateProducts = false
          console.log(
            'Note: `access_pass:create` scope not enabled on key — creating standalone Variants cleanly.',
          )
        } else {
          throw err
        }
      }
    } else if (product) {
      console.log(`Reusing Sandbox product: ${product.title} -> ${product.id}`)
    }

    let variant = (existingVariants.data ?? []).find(
      (v) =>
        (product ? v.product?.id === product.id : v.title?.trim() === item.variantTitle) &&
        Number(v.initial_price) === item.priceUsd &&
        String(v.currency).toLowerCase() === 'usd' &&
        v.billing_type === 'one_time',
    )

    if (!variant) {
      variant = await whop.variants.create({
        account_id: sandboxAccount,
        ...(product ? { product_id: product.id } : {}),
        title: item.variantTitle,
        description: item.description,
        currency: 'usd',
        billing_type: 'one_time',
        initial_price: item.priceUsd,
        adaptive_pricing_enabled: false,
        unlimited_stock: true,
        visibility: 'visible',
      })
      console.log(`Created Sandbox variant: $${item.priceUsd} (${item.variantTitle}) -> ${variant.id}`)
    } else {
      console.log(`Reusing Sandbox variant: $${item.priceUsd} (${item.variantTitle}) -> ${variant.id}`)
      if (variant.adaptive_pricing_enabled) {
        await whop.variants
          .update({ id: variant.id, adaptive_pricing_enabled: false })
          .catch(() => null)
      }
    }

    if (product?.id) {
      secretPairs.push(`WHOP_SANDBOX_PRODUCT_${item.key}=${product.id}`)
    }
    secretPairs.push(`WHOP_SANDBOX_PLAN_${item.key}=${variant.id}`)
  }

  if (args.dryRun) {
    console.log('\nDry run enabled — skipping `whop apps secrets set`. Secret keys ready:')
    console.log(secretPairs.map((pair) => `  ${pair.split('=')[0]}=<set>`).join('\n'))
    return
  }

  if (!appId) {
    console.error('\nCould not find whop.app.json `app_id`. Pass `--app app_...` explicitly.')
    process.exit(1)
  }

  const whopCliEntry = path.resolve(process.cwd(), 'node_modules/@whop/cli/dist/index.js')
  if (!existsSync(whopCliEntry)) {
    console.error(`\n@whop/cli entrypoint not found at ${whopCliEntry}. Run npm install first.`)
    process.exit(1)
  }

  const cliArgs = [whopCliEntry, 'apps', 'secrets', 'set', '--app', appId]
  for (const pair of secretPairs) {
    cliArgs.push('--secret', pair)
  }

  console.log(`\nSaving ${secretPairs.length} encrypted Sandbox secrets to Whop app ${appId}...`)
  execFileSync(process.execPath, cliArgs, { stdio: 'inherit' })

  console.log('\nSandbox setup complete!')
  console.log('Next steps:')
  console.log(`  1. Deploy the updated bundle: npx whop apps deploy --app ${appId}`)
  console.log('  2. Open Portal -> unlock with your passcode -> Card 4242 tab -> Activate Sandbox')
  console.log('  3. Test checkout with Visa 4242 4242 4242 4242 (any future exp + 123 CVC)\n')
}

main().catch((err) => {
  console.error('\nSandbox provisioning failed:', err?.message || err)
  process.exit(1)
})
