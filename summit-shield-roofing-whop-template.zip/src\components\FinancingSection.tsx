import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import { ArrowRight, Calculator, CheckCircle2, CreditCard, Sparkles } from 'lucide-react'
import { roofingTemplate } from '#/config/roofingTemplate'
import { trackWhopEvent } from '#/lib/whopPixel'
import { MotionReveal } from './MotionReveal'

interface FinancingSectionProps {
  onStartDepositCheckout?: () => void
}

const PROVIDER_ACCENTS = [
  {
    border: 'border-pink-400/25 hover:border-pink-400/60',
    iconColor: 'text-pink-300',
    badgeBg: 'bg-pink-500/20 text-pink-200 border border-pink-400/30',
  },
  {
    border: 'border-emerald-400/25 hover:border-emerald-400/60',
    iconColor: 'text-emerald-300',
    badgeBg: 'bg-emerald-500/20 text-emerald-200 border border-emerald-400/30',
  },
  {
    border: 'border-sky-400/25 hover:border-sky-400/60',
    iconColor: 'text-sky-300',
    badgeBg: 'bg-sky-500/20 text-sky-200 border border-sky-400/30',
  },
]

const DEFAULT_SCOPE_PRESETS = [
  { label: '$5,500 Storm Repair', value: 5500 },
  { label: '$11,800 Shingle Roof', value: 11800 },
  { label: '$19,500 Standing Seam', value: 19500 },
]

export function FinancingSection({ onStartDepositCheckout }: FinancingSectionProps) {
  const { financing } = roofingTemplate
  const scopePresets = financing.calculatorPresets ?? DEFAULT_SCOPE_PRESETS
  const [projectTotal, setProjectTotal] = useState(financing.calculatorSampleTotal)
  const [selectedTerm, setSelectedTerm] = useState<12 | 24 | 36>(24)

  const depositToday = roofingTemplate.plans.deposit.priceUsd
  const netBalanceAfterDeposit = Math.max(0, projectTotal - depositToday)
  const monthly12Est = Math.round(netBalanceAfterDeposit / 12)
  const monthly24Est = Math.round(netBalanceAfterDeposit / 24)
  const monthly36Est = Math.round(netBalanceAfterDeposit / 36)
  const sliderProgress = Math.round(((projectTotal - 2500) / (28000 - 2500)) * 100)

  const splitHeadlineIdx = financing.headline.indexOf('. ')
  const headlineLead =
    splitHeadlineIdx !== -1 ? financing.headline.slice(0, splitHeadlineIdx + 1) : financing.headline
  const headlineAccent =
    splitHeadlineIdx !== -1 ? financing.headline.slice(splitHeadlineIdx + 2) : ''

  return (
    <section
      id="financing"
      className="bg-architectural-grid-dark relative overflow-hidden border-b border-white/10 bg-[var(--roof-obsidian)] py-14 text-white sm:py-20"
    >
      {/* Animated multi-hue radial glows */}
      <div
        aria-hidden="true"
        className="animate-aurora-slow pointer-events-none absolute -top-20 right-10 h-80 w-80 rounded-full bg-pink-500/12 blur-[120px]"
      />
      <div
        aria-hidden="true"
        className="animate-aurora-reverse pointer-events-none absolute -bottom-24 left-8 h-96 w-96 rounded-full bg-[var(--roof-copper)]/18 blur-[130px]"
      />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-12">
          {/* Left copy + native providers */}
          <MotionReveal className="lg:col-span-6">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/8 px-3.5 py-1.5 text-xs font-bold tracking-wider text-[var(--roof-amber-light)] uppercase backdrop-blur-md">
              <Sparkles className="h-3.5 w-3.5" />
              <span>{financing.eyebrow}</span>
            </div>

            <h2 className="font-display mt-4 text-3xl font-extrabold text-white sm:text-4xl">
              {headlineLead}
              {headlineAccent && (
                <>
                  {' '}
                  <span className="bg-gradient-to-r from-[var(--roof-copper-light)] via-pink-300 to-emerald-300 bg-clip-text text-transparent">
                    {headlineAccent}
                  </span>
                </>
              )}
            </h2>

            <p className="mt-4 text-base leading-relaxed text-white/75">{financing.description}</p>

            <div className="mt-7 space-y-3.5">
              {financing.providers.map((provider, idx) => {
                const style = PROVIDER_ACCENTS[idx % PROVIDER_ACCENTS.length]
                return (
                  <div
                    key={provider.name}
                    className={`flex items-start justify-between gap-4 rounded-2xl border bg-white/[0.05] p-4 backdrop-blur-md transition-all duration-300 hover:-translate-y-0.5 hover:bg-white/[0.09] ${style.border}`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <CreditCard className={`h-4 w-4 ${style.iconColor}`} />
                        <h3 className="font-display text-base font-bold text-white">
                          {provider.name}
                        </h3>
                      </div>
                      <p className="mt-1 text-sm text-white/70">{provider.terms}</p>
                    </div>
                    <span
                      className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold ${style.badgeBg}`}
                    >
                      {provider.badge}
                    </span>
                  </div>
                )
              })}
            </div>

            <p className="mt-5 text-xs leading-relaxed text-white/55">{financing.disclaimer}</p>
          </MotionReveal>

          {/* Right interactive roofing payment breakdown widget */}
          <MotionReveal delayMs={100} className="lg:col-span-6">
            <div className="rounded-3xl bg-gradient-to-br from-[var(--roof-copper-light)]/40 via-white/15 to-emerald-400/35 p-[1.5px] shadow-[0_25px_70px_-20px_rgba(0,0,0,0.8)]">
              <div className="rounded-[calc(1.5rem-1.5px)] bg-[var(--roof-midnight)] p-6 sm:p-8">
                <div className="flex items-center justify-between gap-4 border-b border-white/12 pb-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-bold tracking-wider text-[var(--roof-amber-light)] uppercase">
                      <Calculator className="h-4 w-4" />
                      <span>Roof Replacement & Split-Pay Estimator</span>
                    </div>
                    <p className="mt-1 text-xs text-white/65">
                      Slide or pick a preset to preview deposit credit vs. financed final balance.
                    </p>
                  </div>
                  <span className="font-mono-num rounded-xl bg-gradient-to-r from-[var(--roof-copper)] to-[var(--roof-amber)] px-3.5 py-1.5 text-lg font-extrabold text-white shadow-md">
                    ${projectTotal.toLocaleString()}
                  </span>
                </div>

                {/* Quick preset pills */}
                <div className="mt-5 flex flex-wrap gap-2">
                  {scopePresets.map((preset) => (
                    <button
                      key={preset.value}
                      type="button"
                      onClick={() => setProjectTotal(preset.value)}
                      className={`rounded-full px-3 py-1 text-xs font-semibold transition-all ${
                        projectTotal === preset.value
                          ? 'bg-white text-[var(--roof-obsidian)] shadow-sm'
                          : 'border border-white/15 bg-white/5 text-white/75 hover:bg-white/12'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>

                {/* Slider with gradient track bar */}
                <div className="mt-5">
                  <label
                    htmlFor="financing-slider"
                    className="flex items-center justify-between text-xs font-medium text-white/80"
                  >
                    <span>Estimated Total Roofing Scope</span>
                    <span className="font-mono-num text-white/60">$2,500 – $28,000</span>
                  </label>
                  <div className="relative mt-3">
                    <div className="h-2 w-full overflow-hidden rounded-full bg-white/12">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-[var(--roof-copper)] via-[var(--roof-amber)] to-[var(--roof-forest)] transition-all duration-150"
                        style={{ width: `${sliderProgress}%` }}
                      />
                    </div>
                    <input
                      id="financing-slider"
                      type="range"
                      min={2500}
                      max={28000}
                      step={250}
                      value={projectTotal}
                      onChange={(e) => setProjectTotal(Number(e.target.value))}
                      className="absolute inset-0 h-2 w-full cursor-pointer opacity-0"
                    />
                  </div>
                </div>

                {/* Breakdown metrics */}
                <div className="mt-6 grid gap-3 sm:grid-cols-2">
                  <div className="rounded-2xl border border-emerald-400/25 bg-emerald-500/10 p-4">
                    <div className="text-xs text-emerald-200/80">1. Scheduling Deposit Today</div>
                    <div className="font-mono-num mt-1 text-2xl font-extrabold text-white">
                      ${depositToday.toLocaleString()}
                    </div>
                    <div className="mt-1 text-[11px] font-medium text-emerald-300">
                      Credited 100% + saves card-on-file
                    </div>
                  </div>
                  <div className="rounded-2xl border border-[var(--roof-copper-light)]/30 bg-[var(--roof-copper)]/12 p-4">
                    <div className="text-xs text-[var(--roof-copper-pale)]">
                      2. Final Invoice Balance After Install
                    </div>
                    <div className="font-mono-num mt-1 text-2xl font-extrabold text-[var(--roof-copper-light)]">
                      ${netBalanceAfterDeposit.toLocaleString()}
                    </div>
                    <div className="mt-1 text-[11px] text-white/70">Settled cleanly upon job closeout</div>
                  </div>
                </div>

                {/* Interactive monthly installment selectors */}
                <div className="mt-4 grid grid-cols-3 gap-2.5 text-center">
                  {(
                    [
                      { months: 12 as const, val: monthly12Est },
                      { months: 24 as const, val: monthly24Est },
                      { months: 36 as const, val: monthly36Est },
                    ]
                  ).map((opt) => {
                    const active = selectedTerm === opt.months
                    return (
                      <button
                        key={opt.months}
                        type="button"
                        onClick={() => setSelectedTerm(opt.months)}
                        className={`rounded-xl border p-3 transition-all ${
                          active
                            ? 'border-[var(--roof-copper-light)] bg-gradient-to-b from-[var(--roof-copper)]/25 to-white/10 shadow-[0_0_20px_-6px_color-mix(in_srgb,var(--roof-copper)_65%,transparent)]'
                            : 'border-white/10 bg-white/[0.05] hover:bg-white/10'
                        }`}
                      >
                        <div
                          className={`text-[11px] font-semibold ${
                            active ? 'text-[var(--roof-amber-light)]' : 'text-white/60'
                          }`}
                        >
                          {opt.months} Months*
                        </div>
                        <div className="font-mono-num mt-1 text-base font-extrabold text-white">
                          ~${opt.val}/mo
                        </div>
                      </button>
                    )
                  })}
                </div>

                <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-2 text-xs text-white/75">
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                    <span>Zero contractor underwriting setup required</span>
                  </div>
                  <Link
                    to="/deposit"
                    onClick={() => {
                      onStartDepositCheckout?.()
                      trackWhopEvent('deposit_started', {
                        plan_key: 'deposit',
                        amount_usd: depositToday,
                        estimated_scope_usd: projectTotal,
                        source: 'financing_calculator',
                      })
                    }}
                    className="btn-shimmer inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[var(--roof-copper)] to-[var(--roof-amber)] px-5 py-2.5 text-sm font-bold text-white shadow-lg transition-all hover:-translate-y-0.5"
                  >
                    <span>Start ${depositToday} Deposit</span>
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                </div>
                <p className="mt-3 text-[11px] text-white/45">
                  *Sample installment estimates exclude applicable APR or lender terms determined at
                  checkout by Klarna, Splitit, or Afterpay.
                </p>
              </div>
            </div>
          </MotionReveal>
        </div>
      </div>
    </section>
  )
}
