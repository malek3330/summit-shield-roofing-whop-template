import { useMemo, useState } from 'react'
import { Compass, MapPin, Navigation, Radio, ShieldAlert } from 'lucide-react'
import { roofingTemplate, type ServiceCity } from '#/config/roofingTemplate'
import { MotionReveal } from './MotionReveal'

interface ResolvedRadarNode {
  cityKey: string
  label: string
  x: number
  y: number
  hub: boolean
}

function buildRadarNodes(cities: ServiceCity[]): ResolvedRadarNode[] {
  if (cities.length === 0) return []
  const explicitHubIdx = cities.findIndex((c) => c.isHub)
  const hubIndex = explicitHubIdx >= 0 ? explicitHubIdx : 0

  const hubCity = cities[hubIndex]
  const hubX = typeof hubCity.mapX === 'number' ? hubCity.mapX : 180
  const hubY = typeof hubCity.mapY === 'number' ? hubCity.mapY : 122

  const nonHubCities = cities.filter((_, i) => i !== hubIndex)
  let nonHubCursor = 0

  return cities.map((city, idx) => {
    const isHub = idx === hubIndex
    const shortName = city.city.split('&')[0].trim()
    const label = city.mapLabel || (isHub ? `${shortName} HQ` : shortName)

    if (typeof city.mapX === 'number' && typeof city.mapY === 'number') {
      return { cityKey: city.city, label, x: city.mapX, y: city.mapY, hub: isHub }
    }

    if (isHub) {
      return { cityKey: city.city, label, x: hubX, y: hubY, hub: true }
    }

    const totalSpokes = Math.max(1, nonHubCities.length)
    const angle = -Math.PI / 2 + (nonHubCursor / totalSpokes) * Math.PI * 2
    nonHubCursor += 1

    const computedX = Math.max(36, Math.min(265, Math.round(hubX + Math.cos(angle) * 96)))
    const computedY = Math.max(30, Math.min(192, Math.round(hubY + Math.sin(angle) * 72)))
    return { cityKey: city.city, label, x: computedX, y: computedY, hub: false }
  })
}

export function ServiceAreaSection() {
  const { serviceArea } = roofingTemplate
  const [activeCity, setActiveCity] = useState(serviceArea.cities[0]?.city ?? '')

  const mapNodes = useMemo(() => buildRadarNodes(serviceArea.cities), [serviceArea.cities])

  const selectedCityObj =
    serviceArea.cities.find((c) => c.city === activeCity) ?? serviceArea.cities[0]

  const hubNode = mapNodes.find((n) => n.hub) ?? mapNodes[0] ?? {
    cityKey: '',
    label: 'HQ',
    x: 180,
    y: 122,
    hub: true,
  }

  const focusedNode =
    mapNodes.find((node) => node.cityKey === selectedCityObj?.city) ?? hubNode

  if (!selectedCityObj) return null

  return (
    <section
      id="service-area"
      className="border-b border-[var(--roof-border)] bg-gradient-to-b from-[var(--roof-surface)]/70 to-[var(--roof-canvas)] py-14 sm:py-20"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-start gap-10 lg:grid-cols-12">
          {/* Left Copy & Interactive City Cards */}
          <MotionReveal className="lg:col-span-7">
            <div className="inline-flex items-center gap-2 rounded-full border border-emerald-300/60 bg-emerald-50 px-3.5 py-1 text-xs font-bold tracking-wider text-emerald-800 uppercase">
              <Compass className="h-3.5 w-3.5 text-[var(--roof-copper)]" />
              <span>{serviceArea.regionLabel}</span>
            </div>

            <h2 className="font-display mt-3 text-3xl font-extrabold text-[var(--roof-ink)] sm:text-4xl">
              {serviceArea.headline}
            </h2>

            <p className="mt-3 text-base leading-relaxed text-[#4B5563]">
              {serviceArea.description}
            </p>

            <div className="mt-4 flex items-center gap-2.5 rounded-2xl border border-[var(--roof-copper)]/30 bg-gradient-to-r from-[var(--roof-copper)]/10 to-[var(--roof-amber)]/10 px-4 py-3 text-sm font-semibold text-[var(--roof-copper-deep)]">
              <ShieldAlert className="h-4 w-4 shrink-0" />
              <span>{serviceArea.emergencyDispatchText}</span>
            </div>

            {/* City cards grid */}
            <div className="mt-7 grid gap-3 sm:grid-cols-2">
              {serviceArea.cities.map((item) => {
                const isSelected = item.city === selectedCityObj.city
                return (
                  <button
                    key={item.city}
                    type="button"
                    onClick={() => setActiveCity(item.city)}
                    className={`flex flex-col rounded-2xl border p-4 text-left transition-all duration-200 hover:-translate-y-0.5 ${
                      isSelected
                        ? 'border-[var(--roof-copper)] bg-white shadow-[0_14px_30px_-10px_color-mix(in_srgb,var(--roof-copper)_22%,transparent)] ring-1 ring-[var(--roof-copper)]'
                        : 'border-[var(--roof-border)] bg-white/85 hover:border-[var(--roof-ink)]/35 hover:bg-white hover:shadow-sm'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="font-display text-base font-bold text-[var(--roof-ink)]">
                        {item.city}
                      </span>
                      <span
                        className={`font-mono-num shrink-0 rounded-full px-2.5 py-0.5 text-[11px] font-bold ${
                          isSelected
                            ? 'bg-emerald-600 text-white'
                            : 'bg-emerald-500/12 text-emerald-700'
                        }`}
                      >
                        {item.dispatchEta}
                      </span>
                    </div>
                    <div className="mt-1.5 text-xs text-[#4B5563]">
                      {item.county} · ZIP {item.zipPrefix}
                    </div>
                    <div className="mt-2 text-xs font-semibold text-[var(--roof-copper-deep)]">
                      {item.roofFocus}
                    </div>
                  </button>
                )
              })}
            </div>
          </MotionReveal>

          {/* Right Live Dark Architectural Dispatch Radar Card */}
          <MotionReveal delayMs={100} className="lg:col-span-5">
            <div className="overflow-hidden rounded-3xl border border-white/10 bg-[var(--roof-obsidian)] p-6 text-white shadow-2xl">
              <div className="flex items-center justify-between border-b border-white/12 pb-4">
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold tracking-wider text-emerald-300 uppercase">
                    <Radio className="h-3.5 w-3.5 animate-pulse" />
                    <span>Live Dispatch Corridor</span>
                  </div>
                  <div className="font-display mt-1 text-lg font-bold text-white">
                    {selectedCityObj.city}
                  </div>
                </div>
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[var(--roof-copper)] to-[var(--roof-amber)] text-white shadow-md">
                  <Navigation className="h-5 w-5" />
                </span>
              </div>

              {/* Illuminated Night Dispatch Radar Map */}
              <div className="mt-5 overflow-hidden rounded-2xl border border-white/10 bg-[var(--roof-midnight)] p-3">
                <svg
                  viewBox="0 0 360 220"
                  className="h-auto w-full"
                  role="img"
                  aria-label={serviceArea.radarLabel}
                >
                  <defs>
                    <pattern id="radarGrid" width="24" height="24" patternUnits="userSpaceOnUse">
                      <path
                        d="M 24 0 L 0 0 0 24"
                        fill="none"
                        stroke="rgba(255,255,255,0.06)"
                        strokeWidth="0.8"
                      />
                    </pattern>
                    <radialGradient id="hubGlow" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="rgba(16, 185, 129, 0.25)" />
                      <stop offset="100%" stopColor="rgba(16, 185, 129, 0)" />
                    </radialGradient>
                  </defs>

                  <rect width="360" height="220" fill="url(#radarGrid)" rx="10" />
                  <circle cx={hubNode.x} cy={hubNode.y} r="95" fill="url(#hubGlow)" />

                  {/* Coverage rings centered on Local HQ */}
                  <circle
                    cx={hubNode.x}
                    cy={hubNode.y}
                    r="88"
                    fill="none"
                    stroke="rgba(16, 185, 129, 0.3)"
                    strokeDasharray="4 4"
                  />
                  <circle
                    cx={hubNode.x}
                    cy={hubNode.y}
                    r="52"
                    fill="color-mix(in srgb, var(--roof-copper) 10%, transparent)"
                    stroke="var(--roof-copper-light)"
                    strokeOpacity="0.45"
                    strokeWidth="1.2"
                  />

                  {/* Highway corridor axes */}
                  <path
                    d={`M ${hubNode.x} 12 L ${hubNode.x} 210`}
                    stroke="rgba(255, 255, 255, 0.14)"
                    strokeWidth="2"
                  />
                  <path
                    d={`M 35 ${Math.min(185, hubNode.y + 20)} Q 150 ${hubNode.y} 325 ${Math.max(36, hubNode.y - 44)}`}
                    stroke="rgba(255, 255, 255, 0.14)"
                    strokeWidth="2"
                    fill="none"
                  />

                  {/* Animated Dispatch Beam from HQ to Focused City */}
                  {!focusedNode.hub && (
                    <line
                      x1={hubNode.x}
                      y1={hubNode.y}
                      x2={focusedNode.x}
                      y2={focusedNode.y}
                      stroke="var(--roof-copper-light)"
                      strokeWidth="2.5"
                      strokeDasharray="6 6"
                      className="animate-dash-flow"
                    />
                  )}

                  {/* City nodes */}
                  {mapNodes.map((node) => {
                    const isFocused = node.cityKey === focusedNode.cityKey
                    return (
                      <g
                        key={node.cityKey}
                        onClick={() => setActiveCity(node.cityKey)}
                        className="cursor-pointer"
                      >
                        {isFocused && (
                          <circle
                            cx={node.x}
                            cy={node.y}
                            r={10}
                            fill="var(--roof-copper-light)"
                            fillOpacity="0.4"
                            className="animate-radar-ping"
                          />
                        )}
                        <circle
                          cx={node.x}
                          cy={node.y}
                          r={node.hub ? 7.5 : isFocused ? 6.5 : 4.5}
                          fill={
                            isFocused
                              ? 'var(--roof-copper-light)'
                              : node.hub
                                ? 'var(--roof-forest)'
                                : '#38BDF8'
                          }
                          stroke="var(--roof-obsidian)"
                          strokeWidth="1.5"
                        />
                        <text
                          x={node.x + 11}
                          y={node.y + 4}
                          fontSize="10.5"
                          fontWeight={node.hub || isFocused ? '700' : '500'}
                          fill={isFocused ? 'var(--roof-amber-light)' : '#E5E7EB'}
                        >
                          {node.label}
                        </text>
                      </g>
                    )
                  })}
                </svg>
              </div>

              <dl className="mt-5 grid grid-cols-2 gap-3 text-sm">
                <div className="rounded-xl border border-white/10 bg-white/[0.04] p-3">
                  <dt className="text-xs text-white/60">County</dt>
                  <dd className="mt-0.5 font-semibold text-white">{selectedCityObj.county}</dd>
                </div>
                <div className="rounded-xl border border-emerald-400/25 bg-emerald-500/10 p-3">
                  <dt className="text-xs text-emerald-200/80">Estimated Truck ETA</dt>
                  <dd className="font-mono-num mt-0.5 font-bold text-emerald-300">
                    ~{selectedCityObj.dispatchEta}
                  </dd>
                </div>
              </dl>

              <a
                href="#estimate-form"
                className="btn-shimmer mt-5 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[var(--roof-copper)] to-[var(--roof-amber)] px-4 py-3 text-sm font-bold text-white shadow-lg transition-all hover:-translate-y-0.5"
              >
                <MapPin className="h-4 w-4" />
                <span>Schedule Inspection in {selectedCityObj.city.split('&')[0].trim()}</span>
              </a>
            </div>
          </MotionReveal>
        </div>
      </div>
    </section>
  )
}
