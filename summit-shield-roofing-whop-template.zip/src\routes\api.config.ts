import { createFileRoute } from '@tanstack/react-router'
import { getAdminSession } from '#/server/auth'
import {
  getPublicRuntimeConfig,
  jsonResponse,
  resolveAuthorizedRuntimeMode,
} from '#/server/whopServer'

export const Route = createFileRoute('/api/config')({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const isAdmin = await getAdminSession(request)
        const url = new URL(request.url)
        const requestedMode = url.searchParams.get('mode')
        const effectiveMode = resolveAuthorizedRuntimeMode(requestedMode, isAdmin, true)
        const config = getPublicRuntimeConfig(isAdmin, effectiveMode)

        return jsonResponse({
          ok: true,
          ...config,
        })
      },
    },
  },
})
