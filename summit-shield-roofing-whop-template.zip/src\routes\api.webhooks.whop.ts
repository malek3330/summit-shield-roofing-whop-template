import { createFileRoute } from '@tanstack/react-router'
import { unwrapWebhook } from '@whop/sdk/helpers'
import { jsonResponse, readServerEnv } from '#/server/whopServer'

export const Route = createFileRoute('/api/webhooks/whop')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const rawPayload = await request.text()
        const webhookSecret = readServerEnv('WHOP_WEBHOOK_SECRET')

        if (!webhookSecret) {
          return jsonResponse(
            {
              ok: false,
              code: 'WEBHOOK_SECRET_NOT_CONFIGURED',
              message:
                'WHOP_WEBHOOK_SECRET is not set. Configure your `ws_...` webhook secret to verify Whop events.',
            },
            503,
          )
        }

        const headersRecord: Record<string, string> = {}
        request.headers.forEach((value, key) => {
          headersRecord[key] = value
        })

        try {
          const event = unwrapWebhook<{
            type?: string
            action?: string
            data?: Record<string, unknown>
          }>(rawPayload, {
            headers: headersRecord,
            key: webhookSecret,
          })

          const eventName = event.type ?? event.action ?? 'unknown'
          console.info('[whop.webhook] verified event:', eventName)

          return jsonResponse({
            received: true,
            event: eventName,
          })
        } catch (error) {
          const message =
            error instanceof Error ? error.message : 'Webhook signature verification failed.'
          return jsonResponse(
            {
              ok: false,
              code: 'INVALID_WEBHOOK_SIGNATURE',
              message,
            },
            400,
          )
        }
      },
    },
  },
})
